import pandas as pd
import numpy as np
from PyQt5.QtCore import QThread, pyqtSignal

class DataAnalysisWorker(QThread):
    progress_updated = pyqtSignal(int)
    analysis_completed = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, file_path):
        super().__init__()
        self.file_path = file_path
    
    def run(self):
        try:
            self.progress_updated.emit(10)
            sheets = pd.read_excel(self.file_path, sheet_name=None)
            self.progress_updated.emit(30)
            
            # Check required sheets
            required_sheets = ["Historical Usage", "Supplier Performance", 
                  "Current Inventory", "Financial Extra Cost Data",
                  "Historical Forecast", "Financial Standard Price"]
            for sheet in required_sheets:
                if sheet not in sheets:
                    raise ValueError(f"Required sheet '{sheet}' not found in Excel file")
            
            self.progress_updated.emit(40)
            results = self.analyze_data(sheets)
            self.progress_updated.emit(100)
            self.analysis_completed.emit(results)
            
        except Exception as e:
            self.error_occurred.emit(str(e))
    
    def analyze_data(self, sheets):
        historical_usage = sheets["Historical Usage"]
        supplier_performance = sheets["Supplier Performance"]
        current_inventory = sheets["Current Inventory"]
        financial_data = sheets["Financial Extra Cost Data"]
        
        # Get period columns (last 60 columns that match YYYYMXX format)
        period_columns = []
        for col in historical_usage.columns:
            if isinstance(col, str) and len(col) == 7 and col[4] == 'M':
                try:
                    year = int(col[:4])
                    month = int(col[5:])
                    if 2020 <= year <= 2030 and 1 <= month <= 12:
                        period_columns.append(col)
                except:
                    continue
        
        period_columns = sorted(period_columns)[-60:]  # Last 60 periods
        last_12_periods = period_columns[-12:]  # Get last 12 periods for analysis
        
        self.progress_updated.emit(50)
        
        # Get all material codes from Historical Usage
        all_material_codes = historical_usage['Material Code'].dropna().unique()
        
        # Categorize materials based on usage in last 12 periods
        materials_with_no_usage = []
        materials_with_usage = []
        
        for material_code in all_material_codes:
            material_row = historical_usage[historical_usage['Material Code'] == material_code]
            if not material_row.empty:
                # Get last 12 periods data
                last_12_values = material_row[last_12_periods].iloc[0]
                numeric_values = pd.to_numeric(last_12_values, errors='coerce').fillna(0)
                
                if (numeric_values == 0).all():
                    materials_with_no_usage.append(material_code)
                else:
                    materials_with_usage.append(material_code)
        
        self.progress_updated.emit(70)
        
        # Get material codes from other sheets
        supplier_material_codes = set(supplier_performance['Material Code'].dropna().unique())
        inventory_material_codes = set(current_inventory['Material Code'].dropna().unique())
        financial_material_codes = set(financial_data['Material Code'].dropna().unique())
        
        # Analyze materials WITH usage in last 12 periods
        materials_with_usage_no_supplier = [mat for mat in materials_with_usage if mat not in supplier_material_codes]
        materials_with_usage_no_stock = [mat for mat in materials_with_usage if mat not in inventory_material_codes]
        materials_with_usage_have_extra_costs = [mat for mat in materials_with_usage if mat in financial_material_codes]
        
        self.progress_updated.emit(90)
        
        # Calculate financial analysis for materials with usage and costs
        financial_analysis = {}
        classification_totals = {}

        if materials_with_usage_have_extra_costs:
            # Find the extra cost column by name pattern
            extra_cost_col = None
            possible_cost_columns = ['Extra Cost', 'Expedited', 'Write-Off', 'Cost']
            
            for col in financial_data.columns:
                if any(keyword in str(col) for keyword in possible_cost_columns):
                    extra_cost_col = col
                    break
            
            # Find classification column if exists
            classification_col = None
            for col in financial_data.columns:
                if 'Classification' in str(col):
                    classification_col = col
                    break
            
            for material_code in materials_with_usage_have_extra_costs:
                financial_row = financial_data[financial_data['Material Code'] == material_code]
                if not financial_row.empty:
                    # Get classification (if column exists)
                    classification = 'Unknown'
                    if classification_col:
                        classification = financial_row[classification_col].iloc[0] if pd.notna(financial_row[classification_col].iloc[0]) else 'Unknown'
                    
                    # Get extra cost (if column exists)
                    extra_cost = 0.0
                    if extra_cost_col:
                        extra_cost_raw = financial_row[extra_cost_col].iloc[0]
                        try:
                            extra_cost = float(extra_cost_raw) if pd.notna(extra_cost_raw) else 0.0
                        except (ValueError, TypeError):
                            extra_cost = 0.0
                    
                    # Accumulate totals by classification
                    if classification not in classification_totals:
                        classification_totals[classification] = 0.0
                    classification_totals[classification] += extra_cost
                    
                    financial_analysis[material_code] = {
                        'classification': classification,
                        'extra_cost': extra_cost,
                        'classification_total': 0.0  # Will be filled in next step
                    }
            
            # Second pass: add classification totals to each material
            for material_code in financial_analysis:
                classification = financial_analysis[material_code]['classification']
                financial_analysis[material_code]['classification_total'] = classification_totals.get(classification, 0.0)
        
        # Create analysis results with corrected categories
        analysis_results = {
            'sheets': sheets,
            'period_columns': period_columns,
            'last_12_periods': last_12_periods,
            'insights': {
                'Total Materials Analyzed': all_material_codes.tolist(),
                'Materials With No Usage Last 12 Periods': materials_with_no_usage,
                'Materials With Usage Last 12 Periods': materials_with_usage,
                'Materials With Usage AND No Supplier Records': materials_with_usage_no_supplier,
                'Materials With Usage AND No Current Stock': materials_with_usage_no_stock,
                'Materials With Usage AND Have Extra Costs': materials_with_usage_have_extra_costs
            },
            'total_materials': len(all_material_codes),
            'materials_with_usage': len(materials_with_usage),
            'materials_no_usage': len(materials_with_no_usage),
            'financial_analysis': financial_analysis
        }
        
        return analysis_results
import pandas as pd
import numpy as np
from PyQt5.QtCore import QThread, pyqtSignal

class DataAnalysisWorker(QThread):
    progress_updated = pyqtSignal(int)
    analysis_completed = pyqtSignal(dict)
    error_occurred = pyqtSignal(str)
    
    def __init__(self, file_path):
        super().__init__()
        self.file_path = file_path
    
    def run(self):
        try:
            self.progress_updated.emit(10)
            sheets = pd.read_excel(self.file_path, sheet_name=None)
            self.progress_updated.emit(30)
            
            # Check required sheets
            required_sheets = ["Historical Usage", "Supplier Performance", 
                  "Current Inventory", "Financial Extra Cost Data",
                  "Historical Forecast", "Financial Standard Price"]
            for sheet in required_sheets:
                if sheet not in sheets:
                    raise ValueError(f"Required sheet '{sheet}' not found in Excel file")
            
            self.progress_updated.emit(40)
            results = self.analyze_data(sheets)
            self.progress_updated.emit(100)
            self.analysis_completed.emit(results)
            
        except Exception as e:
            self.error_occurred.emit(str(e))
    
    def analyze_data(self, sheets):
        historical_usage = sheets["Historical Usage"]
        supplier_performance = sheets["Supplier Performance"]
        current_inventory = sheets["Current Inventory"]
        financial_data = sheets["Financial Extra Cost Data"]
        
        # Get period columns (last 60 columns that match YYYYMXX format)
        period_columns = []
        for col in historical_usage.columns:
            if isinstance(col, str) and len(col) == 7 and col[4] == 'M':
                try:
                    year = int(col[:4])
                    month = int(col[5:])
                    if 2020 <= year <= 2030 and 1 <= month <= 12:
                        period_columns.append(col)
                except:
                    continue
        
        period_columns = sorted(period_columns)[-60:]  # Last 60 periods
        last_12_periods = period_columns[-12:]  # Get last 12 periods for analysis
        
        self.progress_updated.emit(50)
        
        # Get all material codes from Historical Usage
        all_material_codes = historical_usage['Material Code'].dropna().unique()
        
        # Categorize materials based on usage in last 12 periods
        materials_with_no_usage = []
        materials_with_usage = []
        
        for material_code in all_material_codes:
            material_row = historical_usage[historical_usage['Material Code'] == material_code]
            if not material_row.empty:
                # Get last 12 periods data
                last_12_values = material_row[last_12_periods].iloc[0]
                numeric_values = pd.to_numeric(last_12_values, errors='coerce').fillna(0)
                
                if (numeric_values == 0).all():
                    materials_with_no_usage.append(material_code)
                else:
                    materials_with_usage.append(material_code)
        
        self.progress_updated.emit(70)
        
        # Get material codes from other sheets
        supplier_material_codes = set(supplier_performance['Material Code'].dropna().unique())
        inventory_material_codes = set(current_inventory['Material Code'].dropna().unique())
        financial_material_codes = set(financial_data['Material Code'].dropna().unique())
        
        # Analyze materials WITH usage in last 12 periods
        materials_with_usage_no_supplier = [mat for mat in materials_with_usage if mat not in supplier_material_codes]
        materials_with_usage_no_stock = [mat for mat in materials_with_usage if mat not in inventory_material_codes]
        materials_with_usage_have_extra_costs = [mat for mat in materials_with_usage if mat in financial_material_codes]
        
        self.progress_updated.emit(90)
        
        # Calculate financial analysis for materials with usage and costs
        financial_analysis = {}
        classification_totals = {}

        if materials_with_usage_have_extra_costs:
            # Find the extra cost column by name pattern
            extra_cost_col = None
            possible_cost_columns = ['Extra Cost', 'Expedited', 'Write-Off', 'Cost']
            
            for col in financial_data.columns:
                if any(keyword in str(col) for keyword in possible_cost_columns):
                    extra_cost_col = col
                    break
            
            # Find classification column if exists
            classification_col = None
            for col in financial_data.columns:
                if 'Classification' in str(col):
                    classification_col = col
                    break
            
            for material_code in materials_with_usage_have_extra_costs:
                financial_row = financial_data[financial_data['Material Code'] == material_code]
                if not financial_row.empty:
                    # Get classification (if column exists)
                    classification = 'Unknown'
                    if classification_col:
                        classification = financial_row[classification_col].iloc[0] if pd.notna(financial_row[classification_col].iloc[0]) else 'Unknown'
                    
                    # Get extra cost (if column exists)
                    extra_cost = 0.0
                    if extra_cost_col:
                        extra_cost_raw = financial_row[extra_cost_col].iloc[0]
                        try:
                            extra_cost = float(extra_cost_raw) if pd.notna(extra_cost_raw) else 0.0
                        except (ValueError, TypeError):
                            extra_cost = 0.0
                    
                    # Accumulate totals by classification
                    if classification not in classification_totals:
                        classification_totals[classification] = 0.0
                    classification_totals[classification] += extra_cost
                    
                    financial_analysis[material_code] = {
                        'classification': classification,
                        'extra_cost': extra_cost,
                        'classification_total': 0.0  # Will be filled in next step
                    }
            
            # Second pass: add classification totals to each material
            for material_code in financial_analysis:
                classification = financial_analysis[material_code]['classification']
                financial_analysis[material_code]['classification_total'] = classification_totals.get(classification, 0.0)
        
        # Create analysis results with corrected categories
        analysis_results = {
            'sheets': sheets,
            'period_columns': period_columns,
            'last_12_periods': last_12_periods,
            'insights': {
                'Total Materials Analyzed': all_material_codes.tolist(),
                'Materials With No Usage Last 12 Periods': materials_with_no_usage,
                'Materials With Usage Last 12 Periods': materials_with_usage,
                'Materials With Usage AND No Supplier Records': materials_with_usage_no_supplier,
                'Materials With Usage AND No Current Stock': materials_with_usage_no_stock,
                'Materials With Usage AND Have Extra Costs': materials_with_usage_have_extra_costs
            },
            'total_materials': len(all_material_codes),
            'materials_with_usage': len(materials_with_usage),
            'materials_no_usage': len(materials_with_no_usage),
            'financial_analysis': financial_analysis
        }
        
        print("Exploratory Data Analysis Phase Completed\n")
        return analysis_results


        