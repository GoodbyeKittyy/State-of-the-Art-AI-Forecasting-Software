import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from PyQt5.QtWidgets import (QTableWidget, QTableWidgetItem, QHeaderView, QSizePolicy, QVBoxLayout, QWidget, QLabel, QHBoxLayout)
from PyQt5.QtCore import Qt, QTimer, pyqtSignal
from PyQt5.QtGui import QFont, QFontMetrics

class DynamicLearningTables(QWidget):
    # Signal to emit progress updates
    progress_updated = pyqtSignal(int, int)  # current, total
    
    def __init__(self, analysis_results, tabpfn_forecasts, accuracy_results, cost_savings_results, worker):
        super().__init__()
        self.analysis_results = analysis_results
        self.tabpfn_forecasts = tabpfn_forecasts
        self.accuracy_results = accuracy_results
        self.cost_savings_results = cost_savings_results
        self.worker = worker # The worker instance passed from DynamicLearningTab
        
        # Progress tracking variables
        self.total_materials = 0
        self.processed_materials = 0

    def create_optimized_forecast_table(self, layout):
        """Create the single table with optimized forecasts and two-column explanations - OPTIMIZED VERSION"""
        
        table = QTableWidget()

        # ====== ADD FONT SETTINGS HERE ======
        font = QFont()
        font.setPointSize(12)  # Adjust size as needed (10-12 is typical)
        table.setFont(font)
            
        # Get all necessary data
        supplier_perf = self.analysis_results['sheets']['Supplier Performance']
        current_inventory = self.analysis_results['sheets']['Current Inventory']
        financial_extra = self.analysis_results['sheets']['Financial Extra Cost Data']
        
        # Initialize progress tracking
        material_codes = sorted(self.tabpfn_forecasts.keys())
        self.total_materials = len(material_codes)
        self.processed_materials = 0
        
        # Prepare data for optimization
        optimized_results = []
        
        # Process each material code
        for idx, material_code in enumerate(material_codes):
            # Update progress
            self.processed_materials = idx + 1
            
            # Print progress to console every 50 materials
            if self.processed_materials % 50 == 0 or self.processed_materials == self.total_materials:
                print(f"{self.processed_materials}/{self.total_materials} materials processed")
            
            # Force GUI update to show progress
            self.update()
            
            # Get initial TabPFN forecast
            initial_forecast = self.tabpfn_forecasts[material_code]['forecast']
            
            # Get accuracy metrics
            accuracy_info = next((r for r in self.accuracy_results if r['Material Code'] == material_code), None)
            
            # Get cost savings
            cost_info = next((r for r in self.cost_savings_results if r['Material Code'] == material_code), None)
            
            # Get supplier performance data
            supplier_data = supplier_perf[supplier_perf['Material Code'] == material_code]
            if not supplier_data.empty:
                po_lead_times = supplier_data['PO Lead Time Weeks (Delivery Date vs GRN Date)'].dropna()
                quote_lead_times = supplier_data['Quotation Lead Time Weeks'].dropna()
                
                # Calculate supplier reliability score using worker's method
                if len(po_lead_times) > 0 and len(quote_lead_times) > 0:
                    reliability_score = self.worker._calculate_supplier_reliability(po_lead_times, quote_lead_times)
                else:
                    reliability_score = 50  # Default if no data
            else:
                reliability_score = 50  # Default if no data
            
            # Get inventory data
            inventory_data = current_inventory[current_inventory['Material Code'] == material_code]
            if not inventory_data.empty:
                current_stock = inventory_data['Current Stock'].values[0]
                shelf_life = inventory_data['Shelf Life Days'].values[0]
                moq = inventory_data['MOQ'].values[0]
                reorder_point = inventory_data['Reorder Point'].values[0]
                min_safety = inventory_data['Minimum Safety Stock'].values[0]
                max_stock = inventory_data['Max Stock'].values[0]
                
                # Calculate inventory risk score using worker's method
                inventory_risk = self.worker._calculate_inventory_risk(
                    current_stock, shelf_life, moq, reorder_point, min_safety, max_stock, initial_forecast)
            else:
                current_stock = 0  # Add this line
                inventory_risk = 50  # Default if no data
            
            # Get financial extra cost data
            financial_data = financial_extra[financial_extra['Material Code'] == material_code]
            if not financial_data.empty:
                cost_column = 'Extra Cost (Expedited, Write-Off etc.)' if 'Extra Cost (Expedited, Write-Off etc.)' in financial_data.columns else None
                if cost_column:
                    understock_cost = financial_data[financial_data['Classification'] == 'Understock'][cost_column].sum()
                    overstock_cost = financial_data[financial_data['Classification'] == 'Overstock'][cost_column].sum()
                    obsolete_cost = financial_data[financial_data['Classification'] == 'Obsolete'][cost_column].sum()
                    damage_cost = financial_data[financial_data['Classification'] == 'Unexpected Damage'][cost_column].sum()
            else:
                understock_cost = overstock_cost = obsolete_cost = damage_cost = 0
            
            # Apply fuzzy logic adjustment using worker's method
            fuzzy_adjustment = self.worker._apply_fuzzy_logic(
                accuracy_info['AI Forecast MAPE'] if accuracy_info else 50,
                cost_info['AI Forecast Cost Variance'] if cost_info else 0,
                reliability_score,
                inventory_risk
            )
            
            # Apply evolutionary optimization using worker's method
            optimized_forecast, confidence = self.worker._apply_evolutionary_optimization(
                initial_forecast,
                fuzzy_adjustment,
                accuracy_info['AI Forecast MAPE'] if accuracy_info else 50,
                inventory_risk,
                reliability_score
            )

            # NEW: Calculate smart order quantity considering current stock and lead time
            # current_stock already defined above in inventory_data section
            lead_time_weeks = 4  # Default
            if not supplier_data.empty and 'Quotation Lead Time Weeks' in supplier_data.columns:
                lead_time_mean = supplier_data['Quotation Lead Time Weeks'].dropna().mean()
                if not pd.isna(lead_time_mean):
                    lead_time_weeks = lead_time_mean

            # Smart ordering logic with suggested order dates
            if current_stock >= optimized_forecast:
                # Sufficient stock - no immediate order needed
                smart_order_qty = 0
                deadline_note = "0, sufficient buffer stock"
            elif current_stock < optimized_forecast * 0.3:  # Low stock
                # Need to order more due to low stock and lead time
                smart_order_qty = max(optimized_forecast - current_stock, optimized_forecast * 0.5)
                # Calculate suggested order date (today + safety buffer)
                suggested_order_date = datetime.now() + timedelta(days=3)  # 3-day buffer for urgent orders
                deadline_note = f"{smart_order_qty:.0f}, due to long lead time and low stock \nOrder by {suggested_order_date.strftime('%d-%m-%Y')}"
            else:
                # Normal ordering
                smart_order_qty = optimized_forecast - current_stock
                # Calculate suggested order date based on lead time
                lead_time_days = lead_time_weeks * 7
                suggested_order_date = datetime.now() + timedelta(days=lead_time_days - 14)  # Order 2 weeks before needed
                deadline_note = f"{smart_order_qty:.0f}, standard replenishment order\nOrder by {suggested_order_date.strftime('%d-%m-%Y')}"
            
            # Generate explanation (now returns a dictionary with left and right columns) using worker's method
            explanation_dict = self.worker._generate_explanation(
                material_code,
                initial_forecast,
                optimized_forecast,
                accuracy_info,
                cost_info,
                supplier_data,
                inventory_data,
                financial_data
            )
            
            optimized_results.append({
                'Material Code': material_code,
                'Order Qty & Deadline': deadline_note,  # <-- CHANGED TO USE NEW LOGIC
                'Confidence Score': confidence,
                'Left Explanation': explanation_dict['left_column'],
                'Right Explanation': explanation_dict['right_column']
            })

        
        # ========== OPTIMIZED TABLE SETUP ==========
        # Create the table with 5 columns now (including both explanation columns)
        table.setRowCount(len(optimized_results))
        table.setColumnCount(5)
        table.setHorizontalHeaderLabels([
            'Material Code', 
            'Order Qty & Deadline', 
            'Confidence Score', 
            'Explained',  # Left column
            ''   # Right column
        ])

        # Set the 'Explained' column header to right alignment
        header_item = table.horizontalHeaderItem(3)  # Index 3 is the 'Explained' column
        if header_item:
            header_item.setTextAlignment(Qt.AlignRight)

        # Configure table behavior for proper text wrapping
        table.setWordWrap(True)  # Enable word wrap
        table.setEditTriggers(QTableWidget.NoEditTriggers)  # Make it read-only
        
        # ========== PERFORMANCE OPTIMIZATION ==========
        # CRITICAL: Disable automatic row height calculation for performance
        table.verticalHeader().setSectionResizeMode(QHeaderView.Fixed)
        
        # Set a fixed row height for all rows (much faster than calculating each)
        FIXED_ROW_HEIGHT = 1000  # Adjust this value as needed for your content
        table.verticalHeader().setDefaultSectionSize(FIXED_ROW_HEIGHT)
        
        # Configure column resize modes BEFORE populating data
        header = table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)  # Material Code
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)  # Order Qty & Deadline
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)  # Confidence Score
        header.setSectionResizeMode(3, QHeaderView.Stretch)  # Left explanation column
        header.setSectionResizeMode(4, QHeaderView.Stretch)  # Right explanation column
        
        # BATCH POPULATE: Create all items first, then insert efficiently
        items_to_insert = []
        for i, result in enumerate(optimized_results):
            # Create items with proper text alignment
            material_item = QTableWidgetItem(str(result['Material Code']))
            material_item.setTextAlignment(Qt.AlignCenter)
            items_to_insert.append((i, 0, material_item))
            
            forecast_item = QTableWidgetItem(str(result['Order Qty & Deadline']))
            forecast_item.setTextAlignment(Qt.AlignCenter)
            items_to_insert.append((i, 1, forecast_item))
            
            confidence_item = QTableWidgetItem(f"{result['Confidence Score']:.1f}%")
            confidence_item.setTextAlignment(Qt.AlignCenter)
            items_to_insert.append((i, 2, confidence_item))
            
            # For explanation columns, ensure proper text alignment for wrapping
            left_explanation_item = QTableWidgetItem(result['Left Explanation'])
            left_explanation_item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
            items_to_insert.append((i, 3, left_explanation_item))
            
            right_explanation_item = QTableWidgetItem(result['Right Explanation'])
            right_explanation_item.setTextAlignment(Qt.AlignLeft | Qt.AlignTop)
            items_to_insert.append((i, 4, right_explanation_item))
        
        # Batch insert all items at once (more efficient than individual setItem calls)
        for row, col, item in items_to_insert:
            table.setItem(row, col, item)
        
        # Simple one-time column resize (no expensive height calculations)
        table.resizeColumnsToContents()
        
        # Set table size policies for proper display
        table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        table.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        table.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        
        # Set minimum sizes to ensure visibility
        table.setMinimumHeight(600)
        table.setMinimumWidth(1200)  # Increased width for 5 columns
        
        layout.addWidget(table)