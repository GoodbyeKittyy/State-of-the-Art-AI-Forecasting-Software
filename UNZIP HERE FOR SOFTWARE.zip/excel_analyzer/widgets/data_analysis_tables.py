from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, 
                            QTableWidgetItem, QLabel, QHeaderView)
from PyQt5.QtCore import Qt
import pandas as pd

class DataTableWidget(QWidget):
    def __init__(self, title, material_codes, source_data, show_financial=False, show_classification_totals=False):
        super().__init__()
        self.title = title
        self.material_codes = material_codes
        self.source_data = source_data
        self.show_financial = show_financial
        self.show_classification_totals = show_classification_totals
        self.init_ui()
    
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(3)
        main_layout.setContentsMargins(3, 3, 3, 3)

        if self.show_classification_totals:
            top_layout = QHBoxLayout()
            title_label = QLabel(f"{self.title} ({len(self.material_codes)} items)")
            title_label.setStyleSheet("font-size: 28px; font-weight: bold;")
            top_layout.addWidget(title_label)
            top_layout.addStretch()
            main_layout.addLayout(top_layout)
            
            tables_layout = QHBoxLayout()
            self.table = QTableWidget()
            self.populate_table()
            tables_layout.addWidget(self.table, 3)
            
            self.classification_table = QTableWidget()
            self.populate_classification_table()
            
            right_container = QWidget()
            right_layout = QHBoxLayout(right_container)
            right_layout.setContentsMargins(0, 0, 0, 0)
            right_layout.addWidget(self.classification_table)
            right_layout.addStretch()
            tables_layout.addWidget(right_container, 2)
            main_layout.addLayout(tables_layout)
        else:
            title_label = QLabel(f"{self.title} ({len(self.material_codes)} items)")
            title_label.setStyleSheet("font-size: 28px; font-weight: bold;")
            main_layout.addWidget(title_label)
            self.table = QTableWidget()
            self.populate_table()
            main_layout.addWidget(self.table)
        
        self.setLayout(main_layout)
    
    def populate_table(self):
        if not self.material_codes:
            self.table.setRowCount(1)
            self.table.setColumnCount(1)
            self.table.setItem(0, 0, QTableWidgetItem("No data available"))
            return

        # Sort material codes in ascending order
        self.material_codes = sorted(self.material_codes, key=lambda x: str(x))
        
        historical_data = self.source_data.get('Historical Usage', pd.DataFrame())
        financial_data = self.source_data.get('Financial Extra Cost Data', pd.DataFrame())
        
        if self.show_financial:
            extra_cost_col = self._find_column(financial_data, ['Extra Cost', 'Expedited', 'Write-Off', 'Cost'])
            classification_col = self._find_column(financial_data, ['Classification'])
            qty_col = self._find_column(financial_data, ['Qty'])
            
            grouped_data = {}
            for material_code in self.material_codes:
                financial_rows = financial_data[financial_data['Material Code'] == material_code]
                if not financial_rows.empty:
                    for _, row in financial_rows.iterrows():
                        classification = 'Unknown'
                        if classification_col:
                            classification = row[classification_col] if pd.notna(row[classification_col]) else 'Unknown'
                        
                        key = (material_code, classification)
                        quantity = self._get_numeric_value(row, qty_col)
                        extra_cost = self._get_numeric_value(row, extra_cost_col)
                        
                        if key not in grouped_data:
                            grouped_data[key] = {
                                'quantity': quantity,
                                'extra_cost': extra_cost,
                                'classification': classification
                            }
                        else:
                            grouped_data[key]['quantity'] += quantity
                            grouped_data[key]['extra_cost'] += extra_cost
            
            self._create_financial_table(grouped_data, historical_data)
        else:
            self._create_basic_table(historical_data)
        
        self._adjust_column_widths()
    
    def _find_column(self, dataframe, possible_names):
        """Find a column in dataframe that matches any of possible names"""
        for col in dataframe.columns:
            if any(name in str(col) for name in possible_names):
                return col
        return None
    
    def _get_numeric_value(self, row, column_name, default=0):
        """Get numeric value from row column with error handling"""
        if not column_name or column_name not in row:
            return default
        
        try:
            return float(row[column_name]) if pd.notna(row[column_name]) else default
        except (ValueError, TypeError):
            return default
    
    def _create_financial_table(self, grouped_data, historical_data):
        """Create table with financial data"""
        self.table.setRowCount(len(grouped_data))
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(['Material Code', 'Material Description', 
                                        'Classification', 'Quantity', 'Extra Cost'])
        
        material_descriptions = self._get_material_descriptions(historical_data)
        
        for i, ((material_code, classification), data) in enumerate(grouped_data.items()):
            self.table.setItem(i, 0, QTableWidgetItem(str(material_code)))
            desc = material_descriptions.get(material_code, 'N/A')
            self.table.setItem(i, 1, QTableWidgetItem(str(desc)))
            self.table.setItem(i, 2, QTableWidgetItem(str(classification)))
            self.table.setItem(i, 3, QTableWidgetItem(f"{data['quantity']:,.0f}"))
            self.table.setItem(i, 4, QTableWidgetItem(f"${data['extra_cost']:,.2f}"))
    
    def _create_basic_table(self, historical_data):
        """Create basic table with material codes and descriptions"""
        self.table.setRowCount(len(self.material_codes))
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(['Material Code', 'Material Description'])
        
        for i, material_code in enumerate(self.material_codes):
            self.table.setItem(i, 0, QTableWidgetItem(str(material_code)))
            
            if not historical_data.empty:
                material_row = historical_data[historical_data['Material Code'] == material_code]
                if not material_row.empty:
                    desc = material_row['Material Description'].iloc[0] if 'Material Description' in material_row.columns else 'N/A'
                    self.table.setItem(i, 1, QTableWidgetItem(str(desc)))
                else:
                    self.table.setItem(i, 1, QTableWidgetItem('N/A'))
    
    def _get_material_descriptions(self, historical_data):
        """Get material descriptions from historical data"""
        descriptions = {}
        if not historical_data.empty:
            for _, row in historical_data.iterrows():
                material_code = row['Material Code']
                if 'Material Description' in row:
                    descriptions[material_code] = row['Material Description']
        return descriptions
    
    def _adjust_column_widths(self):
        """Adjust table column widths to fit content"""
        header = self.table.horizontalHeader()
        for i in range(self.table.columnCount()):
            header.setSectionResizeMode(i, QHeaderView.ResizeToContents)
    
    def populate_classification_table(self):
        """Populate the classification totals table"""
        financial_data = self.source_data.get('Financial Extra Cost Data', pd.DataFrame())
        classification_col = self._find_column(financial_data, ['Classification'])
        extra_cost_col = self._find_column(financial_data, ['Extra Cost', 'Expedited', 'Write-Off', 'Cost'])
        
        classification_totals = {}
        
        # Process ALL rows for each material code, not just the first one
        for material_code in self.material_codes:
            financial_rows = financial_data[financial_data['Material Code'] == material_code]
            
            # Iterate through ALL rows for this material code
            for _, row in financial_rows.iterrows():
                classification = 'Unknown'
                if classification_col:
                    classification = row[classification_col] if pd.notna(row[classification_col]) else 'Unknown'
                
                extra_cost = self._get_numeric_value(row, extra_cost_col)
                
                if classification not in classification_totals:
                    classification_totals[classification] = 0.0
                classification_totals[classification] += extra_cost
        
        self._create_classification_table(classification_totals)
    
    def _create_classification_table(self, classification_totals):
        """Create the classification totals table"""
        self.classification_table.setRowCount(len(classification_totals))
        self.classification_table.setColumnCount(2)
        self.classification_table.setHorizontalHeaderLabels(['Classification', 'Total Cost'])
        
        sorted_classifications = sorted(classification_totals.items(), key=lambda x: x[1], reverse=True)
        
        for i, (classification, total_cost) in enumerate(sorted_classifications):
            self.classification_table.setItem(i, 0, QTableWidgetItem(str(classification)))
            self.classification_table.setItem(i, 1, QTableWidgetItem(f"${total_cost:,.2f}"))
        
        header = self.classification_table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.Stretch)
        header.setSectionResizeMode(1, QHeaderView.ResizeToContents)