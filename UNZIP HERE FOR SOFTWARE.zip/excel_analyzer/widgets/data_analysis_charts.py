from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

class ChartWidget(QWidget):
    """Custom widget for displaying various types of charts"""
    
    # Centralized font size configuration
    FONT_SIZE_TITLE = 26
    FONT_SIZE_SUBTITLE = 26
    FONT_SIZE_LABEL = 13
    FONT_SIZE_TICK = 16
    FONT_SIZE_AUTOTEXT = 16

    def __init__(self, title, data, chart_type='bar', figsize=(10, 6)):
        super().__init__()
        self.title = title
        self.data = data
        self.chart_type = chart_type
        self.figsize = figsize
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        self.figure = Figure(figsize=self.figsize, tight_layout=True)
        self.canvas = FigureCanvas(self.figure)
        self.create_chart()
        layout.addWidget(self.canvas)
        self.setLayout(layout)
        
        if self.chart_type in ['pie']:
            self.setMinimumSize(900, 500)
        else:
            self.setMinimumSize(900, 600)
        
        self.setSizePolicy(self.canvas.sizePolicy())
    
    def create_chart(self):
        self.figure.clear()
        ax = self.figure.add_subplot(111)
        
        if self.chart_type == 'bar':
            self.create_bar_chart(ax)
        elif self.chart_type == 'pie':
            self.create_pie_chart(ax)
        elif self.chart_type == 'horizontal_bar':
            self.create_horizontal_bar_chart(ax)
        
        self.figure.tight_layout(pad=5.0)
        self.canvas.draw()
    
    def create_bar_chart(self, ax):
        if isinstance(self.data, dict):
            categories = list(self.data.keys())
            values = [len(self.data[cat]) if isinstance(self.data[cat], list) else self.data[cat] for cat in categories]
        else:
            categories = list(self.data.keys())
            values = list(self.data.values())
        
        colors = plt.cm.Set3(np.linspace(0, 1, len(categories)))
        bars = ax.bar(categories, values, color=colors)
        ax.set_title(self.title, fontsize=self.FONT_SIZE_TITLE, fontweight='bold', pad=20)
        ax.set_ylabel('Count', fontsize=self.FONT_SIZE_LABEL)
        
        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height + height*0.01,
                    f'{int(height)}', ha='center', va='bottom', 
                    fontsize=self.FONT_SIZE_TICK, fontweight='bold')
        
        plt.setp(ax.get_xticklabels(), rotation=45, ha='right', fontsize=self.FONT_SIZE_TICK)
        ax.grid(axis='y', alpha=0.3)
        
        # Improved dynamic Y-axis scaling
        if values:
            max_value = max(values)
            if max_value > 0:
                y_max = max_value * 1.2
                
                if y_max <= 10:
                    y_max = int(y_max) + 1
                elif y_max <= 100:
                    y_max = ((int(y_max) // 10) + 1) * 10
                elif y_max <= 1000:
                    y_max = ((int(y_max) // 50) + 1) * 50
                elif y_max <= 10000:
                    y_max = ((int(y_max) // 100) + 1) * 100
                else:
                    y_max = ((int(y_max) // 1000) + 1) * 1000
                
                ax.set_ylim(0, y_max)
    
    def create_pie_chart(self, ax):
        if isinstance(self.data, dict):
            categories = list(self.data.keys())
            values = [len(self.data[cat]) if isinstance(self.data[cat], list) else self.data[cat] for cat in categories]
        else:
            categories = list(self.data.keys())
            values = list(self.data.values())
        
        non_zero_data = [(cat, val) for cat, val in zip(categories, values) if val > 0]
        if non_zero_data:
            cats, vals = zip(*non_zero_data)
            colors = plt.cm.Set3(np.linspace(0, 1, len(cats)))
            wedges, texts, autotexts = ax.pie(
                vals, labels=cats,
                autopct=lambda pct: f'{pct:.1f}%\n({int(pct/100*sum(vals))})',
                colors=colors, startangle=90,
                textprops={'fontsize': self.FONT_SIZE_TICK}
            )
            for autotext in autotexts:
                autotext.set_color('black')
                autotext.set_fontweight('bold')
                autotext.set_fontsize(self.FONT_SIZE_AUTOTEXT)
            
            ax.set_title(self.title, fontsize=self.FONT_SIZE_SUBTITLE, fontweight='bold', pad=20)
    
    def create_horizontal_bar_chart(self, ax):
        if isinstance(self.data, dict):
            categories = list(self.data.keys())
            values = [len(self.data[cat]) if isinstance(self.data[cat], list) else self.data[cat] for cat in categories]
        else:
            categories = list(self.data.keys())
            values = list(self.data.values())
        
        colors = plt.cm.Set2(np.linspace(0, 1, len(categories)))
        bars = ax.barh(categories, values, color=colors)
        ax.set_title(self.title, fontsize=self.FONT_SIZE_TITLE, fontweight='bold', pad=20)
        ax.set_xlabel('Count', fontsize=self.FONT_SIZE_LABEL)
        
        for bar in bars:
            width = bar.get_width()
            ax.text(width + width*0.01, bar.get_y() + bar.get_height()/2.,
                    f'{int(width)}', ha='left', va='center',
                    fontsize=self.FONT_SIZE_TICK, fontweight='bold')
        
        ax.grid(axis='x', alpha=0.3)
        
        if values:
            max_value = max(values)
            if max_value > 0:
                x_max = max_value * 1.2
                
                if x_max <= 10:
                    x_max = int(x_max) + 1
                elif x_max <= 100:
                    x_max = ((int(x_max) // 10) + 1) * 10
                elif x_max <= 1000:
                    x_max = ((int(x_max) // 50) + 1) * 50
                elif x_max <= 10000:
                    x_max = ((int(x_max) // 100) + 1) * 100
                else:
                    x_max = ((int(x_max) // 1000) + 1) * 1000
                
                ax.set_xlim(0, x_max)