from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QFrame, QLabel, QTabWidget, 
                            QScrollArea, QGridLayout, QMessageBox)
from PyQt5.QtGui import QFont
from excel_analyzer.widgets.data_analysis_charts import ChartWidget
from excel_analyzer.widgets.data_analysis_tables import DataTableWidget




class ExploratoryDataAnalysisTab(QWidget):
    def __init__(self, analysis_results):
        super().__init__()
        self.analysis_results = analysis_results
        self.init_ui()
    
    def init_ui(self):
        main_layout = QVBoxLayout()
        
        # Summary section
        summary_frame = self._create_summary_frame()
        main_layout.addWidget(summary_frame)
        
        # Create tab widget for different views
        tab_widget = QTabWidget()
        tab_widget.setFont(QFont("Arial", 13))
        
        # Charts tab with scroll area
        charts_scroll = self._create_charts_scroll()
        tab_widget.addTab(charts_scroll, "Analysis Charts")
        
        # Detailed data tabs for each category
        self._create_category_tabs(tab_widget)
        
        
        main_layout.addWidget(tab_widget)
        self.setLayout(main_layout)
    
    def _has_forecast_data(self):
        """Check if required sheets for forecasting exist"""
        required_sheets = ["Historical Usage", "Historical Forecast", "Financial Standard Price"]
        sheets = self.analysis_results.get('sheets', {})
        return all(sheet in sheets for sheet in required_sheets)
    
    def _create_summary_frame(self):
        """Create the summary frame with key insights"""
        summary_frame = QFrame()
        summary_frame.setFrameStyle(QFrame.Box)
        summary_layout = QVBoxLayout()
        
        summary_title = QLabel("Material Analysis Summary")
        summary_title.setStyleSheet("font-size: 17px; font-weight: bold;")
        summary_layout.addWidget(summary_title)
        
        insights = self.analysis_results['insights']
        total_materials = self.analysis_results['total_materials']
        materials_with_usage = self.analysis_results['materials_with_usage']
        materials_no_usage = self.analysis_results['materials_no_usage']
        
        summary_text = f"""
        Total Materials Analyzed: {total_materials}
        Materials With No Usage (Last 12 Periods): {materials_no_usage}
        Materials With Usage (Last 12 Periods): {materials_with_usage}
        
        From Materials WITH Usage:
        • Materials With Usage AND No Supplier Records: {len(insights['Materials With Usage AND No Supplier Records'])}
        • Materials With Usage AND No Current Stock: {len(insights['Materials With Usage AND No Current Stock'])}
        • Materials With Usage AND Have Extra Costs: {len(insights['Materials With Usage AND Have Extra Costs'])}
        """
        
        summary_text_widget = QLabel(summary_text)
        summary_text_widget.setStyleSheet("font-size: 16px;")
        summary_layout.addWidget(summary_text_widget)
        summary_frame.setLayout(summary_layout)
        return summary_frame
    
    def _create_charts_scroll(self):
        """Create scroll area for charts"""
        charts_scroll = QScrollArea()
        charts_widget = QWidget()
        charts_layout = QVBoxLayout()
        
        self._create_charts(charts_layout, self.analysis_results['insights'])
        charts_widget.setLayout(charts_layout)
        charts_scroll.setWidget(charts_widget)
        charts_scroll.setWidgetResizable(True)
        charts_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        charts_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        return charts_scroll
    
    def _create_category_tabs(self, tab_widget):
        """Create tabs for each material category"""
        insights = self.analysis_results['insights']
        category_mappings = {
            'Materials With No Usage Last 12 Periods': ('Materials with No Usage (12M)', False),
            'Materials With Usage Last 12 Periods': ('Materials with Usage (12M)', False),
            'Materials With Usage AND No Supplier Records': ('Usage + No Supplier Records', False),
            'Materials With Usage AND No Current Stock': ('Usage + No Current Stock', False),
            'Materials With Usage AND Have Extra Costs': ('Usage + Have Extra Costs', True)
        }
        
        for insight_name, material_list in insights.items():
            if material_list and insight_name in category_mappings:
                tab_name, show_financial = category_mappings[insight_name]
                show_classification_totals = (insight_name == 'Materials With Usage AND Have Extra Costs')
                data_widget = DataTableWidget(
                    insight_name, 
                    material_list, 
                    self.analysis_results['sheets'],
                    show_financial=show_financial,
                    show_classification_totals=show_classification_totals
                )
                tab_widget.addTab(data_widget, f"{tab_name} ({len(material_list)})")
    
    def _create_charts(self, layout, insights):
        """Create all analysis charts"""
        spacing = 30
        
        # 1. Material Analysis Summary Bar Chart (FIRST CHART NOW)
        bar_chart_data = self._prepare_bar_chart_data(insights)
        bar_chart = ChartWidget("Material Analysis Summary", bar_chart_data, 'bar', (14, 8))
        layout.addWidget(bar_chart)
        layout.addSpacing(spacing)
        
        # 2. Side by side charts - Usage Distribution and Supplier Records
        pie_charts_layout = QGridLayout()
        pie_charts_widget = QWidget()
        
        # Usage vs No Usage Distribution
        usage_data = {
            'No Usage Last 12 Periods': insights['Materials With No Usage Last 12 Periods'],
            'With Usage Last 12 Periods': insights['Materials With Usage Last 12 Periods']
        }
        usage_pie = ChartWidget("Usage Distribution (Last 12 Periods)", usage_data, 'pie', (8, 8))
        pie_charts_layout.addWidget(usage_pie, 0, 0)
        
        # Supplier Records for Materials with Usage
        supplier_data = {
            'Usage + No Supplier Records': insights['Materials With Usage AND No Supplier Records'],
            'Usage + Have Supplier Records': list(set(insights['Materials With Usage Last 12 Periods']) - 
                                            set(insights['Materials With Usage AND No Supplier Records']))
        }
        supplier_pie = ChartWidget("Supplier Records (Materials with Usage)", supplier_data, 'pie', (8, 8))
        pie_charts_layout.addWidget(supplier_pie, 0, 1)
        
        pie_charts_widget.setLayout(pie_charts_layout)
        layout.addWidget(pie_charts_widget)
        layout.addSpacing(spacing)
        
        # 3. Side by side charts - Stock Status and Extra Costs
        pie_charts_layout2 = QGridLayout()
        pie_charts_widget2 = QWidget()
        
        # Stock Status for Materials with Usage
        stock_data = {
            'Usage + No Current Stock': insights['Materials With Usage AND No Current Stock'],
            'Usage + Have Current Stock': list(set(insights['Materials With Usage Last 12 Periods']) - 
                                            set(insights['Materials With Usage AND No Current Stock']))
        }
        stock_pie = ChartWidget("Stock Status (Materials with Usage)", stock_data, 'pie', (8, 8))
        pie_charts_layout2.addWidget(stock_pie, 0, 0)
        
        # Extra Costs for Materials with Usage
        cost_data = {
            'Usage + Have Extra Costs': insights['Materials With Usage AND Have Extra Costs'],
            'Usage + No Extra Costs': list(set(insights['Materials With Usage Last 12 Periods']) - 
                                    set(insights['Materials With Usage AND Have Extra Costs']))
        }
        cost_pie = ChartWidget("Extra Costs (Materials with Usage)", cost_data, 'pie', (8, 8))
        pie_charts_layout2.addWidget(cost_pie, 0, 1)
        
        pie_charts_widget2.setLayout(pie_charts_layout2)
        layout.addWidget(pie_charts_widget2)
        layout.addSpacing(spacing)
        
        # 4. Financial Analysis Charts (if financial data exists)
        if self.analysis_results['financial_analysis']:
            self._create_financial_charts(layout, spacing)

    def _prepare_main_overview_data(self, insights):
        """Prepare data for main overview pie chart"""
        materials_with_usage = set(insights['Materials With Usage Last 12 Periods'])
        materials_no_supplier = set(insights['Materials With Usage AND No Supplier Records'])
        materials_no_stock = set(insights['Materials With Usage AND No Current Stock'])
        materials_extra_costs = set(insights['Materials With Usage AND Have Extra Costs'])
        
        materials_complete = materials_with_usage - materials_no_supplier - materials_no_stock - materials_extra_costs
        
        return {
            'No Usage Last 12 Periods': insights['Materials With No Usage Last 12 Periods'],
            'Usage + No Supplier Records': insights['Materials With Usage AND No Supplier Records'],
            'Usage + No Current Stock': insights['Materials With Usage AND No Current Stock'],  
            'Usage + Have Extra Costs': insights['Materials With Usage AND Have Extra Costs'],
            'Usage + Complete Records': list(materials_complete)
        }
    
    def _create_pie_charts_grid(self, layout, insights, spacing):
        """Create grid of pie charts"""
        pie_charts_layout = QGridLayout()
        pie_charts_widget = QWidget()
        
        # Usage vs No Usage Distribution
        usage_data = {
            'No Usage Last 12 Periods': insights['Materials With No Usage Last 12 Periods'],
            'With Usage Last 12 Periods': insights['Materials With Usage Last 12 Periods']
        }
        usage_pie = ChartWidget("Usage Distribution (Last 12 Periods)", usage_data, 'pie', (8, 8))
        pie_charts_layout.addWidget(usage_pie, 0, 0)
        
        # Supplier Records for Materials with Usage
        supplier_data = {
            'Usage + No Supplier Records': insights['Materials With Usage AND No Supplier Records'],
            'Usage + Have Supplier Records': list(set(insights['Materials With Usage Last 12 Periods']) - 
                                              set(insights['Materials With Usage AND No Supplier Records']))
        }
        supplier_pie = ChartWidget("Supplier Records (Materials with Usage)", supplier_data, 'pie', (8, 8))
        pie_charts_layout.addWidget(supplier_pie, 0, 1)
        
        # Stock Status for Materials with Usage
        stock_data = {
            'Usage + No Current Stock': insights['Materials With Usage AND No Current Stock'],
            'Usage + Have Current Stock': list(set(insights['Materials With Usage Last 12 Periods']) - 
                                            set(insights['Materials With Usage AND No Current Stock']))
        }
        stock_pie = ChartWidget("Stock Status (Materials with Usage)", stock_data, 'pie', (8, 8))
        pie_charts_layout.addWidget(stock_pie, 1, 0)
        
        # Extra Costs for Materials with Usage
        cost_data = {
            'Usage + Have Extra Costs': insights['Materials With Usage AND Have Extra Costs'],
            'Usage + No Extra Costs': list(set(insights['Materials With Usage Last 12 Periods']) - 
                                    set(insights['Materials With Usage AND Have Extra Costs']))
        }
        cost_pie = ChartWidget("Extra Costs (Materials with Usage)", cost_data, 'pie', (8, 8))
        pie_charts_layout.addWidget(cost_pie, 1, 1)
        
        pie_charts_widget.setLayout(pie_charts_layout)
        layout.addWidget(pie_charts_widget)
        layout.addSpacing(spacing)
    
    def _prepare_bar_chart_data(self, insights):
        """Prepare data for bar charts"""
        return {
            'Total Materials': len(insights['Total Materials Analyzed']),
            'No Usage (12M)': len(insights['Materials With No Usage Last 12 Periods']),
            'With Usage (12M)': len(insights['Materials With Usage Last 12 Periods']),
            'Usage + No Supplier': len(insights['Materials With Usage AND No Supplier Records']),
            'Usage + No Stock': len(insights['Materials With Usage AND No Current Stock']),
            'Usage + Extra Costs': len(insights['Materials With Usage AND Have Extra Costs'])
        }
    
    def _create_financial_charts(self, layout, spacing):
        """Create financial analysis charts"""
        financial_analysis = self.analysis_results['financial_analysis']
        
        # Classification costs analysis
        classification_costs = {}
        material_costs = {}

        for material_code, data in financial_analysis.items():
            classification = data['classification']
            cost = data['extra_cost']
            
            # Count materials by classification instead of summing costs
            if classification not in classification_costs:
                classification_costs[classification] = 0
            classification_costs[classification] += 1
            material_costs[material_code] = cost

        # Classification costs pie chart
        if classification_costs:
            classification_pie = ChartWidget("Extra Costs by Classification", 
                                        classification_costs, 'horizontal_bar', (10, 8))
            layout.addWidget(classification_pie)
            layout.addSpacing(spacing)
        
        # Top materials by cost (limit to top 15 for readability)
        if material_costs:
            top_materials = dict(sorted(material_costs.items(), 
                                    key=lambda x: x[1], reverse=True)[:15])
            top_materials_chart = ChartWidget("Top Materials by Extra Cost", 
                                        top_materials, 'horizontal_bar', (12, 10))
            layout.addWidget(top_materials_chart)
            layout.addSpacing(spacing)

    def _prepare_summary_stats(self, insights):
        """Prepare data for summary statistics chart"""
        return {
            'Total Materials': len(insights['Total Materials Analyzed']),
            'Active (12M)': len(insights['Materials With Usage Last 12 Periods']),
            'Inactive (12M)': len(insights['Materials With No Usage Last 12 Periods']),
            'Missing Suppliers': len(insights['Materials With Usage AND No Supplier Records']),
            'Missing Stock': len(insights['Materials With Usage AND No Current Stock']),
            'With Extra Costs': len(insights['Materials With Usage AND Have Extra Costs'])
        }