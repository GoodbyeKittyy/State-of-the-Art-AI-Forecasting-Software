import os
import pandas as pd
import numpy as np
import warnings
import subprocess
import sys
import time
import torch
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QTabWidget, QScrollArea,
                             QLabel, QTableWidget, QTableWidgetItem, QHeaderView)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed

from ..forecast_worker import ForecastWorker
from .forecast_tables import ForecastTables
from .forecast_charts import ForecastCharts

warnings.filterwarnings('ignore')

class ForecastCostSavingsTab(QWidget):
    def __init__(self, analysis_results):
        super().__init__()
        self._start_time = time.time()
        self.analysis_results = analysis_results
        self.forecast_worker = ForecastWorker()
        self.forecast_tables = ForecastTables()
        self.forecast_charts = ForecastCharts()
        self.init_ui()

    def init_ui(self):
        def format_elapsed_time(seconds):
            days, remainder = divmod(int(seconds), 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, secs = divmod(remainder, 60)
            return f"{days} days {hours} hrs {minutes} mins {secs} secs"

        layout = QVBoxLayout()
        
        # Create tab widget for the three sub-tabs
        tab_widget = QTabWidget()
        tab_widget.setFont(QFont("Arial", 13))
        
        # Sub-tab 1: AI Forecast Predictions
        self.create_ai_forecast_tab(tab_widget)
        
        # Sub-tab 2: Forecast Accuracy Comparison
        self.create_accuracy_comparison_tab(tab_widget)
        
        # Sub-tab 3: Cost Savings Analysis
        self.create_cost_savings_tab(tab_widget)
        
        layout.addWidget(tab_widget)
        self.setLayout(layout)
        elapsed = time.time() - self._start_time
        print(f"✅ Total time: {format_elapsed_time(elapsed)}")

    def create_ai_forecast_tab(self, tab_widget):
        """Create tab showing AI forecast predictions"""
        scroll = QScrollArea()
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Get historical data
        historical_usage = self.analysis_results['sheets']['Historical Usage']
        
        # Get period columns (YYYYMXX format)
        usage_periods = self.forecast_worker._get_period_columns(historical_usage)
        
        if len(usage_periods) == 0:
            error_label = QLabel("No valid period columns found in Historical Usage data")
            layout.addWidget(error_label)
            widget.setLayout(layout)
            scroll.setWidget(widget)
            scroll.setWidgetResizable(True)
            tab_widget.addTab(scroll, "TabPFN AI Forecast Predictions (Training Phase)")
            return
        
        # Generate forecasts for each material code
        forecasts = self.forecast_worker._generate_tabpfn_forecasts(historical_usage, usage_periods)
        
        # Create table
        table = self.forecast_tables.create_ai_forecast_table(forecasts, self.forecast_worker._get_next_period(usage_periods[-1]))
        layout.addWidget(table)
        
        # Add info about the forecasting method
        if self.forecast_worker.tabpfn_model:
            model_info = "✓ TabPFN Time Series AI Forecast Successfully Loaded"
            method_details = (
                "• Model: TabPFN Regressor for Time Series Forecasting\n"
                "• Uses transformer-based in-context learning for predictions\n"
                "• Specifically designed for small tabular datasets\n"
                "• Requires no hyperparameter tuning\n"
                "• Competitive with state-of-the-art methods\n"
                "• Handles time series data through feature engineering"
            )
        else:
            model_info = "⚠ TabPFN Model Loading Failed - Using Statistical Fallback"
            method_details = (
                "• Attempted to load TabPFN from: pip install tabpfn\n"
                "• Using enhanced statistical forecasting methods instead\n"
                "• Includes exponential smoothing and trend analysis\n"
                "• Provides robust fallback forecasting capabilities"
            )
        
        info_label = QLabel(f"{model_info}\n{method_details}")
        info_label.setStyleSheet("font-size: 22px; padding: 10px; background-color: #f0f0f0; border-radius: 5px;")
        layout.addWidget(info_label)
        
        widget.setLayout(layout)
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        tab_widget.addTab(scroll, "TabPFN AI Forecast Predictions")

    def create_accuracy_comparison_tab(self, tab_widget):
        """Create tab comparing forecast accuracies using existing periods only"""
        scroll = QScrollArea()
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Get data
        historical_usage = self.analysis_results['sheets']['Historical Usage']
        historical_forecast = self.analysis_results['sheets']['Historical Forecast']
        
        # Get period columns
        usage_periods = self.forecast_worker._get_period_columns(historical_usage)
        forecast_periods = self.forecast_worker._get_period_columns(historical_forecast)
        
        if len(usage_periods) == 0 or len(forecast_periods) == 0:
            error_label = QLabel("Insufficient period data for accuracy comparison")
            layout.addWidget(error_label)
            widget.setLayout(layout)
            scroll.setWidget(widget)
            scroll.setWidgetResizable(True)
            tab_widget.addTab(scroll, "Accuracy Comparison")
            return
        
        # Get common periods and material codes
        common_periods = sorted(list(set(usage_periods).intersection(set(forecast_periods))))
        material_codes = list(set(historical_usage['Material Code']).intersection(
                      set(historical_forecast['Material Code'])))
        
        if len(common_periods) < 2:
            error_label = QLabel("Need at least 2 common periods for accuracy comparison")
            layout.addWidget(error_label)
            widget.setLayout(layout)
            scroll.setWidget(widget)
            scroll.setWidgetResizable(True)
            tab_widget.addTab(scroll, "Accuracy Comparison")
            return
        
        # Calculate accuracies using existing periods only
        results = self.forecast_worker._calculate_existing_period_accuracy(
            historical_usage, historical_forecast, 
            material_codes, common_periods
        )
        
        # Create table
        table = self.forecast_tables.create_accuracy_comparison_table(results, self.forecast_worker.tabpfn_model is not None)
        layout.addWidget(table)
        
        # Add interpretation info
        model_status = "TabPFN AI" if self.forecast_worker.tabpfn_model else "Statistical Fallback"
        info_label = QLabel(
            f"MAPE (Mean Absolute Percentage Error) Interpretation:\n"
            f"• Lower values indicate better accuracy\n"
            f"• Improvement shows how much better (green) or worse (red) the {model_status} forecast is\n"
            f"• Ideal MAPE is close to 0%\n"
            f"• Analysis uses existing periods only (no future forecasts)\n"
            f"• Current model: {model_status}"
        )
        info_label.setStyleSheet("font-size: 22px; padding: 10px;")
        layout.addWidget(info_label)
        
        # Add summary charts
        if results:
            fig = self.forecast_charts.create_summary_charts(results, model_status)
            if fig:
                canvas = FigureCanvas(fig)
                canvas.setMinimumSize(1000, 1600)
                layout.addWidget(canvas)
        
        widget.setLayout(layout)
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        tab_widget.addTab(scroll, "Accuracy Comparison")

    def create_cost_savings_tab(self, tab_widget):
        """Create tab showing cost variance analysis using latest period only - OPTIMIZED"""
        scroll = QScrollArea()
        widget = QWidget()
        layout = QVBoxLayout()
        
        # Get required data
        historical_usage = self.analysis_results['sheets']['Historical Usage']
        historical_forecast = self.analysis_results['sheets']['Historical Forecast']
        financial_data = self.analysis_results['sheets']['Financial Standard Price']
        
        # Get material codes and standard prices
        material_prices = {}
        for _, row in financial_data.iterrows():
            material_prices[row['Material Code']] = row['Standard Price']
        
        # Get common material codes
        material_codes = list(set(historical_usage['Material Code']).intersection(
                    set(historical_forecast['Material Code']).intersection(
                    set(material_prices.keys()))))
        
        if len(material_codes) == 0:
            error_label = QLabel("No common material codes found across all datasets")
            layout.addWidget(error_label)
            widget.setLayout(layout)
            scroll.setWidget(widget)
            scroll.setWidgetResizable(True)
            tab_widget.addTab(scroll, "Cost Variance Analysis")
            return
        
        # Get period columns
        usage_periods = self.forecast_worker._get_period_columns(historical_usage)
        forecast_periods = self.forecast_worker._get_period_columns(historical_forecast)
        
        if len(usage_periods) == 0 or len(forecast_periods) == 0:
            error_label = QLabel("No valid period columns found")
            layout.addWidget(error_label)
            widget.setLayout(layout)
            scroll.setWidget(widget)
            scroll.setWidgetResizable(True)
            tab_widget.addTab(scroll, "Cost Variance Analysis")
            return
        
        # Get common periods
        common_periods = sorted(list(set(usage_periods).intersection(set(forecast_periods))))
        
        if len(common_periods) == 0:
            error_label = QLabel("No common periods found between usage and forecast data")
            layout.addWidget(error_label)
            widget.setLayout(layout)
            scroll.setWidget(widget)
            scroll.setWidgetResizable(True)
            tab_widget.addTab(scroll, "Cost Variance Analysis")
            return
        
        # Use the latest available period for comparison
        latest_period = common_periods[-1]
        print(f"TabPFN vs Historical Cost Analysis Completed")
        
        # Generate AI forecasts for the latest period only
        ai_forecasts_latest = self.forecast_worker._generate_latest_period_forecasts(
            historical_usage, material_codes, common_periods, latest_period
        )
        
        # Calculate cost variance for the latest period - PARALLEL
        def process_cost_variance(material_code):
            try:
                # Get latest period actual usage
                usage_row = historical_usage[historical_usage['Material Code'] == material_code]
                if len(usage_row) == 0:
                    return None
                latest_usage = usage_row[latest_period].values[0]
                if pd.isna(latest_usage):
                    return None
                
                # Get latest period historical forecast
                forecast_row = historical_forecast[historical_forecast['Material Code'] == material_code]
                if len(forecast_row) == 0:
                    return None
                latest_forecast = forecast_row[latest_period].values[0]
                if pd.isna(latest_forecast):
                    return None
                
                # Get AI forecast
                ai_forecast = ai_forecasts_latest.get(material_code, 0.0)
                
                # Calculate cost variances
                price = material_prices[material_code]
                hist_cost_variance = abs(latest_forecast - latest_usage) * price
                ai_cost_variance = abs(ai_forecast - latest_usage) * price
                
                # Determine better forecasting method
                if hist_cost_variance < ai_cost_variance:
                    better_method = "Historical Forecast"
                elif ai_cost_variance < hist_cost_variance:
                    better_method = "TabPFN AI Forecast" if self.forecast_worker.tabpfn_model else "Statistical Fallback Forecast"
                else:
                    better_method = "Equal Performance"
                
                return {
                    'Material Code': material_code,
                    'Historical Forecast': latest_forecast,
                    'AI Forecast': ai_forecast,
                    'Actual Usage': latest_usage,
                    'Standard Price': price,
                    'Historical Forecast Cost Variance': hist_cost_variance,
                    'AI Forecast Cost Variance': ai_cost_variance,
                    'Better Forecasting Method': better_method
                }
            except Exception as e:
                print(f"Error processing cost variance for material {material_code}: {e}")
                return None

        # Process in parallel
        variance_data = []
        import multiprocessing
        max_workers = multiprocessing.cpu_count()

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_material = {executor.submit(process_cost_variance, material_code): material_code for material_code in material_codes}
            
            for future in as_completed(future_to_material):
                try:
                    result = future.result()
                    if result is not None:
                        variance_data.append(result)
                except Exception as e:
                    material_code = future_to_material[future]
                    print(f"Error getting cost variance result for material {material_code}: {e}")
        
        # Create table
        table = self.forecast_tables.create_cost_variance_table(variance_data, self.forecast_worker.tabpfn_model is not None)
        layout.addWidget(table)
        
        # Add summary info
        if variance_data:
            total_hist_variance = sum(d['Historical Forecast Cost Variance'] for d in variance_data)
            total_ai_variance = sum(d['AI Forecast Cost Variance'] for d in variance_data)
            total_variance_improvement = total_hist_variance - total_ai_variance
            
            # Count better performance
            hist_better_count = sum(1 for d in variance_data if "Historical" in d['Better Forecasting Method'])
            ai_better_count = sum(1 for d in variance_data if ("TabPFN" in d['Better Forecasting Method'] or "Statistical" in d['Better Forecasting Method']))
            equal_count = sum(1 for d in variance_data if "Equal" in d['Better Forecasting Method'])
            
            model_status = "TabPFN AI" if self.forecast_worker.tabpfn_model else "Statistical Fallback"
            
            summary_label = QLabel(
                f"Cost Variance Analysis Summary:\n"
                f"Analysis Period: {latest_period}\n"
                f"Model Status: {model_status}\n\n"
                f"Total Historical Forecast Cost Variance: ${total_hist_variance:,.2f}\n"
                f"Total {model_status} Forecast Cost Variance: ${total_ai_variance:,.2f}\n"
                f"Total Variance Improvement: ${total_variance_improvement:,.2f}\n\n"
                f"Performance Comparison:\n"
                f"• Historical Forecast Better: {hist_better_count} materials\n"
                f"• {model_status} Forecast Better: {ai_better_count} materials\n"
                f"• Equal Performance: {equal_count} materials\n\n"
                f"Note: Lower cost variance indicates better forecasting accuracy"
            )
            
            summary_label.setStyleSheet("font-size: 22px; font-weight: bold; padding: 10px; background-color: #f0f0f0; border-radius: 5px;")
            layout.addWidget(summary_label)
        
        widget.setLayout(layout)
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        tab_widget.addTab(scroll, "Cost Variance Analysis")