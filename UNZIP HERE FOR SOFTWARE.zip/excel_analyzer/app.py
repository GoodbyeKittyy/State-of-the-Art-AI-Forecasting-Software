import os
import sys
import subprocess
from PyQt5.QtWidgets import (QDialog, QMainWindow, QWidget, QVBoxLayout, QFrame, 
                            QLabel, QPushButton, QFileDialog, QProgressBar,
                            QTabWidget, QMessageBox, QTableWidget, QSpinBox, QHBoxLayout, QScrollArea)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont
from excel_analyzer.data_analysis_worker import DataAnalysisWorker
from excel_analyzer.widgets.data_analysis_charts import ChartWidget
from excel_analyzer.widgets.data_analysis_tab import ExploratoryDataAnalysisTab
from excel_analyzer.widgets.forecast_tab import ForecastCostSavingsTab
from excel_analyzer.widgets.dynamic_learning_tab import DynamicLearningTab  
from excel_analyzer.export_results import export_results_with_summary, export_eda_only
import time
from datetime import datetime




# Moved EDAOnlyExportWorker outside the main class
class EDAOnlyExportWorker(QThread):
    """Worker thread for exporting ONLY EDA results"""
    finished = pyqtSignal(str)  # Success message
    error = pyqtSignal(str)     # Error message
    
    def __init__(self, save_path, eda_tab_widget, forecast_tab_widget=None, dynamic_learning_tab_widget=None):
        super().__init__()
        self.save_path = save_path
        self.eda_tab_widget = eda_tab_widget
        self.forecast_tab_widget = forecast_tab_widget
        self.dynamic_learning_tab_widget = dynamic_learning_tab_widget
    
    def run(self):
        try:
            print(f"Starting EDA-only export to: {self.save_path}")
            
            # Use the existing export_eda_only function from export_results.py
            from excel_analyzer.export_results import export_eda_only
            
            # Call the EDA-only export function with all three widgets
            export_eda_only(self.save_path, self.eda_tab_widget, self.forecast_tab_widget, self.dynamic_learning_tab_widget)
            
            # Update success message to reflect all three data sources
            message = f"Analysis results successfully exported to:\n{self.save_path}\n\n"
            message += f"Contains data tables and charts from:\n"
            message += f"• Exploratory Data Analysis\n"
            if self.forecast_tab_widget:
                message += f"• Forecasts & Cost Savings Analysis\n"
            if self.dynamic_learning_tab_widget:
                message += f"• Dynamic Learning & Optimization\n"
            
            self.finished.emit(message)
                            
        except Exception as e:
            print(f"EDA export error: {e}")
            import traceback
            traceback.print_exc()
            
            self.error.emit(f"Failed to export analysis results:\n{str(e)}\n\n"
                        "If you are overwriting an existing file, close the file first!")


# Fixed ExportWorker class
class ExportWorker(QThread):
    """Worker thread for exporting results to avoid UI freezing"""
    finished = pyqtSignal(str)  # Success message
    error = pyqtSignal(str)     # Error message
    
    def __init__(self, save_path, tabs_data, main_app):
        super().__init__()
        self.save_path = save_path
        self.tabs_data = tabs_data
        self.main_app = main_app
    
    def run(self):
        try:
            print(f"Starting export to: {self.save_path}")  # Debug
            
            # Extract all tables and charts from tabs using the enhanced method
            all_tables = self.main_app.extract_tables_from_results()
            print(f"Extracted {len(all_tables)} tables")  # Debug
            
            all_charts = {}
            
            # Extract charts using existing method - with better error handling
            for tab_name, tab_widget in self.tabs_data.items():
                try:
                    tab_tables, tab_charts = self.extract_from_tab(tab_widget, tab_name)
                    all_charts.update(tab_charts)
                    print(f"Processed tab {tab_name}: {len(tab_charts)} charts")  # Debug
                except Exception as tab_error:
                    print(f"Error processing tab {tab_name}: {tab_error}")
                    continue
            
            print(f"Total extracted: {len(all_tables)} tables, {len(all_charts)} charts")
            
            # Check if we have any data to export
            if not all_tables and not all_charts:
                self.error.emit("No data found to export. Please ensure the analysis has been completed successfully.")
                return
            
            # Export with summary - simplified call
            try:
                export_results_with_summary(self.save_path, all_tables, all_charts, None)
                print("Export completed successfully")  # Debug
            except Exception as export_error:
                print(f"Export function error: {export_error}")
                raise export_error
            
            self.finished.emit(f"Results successfully exported to:\n{self.save_path}\n\n"
                             f"Exported {len(all_tables)} data tables and {len(all_charts)} charts.")
                             
        except Exception as e:
            print(f"Export worker error: {e}")  # Debug
            import traceback
            traceback.print_exc()  # Print full traceback for debugging
            
            self.error.emit(f"Failed to export results:\n{str(e)}\n\n"
                          "Please check the console output for more details.")
    
    def extract_from_tab(self, tab_widget, tab_name):
        """Extract tables and charts from a tab widget - with better error handling"""
        tables = {}
        charts = {}
        
        try:
            # Check if tab_widget is None
            if tab_widget is None:
                print(f"Warning: Tab widget for {tab_name} is None")
                return tables, charts
            
            # Check if this tab has sub-tabs (QTabWidget)
            if isinstance(tab_widget, QTabWidget) and tab_widget.count() > 0:
                # This is a tab widget with sub-tabs
                for i in range(tab_widget.count()):
                    try:
                        sub_tab = tab_widget.widget(i)
                        sub_tab_name = tab_widget.tabText(i)
                        full_name = f"{tab_name}_{sub_tab_name}"
                        
                        sub_tables, sub_charts = self.extract_from_widget(sub_tab, full_name)
                        tables.update(sub_tables)
                        charts.update(sub_charts)
                    except Exception as subtab_error:
                        print(f"Error processing subtab {i} in {tab_name}: {subtab_error}")
                        continue
            else:
                # This is a regular widget, extract directly
                sub_tables, sub_charts = self.extract_from_widget(tab_widget, tab_name)
                tables.update(sub_tables)
                charts.update(sub_charts)
        
        except Exception as e:
            print(f"Error extracting from tab {tab_name}: {e}")
        
        return tables, charts
    
    def extract_from_widget(self, widget, prefix):
        """Extract tables and charts from a widget - with better error handling"""
        tables = {}
        charts = {}
        
        if widget is None:
            return tables, charts
        
        try:
            # Look for results attribute
            if hasattr(widget, 'results') and widget.results:
                try:
                    result_tables, result_charts = self.extract_from_results(widget.results, prefix)
                    tables.update(result_tables)
                    charts.update(result_charts)
                except Exception as results_error:
                    print(f"Error extracting results from {prefix}: {results_error}")
            
            # Look for ChartWidgets - safer approach
            try:
                chart_widgets = self.find_chart_widgets(widget)
                for i, chart_widget in enumerate(chart_widgets):
                    try:
                        if hasattr(chart_widget, 'figure') and chart_widget.figure:
                            chart_name = f"{prefix}_Chart_{i+1}"
                            charts[chart_name] = chart_widget.figure
                    except Exception as chart_error:
                        print(f"Error extracting chart {i} from {prefix}: {chart_error}")
                        continue
            except Exception as chart_widgets_error:
                print(f"Error finding chart widgets in {prefix}: {chart_widgets_error}")
            
            # Look for tables stored in the widget
            try:
                if hasattr(widget, 'tables') and widget.tables:
                    for name, table in widget.tables.items():
                        if table is not None:
                            table_name = f"{prefix}_{name}"
                            tables[table_name] = table
            except Exception as tables_error:
                print(f"Error extracting tables from {prefix}: {tables_error}")
            
            # Look for individual DataFrames in widget attributes - safer approach
            try:
                for attr_name in dir(widget):
                    if not attr_name.startswith('_'):
                        try:
                            attr_value = getattr(widget, attr_name, None)
                            if attr_value is not None and (hasattr(attr_value, 'to_dict') or 'DataFrame' in str(type(attr_value))):
                                table_name = f"{prefix}_{attr_name}"
                                tables[table_name] = attr_value
                        except Exception as attr_error:
                            # Skip problematic attributes
                            continue
            except Exception as attrs_error:
                print(f"Error checking attributes in {prefix}: {attrs_error}")
        
        except Exception as e:
            print(f"Error extracting from widget {prefix}: {e}")
        
        return tables, charts
    
    def extract_from_results(self, results, prefix):
        """Extract tables and charts from results dictionary - with better error handling"""
        tables = {}
        charts = {}
        
        if not isinstance(results, dict):
            return tables, charts
        
        try:
            # Direct tables
            if "tables" in results and isinstance(results["tables"], dict):
                for name, table in results["tables"].items():
                    if table is not None:
                        tables[f"{prefix}_{name}"] = table
            
            # Direct charts
            if "charts" in results and isinstance(results["charts"], dict):
                for name, chart in results["charts"].items():
                    if chart is not None:
                        charts[f"{prefix}_{name}"] = chart
            
            # Look for DataFrames and figures in various result categories
            for key, value in results.items():
                try:
                    if value is not None:
                        if hasattr(value, 'to_dict') or 'DataFrame' in str(type(value)):
                            tables[f"{prefix}_{key}"] = value
                        elif 'Figure' in str(type(value)):
                            charts[f"{prefix}_{key}"] = value
                        elif isinstance(value, dict):
                            # Look for nested DataFrames and figures
                            for subkey, subvalue in value.items():
                                if subvalue is not None:
                                    if hasattr(subvalue, 'to_dict') or 'DataFrame' in str(type(subvalue)):
                                        tables[f"{prefix}_{key}_{subkey}"] = subvalue
                                    elif 'Figure' in str(type(subvalue)):
                                        charts[f"{prefix}_{key}_{subkey}"] = subvalue
                except Exception as item_error:
                    print(f"Error processing result item {key}: {item_error}")
                    continue
        
        except Exception as e:
            print(f"Error extracting from results in {prefix}: {e}")
        
        return tables, charts
    
    def find_chart_widgets(self, widget):
        """Recursively find all ChartWidget instances - with better error handling"""
        chart_widgets = []
        
        if widget is None:
            return chart_widgets
        
        try:
            # Check if this widget is a ChartWidget
            if hasattr(widget, 'figure'):  # ChartWidget should have a figure attribute
                chart_widgets.append(widget)
            
            # Recursively search child widgets
            try:
                if hasattr(widget, 'children'):
                    for child in widget.children():
                        if hasattr(child, 'children'):  # It's a widget
                            chart_widgets.extend(self.find_chart_widgets(child))
            except Exception as children_error:
                print(f"Error searching children: {children_error}")
            
            # Special handling for layouts
            try:
                if hasattr(widget, 'layout') and widget.layout():
                    layout = widget.layout()
                    for i in range(layout.count()):
                        item = layout.itemAt(i)
                        if item and item.widget():
                            chart_widgets.extend(self.find_chart_widgets(item.widget()))
            except Exception as layout_error:
                print(f"Error searching layout: {layout_error}")
        
        except Exception as e:
            print(f"Error finding chart widgets: {e}")
        
        return chart_widgets


class ExcelAnalyzerApp(QMainWindow):

    
    def __init__(self):
        super().__init__()
        self.analysis_results = None
        self.export_button = None  # Track export button
        self.tab_widgets = {}  # Store references to tab widgets
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle("Material Planning Forecasting Tool v1.0")
        self.setGeometry(100, 100, 1400, 900)
        self.setStyleSheet(self.load_stylesheet())
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        self.main_layout = QVBoxLayout()
        central_widget.setLayout(self.main_layout)
        
        # Create initial upload interface
        self.create_upload_interface()
    
    def load_stylesheet(self):
        """Load and return the application stylesheet"""
        return """
            QMainWindow {
                background-color: #f0f0f0;
            }
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 14px;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:disabled {
                background-color: #cccccc;
                color: #666666;
            }
            QLabel {
                font-size: 12px;
            }
            QTabWidget::pane {
                border: 1px solid #cccccc;
                background-color: white;
            }
            QTabBar::tab {
                background-color: #e0e0e0;
                padding: 8px 16px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background-color: white;
                border-bottom: 2px solid #4CAF50;
            }
            QScrollArea {
                border: none;
                background-color: white;
            }
        """
    
    def create_upload_interface(self):
        """Create the initial file upload interface"""
        self.clear_layout(self.main_layout)
        
        upload_frame = QFrame()
        upload_frame.setFrameStyle(QFrame.Box)
        upload_frame.setMinimumHeight(200)
        upload_layout = QVBoxLayout()
        
        title_label = QLabel("Material Planning Forecasting Tool")
        title_label.setStyleSheet("font-size: 48px; color: #4caf50; font-weight: bold;")
        title_label.setAlignment(Qt.AlignCenter)
        upload_layout.addWidget(title_label)
        
        instruction_label = QLabel("Please select an Excel file containing the required named sheets:\n"
                                 "• Historical Forecast\n"                   
                                 "• Historical Usage\n"
                                 "• Supplier Performance\n"
                                 "• Financial Standard Price\n"                                 
                                 "• Current Inventory\n"
                                 "• Financial Extra Cost Data\n\n")
        instruction_label.setAlignment(Qt.AlignCenter)
        instruction_label.setStyleSheet("font-size: 36px;")
        upload_layout.addWidget(instruction_label)

        self.upload_button = QPushButton("Upload Excel File")
        self.upload_button.setStyleSheet("font-size: 40px;")
        self.upload_button.clicked.connect(self.upload_file)
        self.upload_button.setMinimumHeight(150)
        upload_layout.addWidget(self.upload_button)

        for _ in range(2):
            upload_layout.addWidget(QLabel(""))

        # Sample Dataset Generator Section
        sample_generator_frame = QFrame()
        sample_generator_frame.setFrameStyle(QFrame.Box)
        sample_generator_layout = QVBoxLayout()

        sample_title_label = QLabel("Sample Dataset Generator")
        sample_title_label.setAlignment(Qt.AlignCenter)
        sample_title_label.setStyleSheet("font-size: 48px; font-weight: bold; color: #2196F3;")
        sample_generator_layout.addWidget(sample_title_label)

        features_label = QLabel("Features: Realistic wafer fabrication materials, multiple suppliers, historical trends and financial data\n Minimum 5 Material Codes and 60 Months of Data is recommended!\n")
        features_label.setAlignment(Qt.AlignCenter)
        features_label.setStyleSheet("font-size: 33px; color: #666;")
        sample_generator_layout.addWidget(features_label)

        # Input controls layout
        controls_layout = QHBoxLayout()

        # Material codes input
        materials_layout = QVBoxLayout()
        materials_label = QLabel("Material Codes:")
        materials_label.setStyleSheet("font-size: 36px;")
        materials_layout.addWidget(materials_label)
        self.materials_spinbox = QSpinBox()
        self.materials_spinbox.setRange(5, 5000)
        self.materials_spinbox.setValue(5)
        self.materials_spinbox.setStyleSheet("""
            font-size: 36px; 
            padding: 3px;
            min-height: 100px;
            QSpinBox::up-button, QSpinBox::down-button { 
                width: 60px; 
            }
        """)
        materials_layout.addWidget(self.materials_spinbox)
        controls_layout.addLayout(materials_layout)

        # Months input
        months_layout = QVBoxLayout()
        months_label = QLabel("Months of Data:")
        months_label.setStyleSheet("font-size: 36px;")
        months_layout.addWidget(months_label)
        self.months_spinbox = QSpinBox()
        self.months_spinbox.setRange(12, 120)
        self.months_spinbox.setValue(60)
        self.months_spinbox.setStyleSheet("""
            font-size: 36px; 
            padding: 3px;
            min-height: 100px;
            QSpinBox::up-button, QSpinBox::down-button { 
                width: 60px; 
            }
        """)
        months_layout.addWidget(self.months_spinbox)
        controls_layout.addLayout(months_layout)

        sample_generator_layout.addLayout(controls_layout)

        # Generate button
        self.generate_button = QPushButton("Generate Sample Data")
        self.generate_button.setStyleSheet("""
            QPushButton {
                font-size: 40px; 
                background-color: #2196F3;
                border: none;
                padding: 10px;
                border-radius: 5px;
                color: white;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:pressed {
                background-color: #0D47A1;
            }
        """)
        self.generate_button.clicked.connect(self.generate_sample_data)
        self.generate_button.setMinimumHeight(150)
        sample_generator_layout.addWidget(self.generate_button)

        sample_generator_frame.setLayout(sample_generator_layout)
        upload_layout.addWidget(sample_generator_frame)


        

        upload_frame.setMinimumHeight(1200)
        upload_frame.setLayout(upload_layout)
        scroll_area = QScrollArea()
        scroll_area.setWidget(upload_frame)
        scroll_area.setWidgetResizable(True)
        self.main_layout.addWidget(scroll_area)


    def generate_sample_data(self):
        """Generate sample dataset with user-specified parameters"""
        num_materials = self.materials_spinbox.value()
        num_months = self.months_spinbox.value()
        
        # Get save location
        save_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Sample Dataset As",
            f"sample_dataset_{num_materials}materials_{num_months}months.xlsx",
            "Excel Files (*.xlsx)"
        )
        
        if not save_path:
            return
        
        # Check if file exists and is open
        if os.path.exists(save_path):
            try:
                # Try to open the file in write mode to check if it's locked
                with open(save_path, 'r+b') as test_file:
                    pass
                # File exists but is not open - ask user what to do
                msg_box = QMessageBox(self)
                msg_box.setIcon(QMessageBox.Question)
                msg_box.setWindowTitle("File Already Exists")
                msg_box.setText(f"The file already exists:\n\n{save_path}\n\nWhat would you like to do?")
                msg_box.setStyleSheet("QMessageBox { font-size: 30px; } QMessageBox QLabel { font-size: 30px; } QMessageBox QPushButton { font-size: 28px; min-width: 200px; min-height: 60px; }")
                
                overwrite_button = msg_box.addButton("Overwrite", QMessageBox.AcceptRole)
                save_new_button = msg_box.addButton("Save with New Name", QMessageBox.ActionRole)
                cancel_button = msg_box.addButton("Cancel", QMessageBox.RejectRole)
                
                msg_box.exec_()
                
                if msg_box.clickedButton() == save_new_button:
                    # Let user choose a new name
                    save_path, _ = QFileDialog.getSaveFileName(
                        self,
                        "Save Sample Dataset As (New Name)",
                        f"sample_dataset_{num_materials}materials_{num_months}months_copy.xlsx",
                        "Excel Files (*.xlsx)"
                    )
                    if not save_path:
                        return
                elif msg_box.clickedButton() == cancel_button:
                    return
                # If overwrite_button, continue with existing save_path
                
            except (PermissionError, IOError):
                # File is open, show error and return
                msg_box = QMessageBox(self)
                msg_box.setIcon(QMessageBox.Critical)
                msg_box.setWindowTitle("File In Use")
                msg_box.setText(f"The file is currently open in another application:\n\n{save_path}\n\nPlease save and close the file, then try again.")
                msg_box.setStyleSheet("QMessageBox { font-size: 30px; } QMessageBox QLabel { font-size: 30px; } QMessageBox QPushButton { font-size: 28px; min-width: 200px; min-height: 60px; }")
                msg_box.exec_()
                return
        
        try:
            # Create progress dialog
            from PyQt5.QtWidgets import QProgressDialog
            from PyQt5.QtCore import QTimer
            
            progress_dialog = QProgressDialog("Generating sample data...", "Cancel", 0, 100, self)
            progress_dialog.setWindowTitle("Generating Dataset")
            progress_dialog.setWindowModality(Qt.WindowModal)
            progress_dialog.setMinimumDuration(0)
            progress_dialog.setFixedSize(1500, 500)
            progress_dialog.move(
                (self.screen().availableGeometry().center() - progress_dialog.rect().center())
            )
            progress_dialog.show()
            progress_dialog.setStyleSheet("""
                QProgressDialog { 
                    font-size: 40px; 
                }
                QProgressDialog QLabel { 
                    font-size: 48px; 
                    padding: 40px;
                }
                QProgressDialog QPushButton { 
                    font-size: 36px; 
                    min-width: 180px; 
                    min-height: 80px;
                    background-color: #f44336;
                    color: white;
                }
                QProgressDialog QProgressBar {
                    font-size: 40px;
                    min-height: 50px;
                }
            """)  # REPLACE THE OLD STYLESHEET
            progress_dialog.show()

            
            # Disable generate button
            self.generate_button.setEnabled(False)
            self.generate_button.setText("Generating...")
            
            # Run the generate_sample_data.py script with parameters
            script_path = os.path.join(os.path.dirname(__file__), "generate_sample_data.py")
            
            # Start subprocess
            import subprocess
            process = subprocess.Popen([
                sys.executable, script_path,
                str(num_materials), str(num_months), save_path
            ], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, cwd=os.path.dirname(__file__))
            
            # Simulate progress updates
            progress = 0
            while process.poll() is None:
                progress = min(progress + 5, 95)
                progress_dialog.setValue(progress)
                progress_dialog.setLabelText(f"Generating {num_materials} materials with {num_months} months of data...")
                
                if progress_dialog.wasCanceled():
                    process.terminate()
                    return
                
                # Process events to keep UI responsive
                from PyQt5.QtWidgets import QApplication
                QApplication.processEvents()
                
                # Small delay
                import time
                time.sleep(0.1)
            
            # Get results
            stdout, stderr = process.communicate()
            progress_dialog.setValue(100)
            progress_dialog.close()
            
            if process.returncode == 0:
                self.show_sample_data_success(save_path, num_materials, num_months)
            else:
                raise Exception(f"\nScript execution failed: \nIf you are overwriting an existing file, close the file first! {stderr}")
        except Exception as e:
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Critical)
            msg_box.setWindowTitle("Generation Error")
            msg_box.setText(f"Failed to generate sample data:\n{str(e)}")
            msg_box.setStyleSheet("QMessageBox { font-size: 30px; }")
            
            
            msg_box.exec_()
        finally:
            # Re-enable generate button
            self.generate_button.setEnabled(True)
            self.generate_button.setText("Generate Sample Data")

    def show_sample_data_success(self, save_path, num_materials, num_months):
        """Show success message with option to upload the generated dataset"""
        message = f"Sample dataset generated successfully!"
        message += f"<span style='color: white;'>{'_'*500}</span>\n\n"
        message += f"Location: {save_path}\n"
        message += f"Materials: {num_materials}\n"
        message += f"Months of data: {num_months}\n"
        message += f"File size: ~{os.path.getsize(save_path) / 1024:.1f} KB"
        
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Sample Data Generated")
        msg_box.setText(message)
        msg_box.setMinimumSize(3000, 600)
        msg_box.setStyleSheet("""
            QMessageBox { font-size: 36px; }
            QMessageBox QLabel { font-size: 48px; }
            QMessageBox QPushButton { 
                font-size: 28px; 
                min-width: 200px; 
                min-height: 200px;
                margin: 5px;
            }
        """)
        
        # Add custom buttons
        upload_button = msg_box.addButton("Upload this Dataset Now", QMessageBox.ActionRole)
        open_button = msg_box.addButton("Open the Saved File", QMessageBox.ActionRole)
        close_button = msg_box.addButton("Close", QMessageBox.RejectRole)

        # Style the upload button with green
        upload_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #45a049;
            }
            QPushButton:pressed {
                background-color: #3d8b40;
            }
        """)

        # Style the open button with default blue (no custom styling needed - inherits from main stylesheet)
        # Style the open button with blue
        open_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:pressed {
                background-color: #1565C0;
            }
        """)


        # Style the close button with red
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #f44336;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #da190b;
            }
            QPushButton:pressed {
                background-color: #c1170a;
            }
        """)
        
        while True:
            msg_box.exec()
            
            if msg_box.clickedButton() == upload_button:
                self.file_path = save_path
                self.create_analysis_interface()
                break
            elif msg_box.clickedButton() == open_button:
                self.open_file_with_system(save_path)
                # Don't break here - let the dialog stay open
            else:  # Close button
                break

    def open_file_with_system(self, file_path):
        """Open a file using the default system application"""
        try:
            import subprocess
            import sys
            
            if sys.platform == "win32":
                # Windows
                os.startfile(file_path)
            elif sys.platform == "darwin":
                # macOS
                subprocess.call(["open", file_path])
            else:
                # Linux
                subprocess.call(["xdg-open", file_path])
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open file:\n{str(e)}")

    def create_analysis_interface(self):
        """Create the analysis interface after file upload"""
        self.clear_layout(self.main_layout)
        
        file_info_label = QLabel(f"Loaded: {self.file_path}")
        file_info_label.setStyleSheet("font-size: 28px; font-weight: bold;")
        self.main_layout.addWidget(file_info_label)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.main_layout.addWidget(self.progress_bar)
        
        # Create horizontal layout for buttons
        from PyQt5.QtWidgets import QHBoxLayout
        button_layout = QHBoxLayout()
        
        self.analysis_button = QPushButton("Run All Data Analysis")
        self.analysis_button.setStyleSheet("font-size: 40px;")

        self.analysis_button.clicked.connect(self.run_analysis)
        self.analysis_button.setMinimumHeight(150)
        button_layout.addWidget(self.analysis_button, 3)
        
        self.clear_button = QPushButton("Clear Selection")
        self.clear_button.setStyleSheet("""
            QPushButton {
                font-size: 40px; 
                background-color: #f44336;
                border: none;
                padding: 10px;
                border-radius: 5px;
                color: white;
            }
            QPushButton:hover {
                background-color: #d32f2f;
                border: 2px solid #ffcdd2;
            }
            QPushButton:pressed {
                background-color: #b71c1c;
                padding: 8px 12px;
            }                        
            QPushButton:disabled {
            background-color: #cccccc;
            color: #666666;
            
            }
        """)

        self.clear_button.clicked.connect(self.clear_selection)
        self.clear_button.setMinimumHeight(150)
        button_layout.addWidget(self.clear_button, 1)
        
        self.main_layout.addLayout(button_layout)
        
        self.tab_widget = QTabWidget()
        self.tab_widget.setVisible(False)
        self.main_layout.addWidget(self.tab_widget)

    def clear_selection(self):
        """Clear the current file selection and return to upload screen"""
        self.file_path = None
        self.analysis_results = None
        self.tab_widgets = {}
        self.create_upload_interface()
    
    def clear_layout(self, layout):
        """Clear all widgets and layouts from a layout"""
        while layout.count():
            child = layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
            elif child.layout():
                self.clear_layout(child.layout())
                child.layout().deleteLater()
    
    def upload_file(self):
        """Handle file upload"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, 
            "Select Excel File", 
            "", 
            "Excel Files (*.xlsx *.xls)"
        )
        
        if file_path:
            self.file_path = file_path
            self.create_analysis_interface()


    def run_analysis(self):


        # Force larger dialog size
        dialog_width = 900   
        dialog_height = 500  
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Analysis Options")
        dialog.setStyleSheet("background-color: white;")
        dialog.setFixedSize(dialog_width, dialog_height)
    
        
        layout = QVBoxLayout()
        dialog.setLayout(layout)
        
        # CLEAN LABEL - Remove all conflicting font settings
        label = QLabel("How would you like to proceed with the analysis?")
        label.setAlignment(Qt.AlignCenter)
        label.setWordWrap(True)
        
        # Method 1: CSS-style approach (most reliable)
        label.setStyleSheet("""
            QLabel {
                font-family: Arial;
                font-size: 48px;
                font-weight: bold;
                color: black;
            }
        """)
        
        layout.addWidget(label)
        
        # CLEAN BUTTONS - Use stylesheet for consistency
        gui_button = QPushButton("Load to this Interface First")
        export_button = QPushButton("Don't Load Here AND Skip Straight to Export to Excel")
        
        # Button styles with font included
        blue_button_style = """
            QPushButton {
                font-family: Arial;
                font-size: 30px;
                font-weight: bold;
                min-height: 60px;
                border: 3px solid #1565c0;
                border-radius: 8px;
                background-color: #2196f3;
                color: white;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #1976d2;
            }
            QPushButton:pressed {
                background-color: #1565c0;
            }
        """
        
        green_button_style = """
            QPushButton {
                font-family: Arial;
                font-size: 30px;
                font-weight: bold;
                min-height: 60px;
                border: 3px solid #388e3c;
                border-radius: 8px;
                background-color: #4caf50;
                color: white;
                padding: 10px;
            }
            QPushButton:hover {
                background-color: #388e3c;
            }
            QPushButton:pressed {
                background-color: #2e7d32;
            }
        """
        
        gui_button.setStyleSheet(blue_button_style)
        export_button.setStyleSheet(green_button_style)
        
        layout.addWidget(gui_button)
        layout.addWidget(export_button)
        
        # Button actions
        def on_gui_clicked():
            dialog.accept()
            self.run_analysis_with_gui()
        
        def on_export_clicked():
            dialog.accept()
            self.run_analysis_direct_export()
        
        gui_button.clicked.connect(on_gui_clicked)
        export_button.clicked.connect(on_export_clicked)

        
        dialog.exec_()


    def run_analysis_with_gui(self):
        self.clear_button.setEnabled(False)
        """Original analysis behavior - load to GUI"""
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                height: 50px;
                font-size: 40px;
                font-weight: bold;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
            }
        """)
        
        self.analysis_button.setEnabled(False)
        self.analysis_start_time = time.time()
        
        self.worker = DataAnalysisWorker(self.file_path)
        self.worker.progress_updated.connect(self.progress_bar.setValue)
        self.worker.analysis_completed.connect(self.on_analysis_completed)
        self.worker.error_occurred.connect(self.on_analysis_error)
        self.worker.start()

    def run_analysis_direct_export(self):
        self.clear_button.setEnabled(False)

        now = datetime.now()
        timestamp = now.strftime("%d%b%Y_%I.%M%p").lower()
        # Capitalize first letter of month (positions 2-4)
        timestamp = timestamp[:2] + timestamp[2:5].capitalize() + timestamp[5:]
        default_filename = f"{timestamp}_AI_Analysis_Results.xlsx"
        
        save_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Analysis Results As",
            default_filename,
            "Excel Files (*.xlsx)"
        )

        if not save_path:
            return

        if os.path.exists(save_path):
            try:
                # Try to open the file in write mode to check if it's locked
                with open(save_path, 'r+b') as test_file:
                    pass
                # File is not open, continue with analysis (no message)
            except (PermissionError, IOError):
                # File is open, show error and return
                msg_box = QMessageBox(self)
                msg_box.setIcon(QMessageBox.Critical)
                msg_box.setWindowTitle("File In Use")
                msg_box.setText(f"The file is currently open in another application:\n\n{save_path}\n\nPlease save and close the file, then try again.\n\nReminder: Do not open the file while the analysis is running.")
                msg_box.setStyleSheet("QMessageBox { font-size: 30px; } QMessageBox QLabel { font-size: 30px; } QMessageBox QPushButton { font-size: 28px; min-width: 200px; min-height: 60px; }")
                msg_box.exec_()
                self.clear_button.setEnabled(True)
                return
        
        self.export_save_path = save_path  # Store for later use
        
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                height: 50px;
                font-size: 40px;
                font-weight: bold;
                text-align: center;
            }
            QProgressBar::chunk {
                background-color: #4CAF50;
            }
        """)
        
        self.analysis_button.setEnabled(False)
        self.analysis_start_time = time.time()
        
        self.worker = DataAnalysisWorker(self.file_path)
        self.worker.progress_updated.connect(self.progress_bar.setValue)
        self.worker.analysis_completed.connect(self.on_analysis_completed_direct_export)
        self.worker.error_occurred.connect(self.on_analysis_error)
        self.worker.start()

    def on_analysis_completed_direct_export(self, results):
        """Handle analysis completion for direct export"""
        self.analysis_results = results
        self.progress_bar.setVisible(False)
        
        # Create tab widgets for export (without showing GUI)
        analysis_tab = ExploratoryDataAnalysisTab(results)
        forecast_tab = ForecastCostSavingsTab(results)
        dynamic_learning_tab = DynamicLearningTab(results)
        
        # Start direct export
        self.export_worker = EDAOnlyExportWorker(
            self.export_save_path, analysis_tab, forecast_tab, dynamic_learning_tab
        )
        self.export_worker.finished.connect(self.on_direct_export_finished)
        self.export_worker.error.connect(self.on_direct_export_error)
        self.export_worker.start()

    def on_direct_export_finished(self, success_message):
        """Handle successful direct export and return to main page"""
        elapsed_time = time.time() - self.analysis_start_time
        minutes = int(elapsed_time // 60)
        seconds = elapsed_time % 60
        time_str = f"{minutes}m {seconds:.1f}s" if minutes > 0 else f"{seconds:.1f}s"
        
        # Re-enable analysis button (not applicable here but keeping consistency)
        self.analysis_button.setEnabled(True)
        
        # Define font size for styling (matching on_export_finished)
        font_size = 36
        
        # Apply QMessageBox styling with better button separation (matching on_export_finished)
        msgbox_style = f"""
            QMessageBox {{ 
                font-size: {font_size}px; 
            }}
            QMessageBox QLabel {{ 
                font-size: {font_size}px; 
            }}
            QMessageBox QPushButton {{ 
                font-size: {font_size-3}px; 
                min-width: {font_size*8}px; 
                min-height: {font_size*5}px;
                margin: 5px;
                padding: 8px 16px;
                border: 2px solid #ccc;
                border-radius: 6px;
                background-color: #f0f0f0;
            }}
            QMessageBox QPushButton:hover {{
                background-color: #e0e0e0;
            }}
        """
        
        # Create custom message box with two buttons (matching on_export_finished)
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Export Complete")
        msg_box.setText(f"Data analysis completed successfully!\n\nTime elapsed: {time_str}\n\n{success_message}")
        msg_box.setStyleSheet(msgbox_style)
        
        # Add custom buttons (matching on_export_finished)
        open_button = msg_box.addButton("Open Saved File", QMessageBox.ActionRole)
        close_button = msg_box.addButton("Close", QMessageBox.RejectRole)
        
        # Style the open button specifically to be green (matching on_export_finished)
        open_button.setStyleSheet(f"""
            QPushButton {{
                font-size: {font_size-3}px;
                min-width: {font_size*8}px;
                min-height: {font_size*5}px;
                margin: 5px;
                padding: 8px 16px;
                border: 2px solid #388e3c;
                border-radius: 6px;
                background-color: #4caf50;
                color: white;
            }}
            QPushButton:hover {{
                background-color: #388e3c;
            }}
            QPushButton:pressed {{
                background-color: #2e7d32;
            }}
        """)

        # Style the close button specifically to be red (matching on_export_finished)
        close_button.setStyleSheet(f"""
            QPushButton {{
                font-size: {font_size-2}px;
                min-width: {font_size*8}px;
                min-height: {font_size*5}px;
                margin: 5px;
                padding: 8px 16px;
                border: 2px solid #d32f2f;
                border-radius: 6px;
                background-color: #f44336;
                color: white;
            }}
            QPushButton:hover {{
                background-color: #d32f2f;
            }}
            QPushButton:pressed {{
                background-color: #b71c1c;
            }}
        """)
        
        # Execute and handle button clicks
        msg_box.exec()
        
        if msg_box.clickedButton() == open_button:
            self.open_exported_file()
        
        # Return to main page
        self.clear_selection()

    def on_direct_export_error(self, error_message):
        """Handle direct export error and return to main page"""
        QMessageBox.critical(self, "Export Error", f"Export failed:\n{error_message}")
        
        # Return to main page
        self.clear_selection()

    def extract_tables_from_results(self):
        """Extract all tables from analysis results - UPDATED with better error handling"""
        tables = {}
        
        try:
            # Get the current tab widget and extract data from each tab
            if not hasattr(self, 'tab_widget') or not self.tab_widget.isVisible():
                print("No visible tab widget found")
                return tables
            
            print(f"Tab widget has {self.tab_widget.count()} tabs")
            
            # Get the Exploratory Data Analysis tab (first tab)
            if self.tab_widget.count() > 0:
                eda_tab = self.tab_widget.widget(0)  # ExploratoryDataAnalysisTab
                if eda_tab:
                    print("Processing EDA tab")
                    try:
                        # Find the inner tab widget that contains the category tabs
                        inner_tab_widgets = eda_tab.findChildren(QTabWidget)
                        inner_tab_widget = None
                        
                        for child in inner_tab_widgets:
                            if child != self.tab_widget:  # Make sure it's not the main tab widget
                                inner_tab_widget = child
                                break
                        
                        if inner_tab_widget:
                            print(f"Found inner tab widget with {inner_tab_widget.count()} tabs")
                            # Extract tables from each category tab
                            for i in range(inner_tab_widget.count()):
                                try:
                                    tab_widget = inner_tab_widget.widget(i)
                                    tab_title = inner_tab_widget.tabText(i)
                                    
                                    if hasattr(tab_widget, 'table') and tab_widget.table:
                                        # Extract table data
                                        table_data = self.extract_table_data_from_widget(tab_widget.table)
                                        if table_data is not None and not table_data.empty:
                                            tables[f"EDA_{tab_title}"] = table_data
                                            print(f"Extracted table from EDA_{tab_title}")
                                    
                                    # Also get classification table if it exists
                                    if hasattr(tab_widget, 'classification_table') and tab_widget.classification_table:
                                        classification_data = self.extract_table_data_from_widget(tab_widget.classification_table)
                                        if classification_data is not None and not classification_data.empty:
                                            tables[f"EDA_{tab_title}_Classifications"] = classification_data
                                            print(f"Extracted classification table from EDA_{tab_title}")
                                except Exception as tab_error:
                                    print(f"Error processing EDA tab {i}: {tab_error}")
                                    continue
                        else:
                            print("No inner tab widget found in EDA tab")
                    except Exception as eda_error:
                        print(f"Error processing EDA tab: {eda_error}")
            
            # Get the Forecasts and Cost Savings tab (second tab)
            if self.tab_widget.count() > 1:
                forecast_tab = self.tab_widget.widget(1)  # ForecastCostSavingsTab
                if forecast_tab:
                    print("Processing forecast tab")
                    try:
                        table_widgets = forecast_tab.findChildren(QTableWidget)
                        print(f"Found {len(table_widgets)} table widgets in forecast tab")
                        for i, table_widget in enumerate(table_widgets):
                            try:
                                table_data = self.extract_table_data_from_widget(table_widget)
                                if table_data is not None and not table_data.empty:
                                    tables[f"Forecast_Table_{i+1}"] = table_data
                                    print(f"Extracted Forecast_Table_{i+1}")
                            except Exception as table_error:
                                print(f"Error extracting forecast table {i}: {table_error}")
                                continue
                    except Exception as forecast_error:
                        print(f"Error processing forecast tab: {forecast_error}")
            
            # Get the Dynamic Learning tab (third tab)
            if self.tab_widget.count() > 2:
                dynamic_tab = self.tab_widget.widget(2)  # DynamicLearningTab
                if dynamic_tab:
                    print("Processing dynamic learning tab")
                    try:
                        table_widgets = dynamic_tab.findChildren(QTableWidget)
                        print(f"Found {len(table_widgets)} table widgets in dynamic learning tab")
                        for i, table_widget in enumerate(table_widgets):
                            try:
                                table_data = self.extract_table_data_from_widget(table_widget)
                                if table_data is not None and not table_data.empty:
                                    tables[f"Dynamic_Learning_Table_{i+1}"] = table_data
                                    print(f"Extracted Dynamic_Learning_Table_{i+1}")
                            except Exception as table_error:
                                print(f"Error extracting dynamic learning table {i}: {table_error}")
                                continue
                    except Exception as dynamic_error:
                        print(f"Error processing dynamic learning tab: {dynamic_error}")
        
        except Exception as e:
            print(f"Error in extract_tables_from_results: {e}")
            import traceback
            traceback.print_exc()
        
        print(f"Total tables extracted: {len(tables)}")
        return tables

    def extract_table_data_from_widget(self, table_widget):
        """Extract data from a QTableWidget as a pandas DataFrame - with better error handling"""
        try:
            if not table_widget or table_widget.rowCount() == 0:
                return None
            
            # Get headers
            headers = []
            for col in range(table_widget.columnCount()):
                header_item = table_widget.horizontalHeaderItem(col)
                headers.append(header_item.text() if header_item else f"Column_{col}")
            
            # Get data
            data = []
            for row in range(table_widget.rowCount()):
                row_data = []
                for col in range(table_widget.columnCount()):
                    item = table_widget.item(row, col)
                    row_data.append(item.text() if item else "")
                data.append(row_data)
            
            # Convert to DataFrame
            import pandas as pd
            df = pd.DataFrame(data, columns=headers)
            
            # Clean up empty rows and columns
            df = df.dropna(how='all').dropna(axis=1, how='all')
            
            return df if not df.empty else None
            
        except Exception as e:
            print(f"Error extracting table data: {e}")
            return None
    
    def on_analysis_completed(self, results):
        """Handle successful analysis completion"""
        self.analysis_results = results
        self.progress_bar.setVisible(False)
        
        # Create all three main tabs and store references
        analysis_tab = ExploratoryDataAnalysisTab(results)
        forecast_tab = ForecastCostSavingsTab(results)
        dynamic_learning_tab = DynamicLearningTab(results)
        
        # Store tab references for export
        self.tab_widgets = {
            "Exploratory_Data_Analysis": analysis_tab,
            "Forecasts_and_Cost_Savings": forecast_tab,
            "Dynamic_Learning_and_Optimization": dynamic_learning_tab
        }
        
        self.tab_widget.clear()
        self.tab_widget.addTab(analysis_tab, "Exploratory Data Analysis")
        self.tab_widget.addTab(forecast_tab, "Forecasts and Cost Savings")
        self.tab_widget.addTab(dynamic_learning_tab, "Dynamic Learning and Optimization")
        
        self.tab_widget.setFont(QFont("Arial", 16))
        self.tab_widget.setVisible(True)
        self.analysis_button.setVisible(False)
        self.clear_button.setVisible(False)

        # Create horizontal layout for buttons
        from PyQt5.QtWidgets import QHBoxLayout
        button_layout = QHBoxLayout()
        
        # Export button
        self.export_button = QPushButton("Export Results to Excel")
        self.export_button.setStyleSheet("font-size: 28px;")
        self.export_button.clicked.connect(self.export_results_to_excel)
        button_layout.addWidget(self.export_button, 3)
        
        # Return to home button
        self.return_home_button = QPushButton("Run Another File")
        self.return_home_button.setStyleSheet("""
            QPushButton {
                font-size: 28px; 
                background-color: #2196F3;
                border: none;
                padding: 10px;
                border-radius: 5px;
                color: white;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:pressed {
                background-color: #0D47A1;
            }
        """)
        self.return_home_button.clicked.connect(self.confirm_return_to_home)
        button_layout.addWidget(self.return_home_button)
        
        self.main_layout.addLayout(button_layout, 1)
        
        # Show completion message after UI is fully loaded
        from PyQt5.QtCore import QTimer
        QTimer.singleShot(100, self.show_completion_message)

    def show_completion_message(self):
        """Show completion message after UI is fully loaded"""
        elapsed_time = time.time() - self.analysis_start_time
        minutes = int(elapsed_time // 60)
        seconds = elapsed_time % 60
        time_str = f"{minutes}m {seconds:.1f}s" if minutes > 0 else f"{seconds:.1f}s"

        self.show_large_message_box(
            "Analysis Complete", 
            f"Data analysis completed successfully!\n\nTime elapsed: {time_str}",
            font_size=60,
            width=6000
        )

    def confirm_return_to_home(self):
        """Solution 5: Using QTimer to modify buttons after creation"""
        from PyQt5.QtCore import QTimer
        from PyQt5.QtWidgets import QPushButton
        
        font_size = 40
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Question)
        msg.setWindowTitle("Confirm Return to Home")
        msg.setText("Are you sure you want to return to the main screen?\n\nAll current analysis results will be cleared.")
        msg.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg.setDefaultButton(QMessageBox.No)
        
        # Set the message box size and font
        msg.setFixedSize(font_size * 40, font_size * 10)  # Wider message box
        
        # Style the entire message box
        msg.setStyleSheet(f"""
            QMessageBox {{
                font-size: {font_size}px;
                background-color: white;
            }}
            QMessageBox QLabel {{
                font-size: {font_size}px;
                padding: 20px;
            }}
        """)
        
        def style_buttons():
            buttons = msg.findChildren(QPushButton)
            for button in buttons:
                button.setFixedSize(font_size * 8, font_size * 2)
                
                # Check button text to apply different styles
                if button.text() == "&Yes":
                    # Red button for Yes
                    button.setStyleSheet(f"""
                        QPushButton {{
                            font-size: {font_size}px;
                            padding: 15px 30px;
                            background-color: #f44336;
                            color: white;
                            border: 2px solid #f44336;
                            border-radius: 8px;
                            font-weight: bold;
                            margin: 5px;
                        }}
                        QPushButton:hover {{
                            background-color: #d32f2f;
                            border-color: #c62828;
                        }}
                        QPushButton:pressed {{
                            background-color: #c62828;
                            border-color: #b71c1c;
                        }}
                    """)
                elif button.text() == "&No":
                    # Green button for No
                    button.setStyleSheet(f"""
                        QPushButton {{
                            font-size: {font_size}px;
                            padding: 15px 30px;
                            background-color: #4caf50;
                            color: white;
                            border: 2px solid #4caf50;
                            border-radius: 8px;
                            font-weight: bold;
                            margin: 5px;
                        }}
                        QPushButton:hover {{
                            background-color: #45a049;
                            border-color: #43a047;
                        }}
                        QPushButton:pressed {{
                            background-color: #388e3c;
                            border-color: #2e7d32;
                        }}
                    """)
        
        # Use QTimer to style buttons after they're created
        QTimer.singleShot(0, style_buttons)
        
        if msg.exec_() == QMessageBox.Yes:
            self.clear_selection()


    def export_results_to_excel(self):
        """Export analysis results to an Excel file with all three tabs."""
        if not self.analysis_results or not self.tab_widgets:
            QMessageBox.warning(self, "No Results", "No analysis results to export.")
            return
        
        now = datetime.now()
        timestamp = now.strftime("%d%b%Y_%I.%M%p").lower()
        # Capitalize first letter of month (positions 2-4)
        timestamp = timestamp[:2] + timestamp[2:5].capitalize() + timestamp[5:]
        default_filename = f"{timestamp}_AI_Analysis_Results.xlsx"
        
        save_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Analysis Results As",
            default_filename,
            "Excel Files (*.xlsx)"
        )
        
        # Disable export button during export
        self.export_button.setEnabled(False)
        self.export_button.setText("Exporting Analysis Results...")
        
        # Get all three tab widgets
        eda_tab = self.tab_widgets.get("Exploratory_Data_Analysis")
        forecast_tab = self.tab_widgets.get("Forecasts_and_Cost_Savings")
        dynamic_learning_tab = self.tab_widgets.get("Dynamic_Learning_and_Optimization")
        
        # Create and start export worker with all three widgets
        self.export_worker = EDAOnlyExportWorker(save_path, eda_tab, forecast_tab, dynamic_learning_tab)
        self.export_worker.finished.connect(self.on_export_finished)
        self.export_worker.error.connect(self.on_export_error)
        self.export_worker.start()

    def on_export_finished(self, success_message):
        """Handle successful export completion"""
        # Re-enable export button
        self.export_button.setEnabled(True)
        self.export_button.setText("Export Results to Excel")
        
        # Define font size for styling
        font_size = 36
        
        # Apply QMessageBox styling with better button separation
        msgbox_style = f"""
            QMessageBox {{ 
                font-size: {font_size}px; 
            }}
            QMessageBox QLabel {{ 
                font-size: {font_size}px; 
            }}
            QMessageBox QPushButton {{ 
                font-size: {font_size-3}px; 
                min-width: {font_size*8}px; 
                min-height: {font_size*5}px;
                margin: 5px;
                padding: 8px 16px;
                border: 2px solid #ccc;
                border-radius: 6px;
                background-color: #f0f0f0;
            }}
            QMessageBox QPushButton:hover {{
                background-color: #e0e0e0;
            }}
        """
        
        # Create custom message box with two buttons
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle("Export Complete")
        msg_box.setText(success_message)
        msg_box.setStyleSheet(msgbox_style)
        
        # Add custom buttons
        open_button = msg_box.addButton("Open Saved File", QMessageBox.ActionRole)
        close_button = msg_box.addButton("Close", QMessageBox.RejectRole)
        
        # Style the open button specifically to be green
        open_button.setStyleSheet(f"""
            QPushButton {{
                font-size: {font_size-3}px;
                min-width: {font_size*8}px;
                min-height: {font_size*5}px;
                margin: 5px;
                padding: 8px 16px;
                border: 2px solid #388e3c;
                border-radius: 6px;
                background-color: #4caf50;
                color: white;
            }}
            QPushButton:hover {{
                background-color: #388e3c;
            }}
            QPushButton:pressed {{
                background-color: #2e7d32;
            }}
        """)

        # Style the close button specifically to be red
        close_button.setStyleSheet(f"""
            QPushButton {{
                font-size: {font_size-2}px;
                min-width: {font_size*8}px;
                min-height: {font_size*5}px;
                margin: 5px;
                padding: 8px 16px;
                border: 2px solid #d32f2f;
                border-radius: 6px;
                background-color: #f44336;
                color: white;
            }}
            QPushButton:hover {{
                background-color: #d32f2f;
            }}
            QPushButton:pressed {{
                background-color: #b71c1c;
            }}
        """)
        
        # Execute and handle button clicks
        msg_box.exec()
        
        if msg_box.clickedButton() == open_button:
            self.open_exported_file()

    def open_exported_file(self):
        """Open the exported Excel file using the default system application"""
        try:
            if hasattr(self.export_worker, 'save_path') and self.export_worker.save_path:
                import subprocess
                import sys
                
                if sys.platform == "win32":
                    # Windows
                    os.startfile(self.export_worker.save_path)
                elif sys.platform == "darwin":
                    # macOS
                    subprocess.call(["open", self.export_worker.save_path])
                else:
                    # Linux
                    subprocess.call(["xdg-open", self.export_worker.save_path])
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Could not open file:\n{str(e)}")

    def on_export_error(self, error_message):
        """Handle export error"""
        # Re-enable export button
        self.export_button.setEnabled(True)
        self.export_button.setText("Export Results to Excel")
        
        # Show error message using the custom large message box
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Critical)
        msg.setText(error_message)
        msg.setWindowTitle("Export Error")
        msg.setMinimumSize(2400, 800)
        msg.setStyleSheet("""
            QMessageBox { font-size: 40px; }
            QMessageBox QLabel { font-size: 36px; }
            QMessageBox QPushButton { 
                font-size: 36px; 
                min-width: 500px; 
                min-height: 80px; 
            }
        """)
        msg.exec_()
    
    def on_analysis_error(self, error_message):
        """Handle analysis errors with dynamic sheet validation"""
        self.progress_bar.setVisible(False)
        self.analysis_button.setEnabled(True)


        
        # Required sheet names (exact names as specified)
        required_sheets = [
            "Historical Forecast",
            "Historical Usage", 
            "Supplier Performance",
            "Financial Standard Price",
            "Current Inventory",
            "Financial Extra Cost Data"
        ]
        
        # Check if this is a sheet-related error by trying to read the Excel file
        missing_sheets = []
        found_sheets = []
        
        try:
            if hasattr(self, 'file_path') and self.file_path:
                import pandas as pd
                
                # Get list of sheets in the Excel file
                excel_file = pd.ExcelFile(self.file_path)
                available_sheets = excel_file.sheet_names
                
                # Check which required sheets are missing
                for sheet in required_sheets:
                    if sheet in available_sheets:
                        found_sheets.append(sheet)
                    else:
                        missing_sheets.append(sheet)
                
                # If we have missing sheets, create a detailed error message
                if missing_sheets:
                    error_title = "Missing Required Excel Sheets"
                    
                    detailed_message = "The following required sheets are missing from your Excel file:\n\n"
                    
                    # List missing sheets with bullet points
                    for sheet in missing_sheets:
                        detailed_message += f"❌ {sheet}\n"
                    
                    if found_sheets:
                        detailed_message += f"\nFound sheets:\n"
                        for sheet in found_sheets:
                            detailed_message += f"✅ {sheet}\n"

                    detailed_message += "\nPlease ensure all sheet names match exactly as shown above."
                    # Show the detailed message box
                    self.show_large_message_box(error_title, detailed_message, width=8000, height=8000, font_size=30)
                    return
        
        except Exception as sheet_check_error:
            # If we can't read the file, fall back to showing the original error
            print(f"Could not check sheets: {sheet_check_error}")
        
        # For non-sheet related errors or if sheet checking failed, show original error
        QMessageBox.critical(self, "Analysis Error", f"Error during analysis:\n{error_message}")
    
    def show_large_message_box(self, title, text, width=5000, height=700, font_size=16):
        """Display a large message box with custom styling"""
        msg = QMessageBox(self)
        msg.setIcon(QMessageBox.Information)
        msg.setText(text)
        msg.setWindowTitle(title)
        msg.setMinimumSize(width, height)
        msg.setStyleSheet(f"""
            QMessageBox {{ font-size: {font_size}px; }}
            QMessageBox QLabel {{ font-size: {font_size}px; }}
            QMessageBox QPushButton {{ 
                font-size: {font_size-2}px; 
                min-width: {font_size*12}px; 
                min-height: {font_size*3}px; 
            }}
        """)
        return msg.exec_()