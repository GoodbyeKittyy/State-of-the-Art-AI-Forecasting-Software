import pandas as pd
import random
import numpy as np
from datetime import datetime, timedelta
from faker import Faker
import os
import sys

def generate_classification_remark(classification):
    """Generate realistic remarks based on classification type"""
    remarks_map = {
        'Understock': [
            "Emergency procurement due to production shortage",
            "Rush order to avoid line down situation",
            "Stock out caused production delay",
            "Urgent replenishment to meet demand"
        ],
        'Overstock': [
            "Excess inventory due to demand forecast error",
            "Overordered due to minimum quantity requirement",
            "Production schedule change left excess stock",
            "Market demand lower than projected"
        ],
        'Obsolete': [
            "Material expired beyond shelf life",
            "Process change made material obsolete",
            "Technology upgrade rendered material unusable",
            "Quality specification updated, old stock written off"
        ],
        'Unexpected Damage': [
            "Material damaged during transport",
            "Warehouse handling incident",
            "Equipment malfunction caused material loss",
            "Environmental exposure damaged inventory"
        ],
        'Expedited Shipping': [
            "Air freight due to urgent production need",
            "Express delivery to avoid production halt",
            "Same-day delivery surcharge for critical material",
            "Weekend delivery premium to meet schedule"
        ],
        'Quality Issue': [
            "Failed incoming inspection, returned to supplier",
            "Contamination detected, batch quarantined",
            "Out of specification material rejected",
            "Quality audit found non-conforming material"
        ]
    }
    
    return random.choice(remarks_map.get(classification, ["Material cost adjustment"]))

def generate_sample_data(num_materials=50, num_months=60, output_file=None):
    """Generate sample wafer fab data with specified parameters"""
    
    fake = Faker()
    
    # Configuration
    mrp_controller = "76"
    
    # Generate date range based on num_months
    end_date = datetime.now().replace(day=1)  # Start of current month
    start_date = end_date - timedelta(days=30 * num_months)
    months = pd.date_range(start_date, end_date, freq='MS').strftime("%YM%m").tolist()
    recent_months = months[-12:] if len(months) >= 12 else months[-len(months)//2:]
    
    if output_file is None:
        output_file = f"sample_dataset_{num_materials}materials_{num_months}months.xlsx"

    # Define realistic material categories
    material_catalog = [
        {"type": "Photoresist", "prefix": "PR", "uom": "L"},
        {"type": "Etchant", "prefix": "ET", "uom": "L"},
        {"type": "CMP Slurry", "prefix": "SL", "uom": "L"},
        {"type": "Wafer", "prefix": "WF", "uom": "PCS"},
        {"type": "Gas", "prefix": "GS", "uom": "M3"},
        {"type": "Cleaner", "prefix": "CL", "uom": "L"},
        {"type": "Metal", "prefix": "MT", "uom": "KG"},
        {"type": "Mask", "prefix": "MS", "uom": "PCS"},
        {"type": "Dopant", "prefix": "DP", "uom": "L"},
        {"type": "Developer", "prefix": "DV", "uom": "L"},
        {"type": "Stripper", "prefix": "ST", "uom": "L"},
        {"type": "Implant", "prefix": "IM", "uom": "KG"},
    ]

    # Create realistic material list
    materials = []
    for i in range(num_materials):
        category = random.choice(material_catalog)
        code = f"{category['prefix']}{str(i+1).zfill(4)}"
        description = f"{category['type']} Material {category['prefix']}-{random.randint(100,999)}"
        wafer_size = random.choice(['200mm', '300mm'])
        
        materials.append({
            "MRP Controller": mrp_controller,
            "Material Code": code,
            "Material Description": description,
            "UOM": category['uom'],
            "Wafer Size": wafer_size
        })

    material_df = pd.DataFrame(materials)

    # --- Historical Usage (moved before Historical Forecast) ---
    historical_usage = []
    zero_usage_materials = set(random.sample(
        [m["Material Code"] for m in materials],
        min(int(num_materials * 0.25), len(materials))
    ))

    for material in materials:
        usage_record = {**material}
        mat_code = material["Material Code"]

        for month in months:
            if mat_code in zero_usage_materials and month in recent_months:
                usage_record[month] = 0
            else:
                # Create more realistic usage patterns
                base_usage = random.randint(50, 800)
                seasonal_factor = 1 + 0.3 * np.sin(2 * np.pi * months.index(month) / 12)
                usage_record[month] = max(0, int(base_usage * seasonal_factor * random.uniform(0.7, 1.3)))
        
        historical_usage.append(usage_record)

    df_historical = pd.DataFrame(historical_usage)

    # --- Historical Forecast (now generated after usage is created) ---
    historical_forecast = []
    for i, material in enumerate(materials):
        forecast_record = {**material}
        usage_record = df_historical.iloc[i]  # Get corresponding usage data
        
        for month in months:
            actual_usage = usage_record[month]
            
            # Create more realistic forecast variance
            if random.random() < 0.9:  # 70% chance for overforecast
                variance_factor = random.uniform(6.0, 9.0)  # 50% to 300% overforecast
            else:  
                variance_factor = random.uniform(0.81, 0.98)  # 10% to 70% underforecast
            
            forecast_value = max(0, int(actual_usage * variance_factor))
            forecast_record[month] = forecast_value
        
        historical_forecast.append(forecast_record)
    
    df_forecast = pd.DataFrame(historical_forecast)

    # --- Supplier Performance ---
    supplier_performance = []
    supplier_materials = random.sample(materials, min(int(num_materials * 0.75), len(materials)))
    
    suppliers = [fake.company() for _ in range(min(20, num_materials // 3))]  # Reuse suppliers

    for material in supplier_materials:
        num_suppliers = random.randint(1, min(3, len(suppliers)))
        material_suppliers = random.sample(suppliers, num_suppliers)
        
        for supplier in material_suppliers:
            supplier_performance.append({
                **material,
                "Supplier": supplier,
                "PO Reference": fake.bothify(text='PO######'),
                "Quotation Lead Time Weeks": random.randint(1, 16),
                "PO Lead Time Weeks (Delivery Date vs GRN Date)": round(random.uniform(0.5, 12.0), 1),
                "PO Receiving Date": fake.date_between(start_date=start_date, end_date=end_date),
                "PO Doc. date": fake.date_between(start_date=start_date, end_date=end_date),
                "V.code": fake.lexify(text='V????'),
                "Ref": fake.bothify(text='REF#####')
            })
    
    df_supplier = pd.DataFrame(supplier_performance)

    # --- Financial Standard Price ---
    df_price = pd.DataFrame([
        {
            **material,
            "Standard Price": round(random.uniform(5.0, 2000.0), 2)
        }
        for material in materials
    ])

    # --- Current Inventory ---
    inventory_materials = random.sample(materials, min(int(num_materials * 0.85), len(materials)))
    df_inventory = pd.DataFrame([
        {
            **material,
            "Current Stock": random.randint(0, 1500),
            "Shelf Life Days": random.choice(['NIL'] * 3 + [random.randint(90, 1095)]),  # More NIL values
            "MOQ": random.randint(5, 200),
            "Reorder Point": random.randint(10, 300),
            "Minimum Safety Stock": random.randint(5, 150),
            "Max Stock": random.randint(300, 3000)
        }
        for material in inventory_materials
    ])

    # --- Financial Extra Cost Data ---
    extra_cost_types = ['Understock', 'Overstock', 'Obsolete', 'Unexpected Damage', 'Expedited Shipping', 'Quality Issue']
    extra_cost_materials = random.sample(materials, min(int(num_materials * 0.4), len(materials)))
    extra_cost_data = []

    for material in extra_cost_materials:
        num_incidents = random.randint(1, 8)
        for _ in range(num_incidents):
            classification = random.choice(extra_cost_types)
            incident_date = fake.date_between(start_date=start_date, end_date=end_date)
            
            # Different cost ranges based on classification
            if classification in ['Obsolete', 'Quality Issue']:
                cost = round(random.uniform(500.0, 25000.0), 2)
            elif classification in ['Expedited Shipping', 'Understock']:
                cost = round(random.uniform(100.0, 5000.0), 2)
            else:
                cost = round(random.uniform(50.0, 10000.0), 2)
            
            extra_cost_data.append({
                **material,
                "Reference Date": incident_date.strftime("%Y-%m-%d"),
                "Extra Cost (Expedited, Write-Off etc.)": cost,
                "Remarks": generate_classification_remark(classification),
                "Classification": classification,
                "Qty": random.randint(1, 200)
            })

    df_extra_cost = pd.DataFrame(extra_cost_data)

    # --- Excel Formatting Function ---
    def write_sheet(writer, df, sheet_name):
        df.to_excel(writer, sheet_name=sheet_name, index=False)
        worksheet = writer.sheets[sheet_name]

        # Hide gridlines
        worksheet.hide_gridlines(option=2)

        # Autofit columns with max width limit
        for idx, col in enumerate(df.columns):
            max_len = min(max(df[col].astype(str).map(len).max(), len(str(col))) + 2, 50)
            worksheet.set_column(idx, idx, max_len)

        # Set default row height
        worksheet.set_default_row(18)

        # Format headers
        workbook = writer.book
        header_fmt = workbook.add_format({
            'bold': True,
            'border': 1,
            'border_color': 'black',
            'bg_color': '#E6E6FA',
            'font_size': 11
        })
        
        # Write headers with formatting
        for col_idx, col_name in enumerate(df.columns):
            worksheet.write(0, col_idx, col_name, header_fmt)

        # Solid black borders with date formatting
        border_fmt = workbook.add_format({'border': 1, 'border_color': 'black'})
        date_border_fmt = workbook.add_format({
            'border': 1, 
            'border_color': 'black', 
            'num_format': 'yyyy-mm-dd'
        })
        currency_fmt = workbook.add_format({
            'border': 1,
            'border_color': 'black',
            'num_format': '$#,##0.00'
        })

        for row in range(1, len(df) + 1):
            for col in range(len(df.columns)):
                cell_value = df.iat[row - 1, col]
                col_name = df.columns[col]
                
                # Apply appropriate formatting
                if col_name in ['PO Receiving Date', 'PO Doc. date', 'Reference Date']:
                    worksheet.write(row, col, cell_value, date_border_fmt)
                elif col_name in ['Standard Price', 'Extra Cost (Expedited, Write-Off etc.)']:
                    worksheet.write(row, col, cell_value, currency_fmt)
                else:
                    worksheet.write(row, col, cell_value, border_fmt)

        # Special handling for Financial Extra Cost Data sheet - add reference table
        if sheet_name == "Financial Extra Cost Data":
            # Reference table data
            reference_data = [
                ["Example Description", "Classification"],
                ["Overuse", "Understock"],
                ["Write off", "Overstock"],
                ["Tool EOL", "Obsolete"],
                ["Breakage", "Unexpected Damage"],
                ["Issues found with material during Wafer Fabrication", "Quality Issue"],
                ["User Urgent Request and Require Air Transport", "Expedited Shipping"]
            ]
            
            # Calculate starting column (skip one blank column after main data)
            start_col = len(df.columns) + 1
            
            # Write reference table
            for row_idx, row_data in enumerate(reference_data):
                for col_idx, cell_value in enumerate(row_data):
                    if row_idx == 0:  # Header row
                        worksheet.write(row_idx, start_col + col_idx, cell_value, header_fmt)
                    else:  # Data rows
                        worksheet.write(row_idx, start_col + col_idx, cell_value, border_fmt)
            
            # Auto-fit the reference table columns
            for col_idx in range(len(reference_data[0])):
                max_len = max(len(str(row[col_idx])) for row in reference_data) + 2
                worksheet.set_column(start_col + col_idx, start_col + col_idx, max_len)

    # --- Write Excel File ---
    try:
        with pd.ExcelWriter(output_file, engine='xlsxwriter') as writer:
            write_sheet(writer, df_forecast, "Historical Forecast")
            write_sheet(writer, df_historical, "Historical Usage")
            write_sheet(writer, df_supplier, "Supplier Performance")
            write_sheet(writer, df_price, "Financial Standard Price")
            write_sheet(writer, df_inventory, "Current Inventory")
            write_sheet(writer, df_extra_cost, "Financial Extra Cost Data")
        
        print(f"[SUCCESS] Excel file '{output_file}' generated successfully!")
        print(f"[INFO] Location: {os.path.abspath(output_file)}")
        print(f"[INFO] Materials: {num_materials}")
        print(f"[INFO] Months: {num_months} ({months[0]} to {months[-1]})")
        print(f"[INFO] File size: {os.path.getsize(output_file) / 1024:.1f} KB")
        
        return True
        
    except Exception as e:
        print(f"[ERROR] Error generating Excel file: {str(e)}")
        return False

if __name__ == "__main__":
    # Command line interface
    if len(sys.argv) >= 4:
        # Called from app.py with parameters
        num_materials = int(sys.argv[1])
        num_months = int(sys.argv[2])
        output_file = sys.argv[3]
        
        success = generate_sample_data(num_materials, num_months, output_file)
        sys.exit(0 if success else 1)
    else:
        # Default execution
        print("Sample Dataset Generator")
        print("=" * 50)
        
        try:
            num_materials = int(input("Enter number of materials (default: 50): ") or "50")
            num_months = int(input("Enter number of months (default: 60): ") or "60")
            
            if num_materials < 1 or num_materials > 500:
                print("[WARNING] Number of materials should be between 1 and 500")
                num_materials = max(1, min(500, num_materials))
            
            if num_months < 1 or num_months > 120:
                print("[WARNING] Number of months should be between 1 and 120")
                num_months = max(1, min(120, num_months))
            
            generate_sample_data(num_materials, num_months)
            
        except KeyboardInterrupt:
            print("\n\n[CANCELLED] Generation cancelled by user.")
        except ValueError as e:
            print(f"[ERROR] Invalid input: {e}")
        except Exception as e:
            print(f"[ERROR] Error: {e}")