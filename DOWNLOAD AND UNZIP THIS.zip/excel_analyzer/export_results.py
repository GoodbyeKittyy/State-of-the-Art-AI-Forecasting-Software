import os
import re
import pandas as pd
from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter
from io import BytesIO
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QTabWidget, QTableWidget

#Function Name says EDA only but has been expanded to ALL MAIN TABS
#Chose to this to Act as the main function as EDA tab is the starting point 
def export_eda_only(output_path, eda_tab_widget, forecast_tab_widget=None, dynamic_learning_tab_widget=None):
    """
    Export ONLY the Exploratory Data Analysis results AND Forecasts and Cost Savings AND Dynamic Learning - just the charts and tables.
    
    Args:
        output_path: Path to save the Excel file
        eda_tab_widget: The ExploratoryDataAnalysisTab widget instance
        forecast_tab_widget: The ForecastCostSavingsTab widget instance (optional)
        dynamic_learning_tab_widget: The DynamicLearningTab widget instance (optional)
    """
    print(f"Starting EDA-only export to: {output_path}")
    
    # Extract tables from EDA tab only
    tables = extract_eda_tables(eda_tab_widget)
    print(f"Extracted {len(tables)} tables from EDA tab")
    
    # Extract charts from EDA tab only (in order)
    charts = extract_eda_charts_in_order(eda_tab_widget)
    print(f"Extracted {len(charts)} charts from EDA tab")
    
    # Get analysis metadata from eda_tab_widget - MADE DYNAMIC
    # Metadata needs to be handled properly, exercise caution
    analysis_metadata = extract_dynamic_analysis_metadata(eda_tab_widget)
    
    # Extract forecast data
    forecast_data = None
    if forecast_tab_widget:
        forecast_data = extract_forecast_data(forecast_tab_widget)
        print(f"Extracted forecast data: {len(forecast_data['tables'])} tables, {len(forecast_data['charts'])} charts")
    
    # Extract dynamic learning data 
    dynamic_learning_data = None
    if dynamic_learning_tab_widget:
        dynamic_learning_data = extract_dynamic_learning_data(dynamic_learning_tab_widget)
        print(f"Extracted dynamic learning data: {len(dynamic_learning_data['tables'])} tables")
    
    # Export using the export function
    return export_results_with_summary(output_path, tables, charts, analysis_metadata, forecast_data, dynamic_learning_data)

#Metadata Handling - Exercise Caution
def extract_dynamic_analysis_metadata(eda_tab_widget):
    """
    Dynamically extract analysis metadata with fallback for missing data
    """
    analysis_metadata = {
        'total_materials': 'N/A',
        'materials_with_usage': 'N/A',
        'materials_no_usage': 'N/A',
        'insights': {}
    }
    
    try:
        if hasattr(eda_tab_widget, 'analysis_results'):
            results = eda_tab_widget.analysis_results
            if results:
                # Safely extract with fallbacks if fallbacks are used
                analysis_metadata['total_materials'] = results.get('total_materials', 'N/A')
                analysis_metadata['materials_with_usage'] = results.get('materials_with_usage', 'N/A')
                analysis_metadata['materials_no_usage'] = results.get('materials_no_usage', 'N/A')
                
                # Safely extract insights
                insights = results.get('insights', {})
                if isinstance(insights, dict):
                    analysis_metadata['insights'] = insights
                else:
                    print("Warning: insights is not a dictionary, using empty dict")
                    analysis_metadata['insights'] = {}
        else:
            print("Warning: eda_tab_widget has no analysis_results attribute")
    
    except Exception as e:
        print(f"Warning: Error extracting analysis metadata: {e}")
    
    return analysis_metadata

def extract_eda_tables(eda_tab_widget):
    """Extract tables specifically from EDA tab structure - IMPROVED ERROR HANDLING"""
    tables = {}
    
    try:
        # Look for the inner QTabWidget that contains the category tabs
        inner_tab_widgets = eda_tab_widget.findChildren(QTabWidget)
        
        # Find the inner tab widget (should be different from main app tab widget)
        inner_tab_widget = None
        for tab_widget in inner_tab_widgets:
            # Check if this has multiple tabs with category names
            if tab_widget.count() > 3:  # EDA inner tab typically has 5-6 category tabs
                inner_tab_widget = tab_widget
                break
        
        if inner_tab_widget:
            print(f"Found EDA inner tab widget with {inner_tab_widget.count()} category tabs")
            
            # Extract from each category tab
            for i in range(inner_tab_widget.count()):
                try:
                    category_tab = inner_tab_widget.widget(i)
                    category_name = inner_tab_widget.tabText(i)
                    
                    if category_tab:
                        # Look for QTableWidget in this category tab
                        table_widgets = category_tab.findChildren(QTableWidget)
                        
                        for j, table_widget in enumerate(table_widgets):
                            if table_widget and table_widget.rowCount() > 0:
                                # Extract table data
                                df = extract_table_data_from_widget(table_widget)
                                if df is not None and not df.empty:
                                    # Create clean table name
                                    table_name = f"EDA_{clean_name(category_name)}"
                                    if j > 0:  # If multiple tables in same category
                                        table_name += f"_Table_{j+1}"
                                    
                                    tables[table_name] = df
                                    print(f"Successfully extracted table: {table_name} ({len(df)} rows)")
                
                except Exception as tab_error:
                    print(f"Warning: Error extracting from category tab {i}: {tab_error}")
                    continue
        else:
            print("Warning: Could not find EDA inner tab widget")
    
    except Exception as e:
        print(f"Warning: Error extracting EDA tables: {e}")
    
    print(f"Total tables extracted: {len(tables)}")
    return tables


def extract_eda_charts_in_order(eda_tab_widget):
    """
    FIXED: Extract exactly 10 specific charts in the correct order
    """
    charts = {}
    
    try:
        from excel_analyzer.widgets.data_analysis_charts import ChartWidget
        
        # Find all ChartWidget instances
        chart_widgets = eda_tab_widget.findChildren(ChartWidget)
        print(f"Found {len(chart_widgets)} ChartWidget instances in EDA tab")
        
        if not chart_widgets:
            print("Warning: No ChartWidget instances found")
            return charts
        
        # Defining the exact 6 charts in the same order as they appeared in the software
        target_charts = [
            {"title": "01 Material Analysis Summary", "keywords": ["material", "analysis", "summary"]},
            {"title": "02 Usage Distribution Last 12 Periods", "keywords": ["usage", "distribution", "12", "periods"]},
            {"title": "03 Supplier Records Materials With Usage", "keywords": ["supplier", "records", "materials", "usage"]},
            {"title": "04 Stock Status Materials With Usage", "keywords": ["stock", "status", "materials", "usage"]},
            {"title": "05 Extra Costs Materials With Usage", "keywords": ["extra", "costs", "materials", "usage"]},
            {"title": "06 Extra Costs By Classification", "keywords": ["extra", "costs", "classification"]},
            {"title": "07 Top Materials By Extra Cost", "keywords": ["top", "materials", "extra", "cost"]}
        ]
        
        # Extracting charts
        valid_charts = []
        for chart_widget in chart_widgets:
            if hasattr(chart_widget, 'figure') and chart_widget.figure is not None:
                chart_title = get_chart_title(chart_widget).lower()
                valid_charts.append({
                    'widget': chart_widget,
                    'title': chart_title,
                    'figure': chart_widget.figure,
                    'original_title': get_chart_title(chart_widget)
                })
        
        print(f"Found {len(valid_charts)} valid charts")
        
        # Match charts to target positions
        used_charts = set()
        
        for i, target in enumerate(target_charts, 1):
            best_match = None
            best_score = 0
            best_idx = -1
            
            for idx, chart in enumerate(valid_charts):
                if idx in used_charts:
                    continue
                    
                # Calculate match score
                matches = sum(1 for keyword in target["keywords"] if keyword in chart['title'])
                score = matches / len(target["keywords"])
                
                if score > best_score and score >= 0.5:  # At least 50% keyword match
                    best_match = chart
                    best_score = score
                    best_idx = idx
            
            if best_match:
                chart_name = f"Chart_{i:02d}_{clean_name(target['title'])}"
                charts[chart_name] = best_match['figure']
                used_charts.add(best_idx)
                print(f"Matched chart {i}: {target['title']} -> '{best_match['original_title']}' (score: {best_score:.2f})")
            else:
                print(f"Warning: Could not find match for chart {i}: {target['title']}")
                
                # Try to find any unused chart as fallback
                for idx, chart in enumerate(valid_charts):
                    if idx not in used_charts:
                        chart_name = f"Chart_{i:02d}_{clean_name(chart['original_title'])}"
                        charts[chart_name] = chart['figure']
                        used_charts.add(idx)
                        print(f"Using fallback chart {i}: {chart['original_title']}")
                        break
        
        return charts
        
    except Exception as e:
        print(f"Warning: Error extracting EDA charts: {e}")
        return {}

def get_chart_title(chart_widget):
    """Get chart title from chart widget with multiple fallbacks"""
    try:
        if hasattr(chart_widget, 'title') and chart_widget.title:
            return str(chart_widget.title)
        elif hasattr(chart_widget, 'chart_title') and chart_widget.chart_title:
            return str(chart_widget.chart_title)
        elif hasattr(chart_widget, 'figure') and chart_widget.figure and chart_widget.figure._suptitle:
            return str(chart_widget.figure._suptitle.get_text())
        elif hasattr(chart_widget, 'figure') and chart_widget.figure:
            # Try to get title from axes
            for ax in chart_widget.figure.get_axes():
                if ax.get_title():
                    return str(ax.get_title())
        return "Untitled Chart"
    except Exception as e:
        print(f"Warning: Error getting chart title: {e}")
        return "Untitled Chart"

def extract_table_data_from_widget(table_widget):
    """Extract data from a QTableWidget as a pandas DataFrame - FIXED: Now extracts ALL rows including hidden ones"""
    try:
        if not table_widget or table_widget.rowCount() == 0:
            return None
        
        # Get headers - including hidden columns
        headers = []
        for col in range(table_widget.columnCount()):
            header_item = table_widget.horizontalHeaderItem(col)
            headers.append(header_item.text() if header_item else f"Column_{col}")
        
        # Get data - INCLUDING HIDDEN ROWS AND COLUMNS
        data = []
        for row in range(table_widget.rowCount()):
            # Extract from ALL rows, regardless of whether they're hidden
            row_data = []
            for col in range(table_widget.columnCount()):
                item = table_widget.item(row, col)
                # Extract data regardless of whether row/column is hidden
                row_data.append(item.text() if item else "")
            data.append(row_data)
        
        # Convert to DataFrame
        df = pd.DataFrame(data, columns=headers)
        
        # Clean up empty rows and columns
        df = df.dropna(how='all').dropna(axis=1, how='all')
        
        print(f"Extracted table data: {len(df)} rows × {len(df.columns)} columns (including hidden rows)")
        
        return df if not df.empty else None
        
    except Exception as e:
        print(f"Warning: Error extracting table data: {e}")
        return None

def clean_name(name):
    """Clean name for use in keys and sheet names"""
    invalid_chars = ['\\', '/', '*', '[', ']', ':', '?', '(', ')', ' ']
    clean = str(name)
    for char in invalid_chars:
        clean = clean.replace(char, '_')
    # Remove consecutive underscores and limit length
    while '__' in clean:
        clean = clean.replace('__', '_')
    return clean.strip('_')[:50]

def auto_fit_columns(ws):
    """Auto-fit all columns in a worksheet"""
    for column_cells in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column_cells[0].column)
        
        for cell in column_cells:
            try:
                cell_length = len(str(cell.value))
                if cell_length > max_length:
                    max_length = cell_length
            except:
                pass
        
        # Set width with buffer
        adjusted_width = min(max_length + 2, 50)  # Max width 50 characters
        ws.column_dimensions[column_letter].width = adjusted_width

def export_results_with_summary(output_path, tables: dict, charts: dict, analysis_metadata=None, forecast_data=None, dynamic_learning_data=None):
    """
    UPDATED: Complete export function with DYNAMIC summary generation, forecast data, and dynamic learning data
    """
    print(f"Exporting {len(tables)} tables and {len(charts)} charts to {output_path}")
    if forecast_data:
        print(f"Also exporting forecast data: {len(forecast_data['tables'])} tables, {len(forecast_data['charts'])} charts")
    if dynamic_learning_data:
        print(f"Also exporting dynamic learning data: {len(dynamic_learning_data['tables'])} tables")
    
    # Create workbook and remove default sheet
    wb = Workbook()
    
    # Remove the default "Sheet" that Excel creates
    if "Sheet" in [ws.title for ws in wb.worksheets]:
        wb.remove(wb["Sheet"])
    
    # Store chart buffers to keep them alive until workbook is saved
    chart_buffers = []
    
    # Style definitions
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    title_font = Font(bold=True, size=16, color="2F4F4F")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Create summary sheet first
    summary_ws = wb.create_sheet(title="Exploratory Data Analysis", index=0)
    
    # Enhanced summary styling
    summary_title_font = Font(bold=True, size=18, color="1F4E79")
    subtitle_font = Font(bold=True, size=14, color="2F4F4F")
    normal_font = Font(size=12)
    highlight_fill = PatternFill(start_color="E6F3FF", end_color="E6F3FF", fill_type="solid")
    
    # Add main title
    summary_ws['A1'] = "Exploratory Data Analysis (EDA) - Summary Report"
    summary_ws['A1'].font = summary_title_font
    summary_ws.merge_cells('A1:D1')
    summary_ws['A1'].alignment = Alignment(horizontal='center')
    
    current_row = 3
    
    # FIXED: Add DYNAMIC Analysis Summary
    if analysis_metadata:
        summary_ws[f'A{current_row}'] = "Analysis Summary:"
        summary_ws[f'A{current_row}'].font = subtitle_font
        summary_ws[f'A{current_row}'].fill = highlight_fill
        current_row += 1
        
        # DYNAMIC summary lines generation
        summary_lines = generate_dynamic_summary_lines(analysis_metadata)
        
        for line in summary_lines:
            if line.strip():  # Only add non-empty lines
                summary_ws[f'A{current_row}'] = line
                summary_ws[f'A{current_row}'].font = normal_font
                current_row += 1
            else:
                current_row += 1  # Process empty lines normally
        
        current_row += 1  # Add some spacing
    else:
        # Fallback if no metadata
        summary_ws[f'A{current_row}'] = "Analysis Summary: No metadata available"
        summary_ws[f'A{current_row}'].font = subtitle_font
        summary_ws[f'A{current_row}'].fill = highlight_fill
        current_row += 3
    
    # Add charts to summary sheet with DYNAMIC layout
    if charts:
        summary_ws[f'A{current_row}'] = "Analysis Charts:"
        summary_ws[f'A{current_row}'].font = subtitle_font
        summary_ws[f'A{current_row}'].fill = highlight_fill
        current_row += 2
        
        # DYNAMIC chart layout based on available charts
        current_row = add_charts_dynamically(summary_ws, charts, current_row, chart_buffers)
        current_row += 2  # Add spacing before tables
    
    # Add tables to summary sheet
    if tables:
        summary_ws[f'A{current_row}'] = "Data Tables:"
        summary_ws[f'A{current_row}'].font = subtitle_font
        summary_ws[f'A{current_row}'].fill = highlight_fill
        current_row += 2
        
        for table_name, df in tables.items():
            if df is not None and not df.empty:
                # Add table title
                # Add table title
                table_display_name = table_name.replace('EDA_', '').replace('_', ' ').replace(' And ', ' + ')

                # Handle specific naming pattern - replace the one that ends with "Table 2"
                if "Usage + Have Extra Costs" in table_display_name and table_display_name.endswith("Table 2"):
                    table_display_name = "Usage + Have Extra Costs, By Total Breakdown"
                else:
                    # Add parentheses around the last number if it exists
                    words = table_display_name.split()
                    if words and words[-1].isdigit():
                        words[-1] = f"({words[-1]})"
                        table_display_name = ' '.join(words)

                summary_ws[f'A{current_row}'] = f"{table_display_name}"
                summary_ws[f'A{current_row}'].font = Font(bold=True, size=12)
                current_row += 1
                
                # Add table summary info
                summary_ws[f'A{current_row}'] = f"Records: {len(df)} rows × {len(df.columns)} columns"
                summary_ws[f'A{current_row}'].font = Font(italic=True, size=10)
                current_row += 1
                
                # Add table data (show all rows)
                display_df = df  # Show all data instead of limiting
                
                # Add headers
                for col_idx, column in enumerate(display_df.columns, 1):
                    cell = summary_ws.cell(row=current_row, column=col_idx, value=str(column))
                    cell.font = header_font
                    cell.fill = header_fill
                    cell.alignment = Alignment(horizontal='center')
                    cell.border = border
                
                current_row += 1
                
                # Add data rows
                for _, row_data in display_df.iterrows():
                    for col_idx, value in enumerate(row_data, 1):
                        cell = summary_ws.cell(row=current_row, column=col_idx)
                        cell.value = str(value) if pd.notna(value) else "N/A"
                        cell.border = border
                        if current_row % 2 == 0:
                            cell.fill = PatternFill(start_color="F8F8F8", end_color="F8F8F8", fill_type="solid")
                    current_row += 1
                
                current_row += 2  # Space between tables
    
    # NEW: Create Forecasts and Cost Savings sheet if data is available
    if forecast_data:
        create_forecast_cost_savings_sheet(wb, forecast_data, chart_buffers)
    
    # NEW: Create Dynamic Learning & Optimization sheet if data is available
    if dynamic_learning_data:
        create_dynamic_learning_optimization_sheet(wb, dynamic_learning_data)
    
    # NEW: Create Final Actions sheet combining EDA and Dynamic Learning data
    if tables and dynamic_learning_data:
        create_final_actions_sheet(wb, tables, dynamic_learning_data)

    # Auto-adjust column widths for summary
    for column_letter in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N']:
        summary_ws.column_dimensions[column_letter].width = 15
    
    # Create directories if they don't exist
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else '.', exist_ok=True)
    
    # Auto-fit all columns in the summary sheet
    auto_fit_columns(summary_ws)

    # Save workbook
    try:
        # 1. Auto-fit columns for all sheets
        for sheet in wb.worksheets:
            auto_fit_columns(sheet)
            # Add padding after auto-fitting
            for col_letter in sheet.column_dimensions:
                current_width = sheet.column_dimensions[col_letter].width
                sheet.column_dimensions[col_letter].width = current_width + 2

        # 2. Find and merge "Explained" cell in Dynamic Learning & Optimization sheet
        for sheet in wb.worksheets:
            if sheet.title == "Dynamic Learning & Optimization":
                for row in sheet.iter_rows():
                    for cell in row:
                        if cell.value == "Explained":
                            # Merge with the cell to the right
                            start_cell = cell.coordinate
                            end_cell = sheet.cell(row=cell.row, column=cell.column + 1).coordinate
                            sheet.merge_cells(f"{start_cell}:{end_cell}")
                            # Center the merged cell
                            cell.alignment = Alignment(horizontal='center', vertical='center')
                            break
                break

        # Convert text numbers to actual numbers for all sheets
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    if cell.value and isinstance(cell.value, str):
                        # Try to convert string numbers to actual numbers
                        try:
                            # Handle currency strings like "$1,234.56"
                            if cell.value.startswith('$'):
                                numeric_value = float(cell.value.replace('$', '').replace(',', ''))
                                cell.value = numeric_value
                                cell.number_format = '"$"#,##0.00'
                            # Handle percentage strings like "45.67%"
                            elif cell.value.endswith('%'):
                                numeric_value = float(cell.value.replace('%', '')) / 100
                                cell.value = numeric_value
                                cell.number_format = '0.00%'
                            # Handle regular number strings with commas like "1,234.56"
                            elif cell.value.replace(',', '').replace('.', '').replace('-', '').isdigit():
                                cell.value = float(cell.value.replace(',', '')) if '.' in cell.value else int(cell.value.replace(',', ''))
                        except (ValueError, AttributeError):
                            pass  # Keep as text if conversion fails


        wb.save(output_path)
        print(f"EDA export completed successfully!")
        print(f"  - Tables exported: {len(tables)}")
        print(f"  - Charts exported: {len(charts)}")
        if forecast_data:
            print(f"  - Forecast tables exported: {len(forecast_data['tables'])}")
            print(f"  - Forecast charts exported: {len(forecast_data['charts'])}")
        if dynamic_learning_data:
            print(f"  - Dynamic learning tables exported: {len(dynamic_learning_data['tables'])}")
        print(f"  - Total sheets: {len(wb.worksheets)}")
        return output_path
    except Exception as e:
        print(f"Error saving workbook: {e}")
        raise
    finally:
        # Now it's safe to close all chart buffers
        for buffer in chart_buffers:
            try:
                buffer.close()
            except:
                pass


# Metadata Handling - Exercise Caution
def extract_dynamic_learning_data(dynamic_learning_tab_widget):
    """
    Extract data from the DynamicLearningTab widget - UPDATED to handle hidden columns
    """
    dynamic_learning_data = {
        'tables': {},
        'metadata': {}
    }
    
    try:
        # Access the dynamic_learning_tables object which contains the table data
        if hasattr(dynamic_learning_tab_widget, 'dynamic_learning_tables'):
            tables_obj = dynamic_learning_tab_widget.dynamic_learning_tables
            
            # Look for QTableWidget in the dynamic learning tab
            from PyQt5.QtWidgets import QTableWidget
            table_widgets = dynamic_learning_tab_widget.findChildren(QTableWidget)
            
            print(f"Found {len(table_widgets)} table widgets in Dynamic Learning tab")
            
            for i, table_widget in enumerate(table_widgets):
                if table_widget and table_widget.rowCount() > 0:
                    # Store information about which columns are hidden
                    hidden_columns = []
                    for col_idx in range(table_widget.columnCount()):
                        if table_widget.isColumnHidden(col_idx):
                            hidden_columns.append(col_idx)
                    
                    print(f"Table {i} has {len(hidden_columns)} hidden columns: {hidden_columns}")
                    
                    # Extract table data INCLUDING hidden columns
                    df = extract_table_data_from_widget(table_widget)
                    if df is not None and not df.empty:
                        # Create table name
                        table_name = "Optimized_Forecast_Analysis"
                        if i > 0:
                            table_name += f"_Table_{i+1}"
                        
                        dynamic_learning_data['tables'][table_name] = df
                        
                        # Store which columns should be hidden in Excel
                        dynamic_learning_data['hidden_columns'] = {
                            table_name: hidden_columns
                        }
                        
                        print(f"Successfully extracted dynamic learning table: {table_name} ({len(df)} rows, {len(df.columns)} columns)")
                        print(f"Columns that should be hidden: {[df.columns[idx] for idx in hidden_columns if idx < len(df.columns)]}")
            
            # Extract metadata if available
            if hasattr(dynamic_learning_tab_widget, 'analysis_results'):
                dynamic_learning_data['metadata']['analysis_results'] = True
            if hasattr(dynamic_learning_tab_widget, 'tabpfn_forecasts'):
                dynamic_learning_data['metadata']['tabpfn_forecasts'] = True
            if hasattr(dynamic_learning_tab_widget, 'accuracy_results'):
                dynamic_learning_data['metadata']['accuracy_results'] = True  
            if hasattr(dynamic_learning_tab_widget, 'cost_savings_results'):
                dynamic_learning_data['metadata']['cost_savings_results'] = True
        
        else:
            print("Warning: dynamic_learning_tables object not found in DynamicLearningTab")
    
    except Exception as e:
        print(f"Error extracting dynamic learning data: {e}")
    
    return dynamic_learning_data

# Used to resolve Number Stored As A Text Error on Excel
def sanitize_excel_value(value):
    """
    Sanitize a value to prevent Excel formula interpretation issues
    """
    if pd.isna(value) or value is None:
        return "N/A"
    
    # Convert to string for processing
    str_value = str(value).strip()
    
    # If empty string, return N/A
    if not str_value:
        return "N/A"
    
    # Check if the value starts with characters that Excel might interpret as formulas
    formula_chars = ['=', '+', '-', '@']
    if any(str_value.startswith(char) for char in formula_chars):
        # Prefix with apostrophe to force Excel to treat as text
        return f"'{str_value}"
    
    # Handle special cases that might cause issues
    if str_value.lower() in ['true', 'false']:
        return f"'{str_value}"  # Force as text
    
    # Check for potential formula patterns (basic check)
    if '=' in str_value and any(func in str_value.upper() for func in ['SUM', 'COUNT', 'IF', 'VLOOKUP', 'INDEX']):
        return f"'{str_value}"
    
    return str_value


# This function is UNIQUE
# What it does is it helps to solve the special symbols and translate them correctlt to excel

def create_dynamic_learning_optimization_sheet(wb, dynamic_learning_data):
    """
    Create the "Dynamic Learning & Optimization" sheet with the optimized forecast table
    UPDATED: Now properly handles hidden columns from the original widget
    """
    # Create the new sheet
    dl_ws = wb.create_sheet(title="Dynamic Learning & Optimization")
    
    # Style definitions
    title_font = Font(bold=True, size=18, color="1F4E79")
    subtitle_font = Font(bold=True, size=14, color="2F4F4F")
    section_font = Font(bold=True, size=12, color="4A4A4A")
    normal_font = Font(size=11)
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    highlight_fill = PatternFill(start_color="E6F3FF", end_color="E6F3FF", fill_type="solid")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Add main title
    dl_ws['A1'] = "Dynamic Learning & Optimization Analysis"
    dl_ws['A1'].font = title_font
    dl_ws.merge_cells('A1:H1')
    dl_ws['A1'].alignment = Alignment(horizontal='center')
    
    current_row = 3
    
    # Add description
    dl_ws[f'A{current_row}'] = "Advanced Dynamic Learning & Optimization"
    dl_ws[f'A{current_row}'].font = subtitle_font
    dl_ws[f'A{current_row}'].fill = highlight_fill
    dl_ws.merge_cells(f'A{current_row}:H{current_row}')
    current_row += 2
    
    # Add metadata summary if available
    if dynamic_learning_data.get('metadata'):
        metadata = dynamic_learning_data['metadata']
        dl_ws[f'A{current_row}'] = "Analysis Components:"
        dl_ws[f'A{current_row}'].font = section_font
        current_row += 1
        
        components = []
        if metadata.get('tabpfn_forecasts'):
            components.append("• TabPFN Machine Learning Forecasts")
        if metadata.get('accuracy_results'):
            components.append("• Forecast Accuracy Analysis")
        if metadata.get('cost_savings_results'):
            components.append("• Cost Savings Optimization")
        if metadata.get('analysis_results'):
            components.append("• Historical Usage Analysis")
        
        for component in components:
            dl_ws[f'A{current_row}'] = component
            dl_ws[f'A{current_row}'].font = normal_font
            current_row += 1
        
        current_row += 2
    
    # Store the row where "Software's Final Suggestion" will be placed
    suggestion_row = current_row
    
    # Add the main table(s) - UPDATED SECTION
    if dynamic_learning_data.get('tables'):
        dl_ws[f'A{current_row}'] = "Software's Final Suggestion"
        dl_ws[f'A{current_row}'].font = subtitle_font
        dl_ws[f'A{current_row}'].fill = highlight_fill
        current_row += 1
    
    # Get hidden column information
    hidden_columns_info = dynamic_learning_data.get('hidden_columns', {})
    
    for table_name, df in dynamic_learning_data['tables'].items():
        if df is not None and not df.empty:
            
            dl_ws[f'A{current_row}'].font = section_font
            current_row += 1
            
            # Add table info
            dl_ws[f'A{current_row}'] = f"Records: {len(df)} materials × {len(df.columns)} analysis columns"
            dl_ws[f'A{current_row}'].font = Font(italic=True, size=10)
            current_row += 1
            
            # UPDATED: Store header row for auto-sizing calculations
            header_row = current_row
            
            # Add table headers with sanitization and wrapping - INCLUDING HIDDEN COLUMNS
            for col_idx, column in enumerate(df.columns, 1):
                cell = dl_ws.cell(row=current_row, column=col_idx, value=sanitize_excel_value(column))
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center', wrap_text=True, vertical='center')
                cell.border = border
            
            current_row += 1
            
            # UPDATED: Track column widths during data insertion
            column_widths = {}
            
            # Add table data with sanitization (show all rows since this is the primary data)
            for i, (_, row_data) in enumerate(df.iterrows()):
                for col_idx, value in enumerate(row_data, 1):
                    cell = dl_ws.cell(row=current_row, column=col_idx)
                    
                    # Sanitize and handle different data types
                    sanitized_value = sanitize_excel_value(value)
                    
                    if pd.isna(value):
                        cell.value = "N/A"
                        cell.font = Font(italic=True, color="808080")
                        cell_width = 4  # Length of "N/A"
                    elif isinstance(sanitized_value, str):
                        # Handle currency and percentage strings
                        if sanitized_value.startswith("'$"):  # Sanitized currency
                            cell.value = sanitized_value
                            cell_width = len(sanitized_value)
                        elif sanitized_value.startswith('$'):
                            try:
                                numeric_value = float(sanitized_value.replace('$', '').replace(',', ''))
                                cell.value = numeric_value
                                cell.number_format = '"$"#,##0.00'
                                cell_width = max(len(f"${numeric_value:,.2f}"), 10)
                            except:
                                cell.value = sanitized_value
                                cell_width = len(sanitized_value)
                        elif sanitized_value.endswith('%'):
                            try:
                                numeric_value = float(sanitized_value.replace('%', '')) / 100
                                cell.value = numeric_value
                                cell.number_format = '0.00%'
                                cell_width = max(len(f"{numeric_value:.2%}"), 8)
                            except:
                                cell.value = sanitized_value
                                cell_width = len(sanitized_value)
                        else:
                            cell.value = sanitized_value
                            cell_width = len(sanitized_value)
                    elif isinstance(value, (int, float)) and not pd.isna(value):
                        cell.value = value
                        if isinstance(value, float):
                            # Check if it looks like a percentage (0-1 range) or currency
                            if 0 <= value <= 1 and col_idx > 1:  # Might be percentage
                                cell.number_format = '0.00%'
                                cell_width = max(len(f"{value:.2%}"), 8)
                            else:
                                cell.number_format = '#,##0.00'
                                cell_width = max(len(f"{value:,.2f}"), 10)
                        else:
                            cell.number_format = '#,##0'
                            cell_width = max(len(f"{value:,}"), 8)
                    else:
                        cell.value = sanitized_value
                        cell_width = len(str(sanitized_value))
                    
                    # Enable text wrapping for long content
                    cell.alignment = Alignment(horizontal='left', vertical='top', wrap_text=True)
                    cell.border = border
                    
                    # Track maximum width for each column
                    col_letter = get_column_letter(col_idx)
                    if col_letter not in column_widths:
                        # Initialize with header width
                        header_cell = dl_ws.cell(row=header_row, column=col_idx)
                        header_width = len(str(header_cell.value)) if header_cell.value else 10
                        column_widths[col_letter] = header_width
                    
                    column_widths[col_letter] = max(column_widths[col_letter], min(cell_width, 50))
                    
                    # Alternate row coloring
                    if current_row % 2 == 0:
                        cell.fill = PatternFill(start_color="F8F8F8", end_color="F8F8F8", fill_type="solid")
                
                # Calculate row height based on actual text wrapping for each cell
                max_lines_needed = 1
                for col_idx, value in enumerate(row_data, 1):
                    col_letter = get_column_letter(col_idx)
                    col_width = column_widths.get(col_letter, 15)
                    
                    # Get the actual content string
                    if pd.isna(value):
                        content_str = "N/A"
                    else:
                        content_str = str(sanitize_excel_value(value))
                    
                    # Calculate actual wrapped lines needed
                    if len(content_str) <= col_width:
                        lines_needed = 1
                    else:
                        # Account for word wrapping - split by spaces and calculate wrapped lines
                        words = content_str.split()
                        if not words:
                            lines_needed = 1
                        else:
                            lines_needed = 1
                            current_line_length = 0
                            
                            for word in words:
                                # If adding this word exceeds column width, start new line
                                if current_line_length + len(word) + 1 > col_width:
                                    if current_line_length > 0:  # Only start new line if current line has content
                                        lines_needed += 1
                                        current_line_length = len(word)
                                    else:
                                        # Single word longer than column width
                                        current_line_length = len(word)
                                else:
                                    current_line_length += len(word) + 1  # +1 for space
                    
                    max_lines_needed = max(max_lines_needed, lines_needed)
                
                # Set row height: 15px base + 18px per line (accounting for padding)
                calculated_height = 25 + (max_lines_needed * 25)
                dl_ws.row_dimensions[current_row].height = calculated_height
                
                current_row += 1
            
            # Apply the calculated column widths
            for col_letter, width in column_widths.items():
                # Add padding and ensure reasonable limits
                adjusted_width = max(min(width + 3, 60), 12)  # Min 12, Max 60 characters
                dl_ws.column_dimensions[col_letter].width = adjusted_width
                print(f"Set column {col_letter} width to {adjusted_width}")
            
            # Set header row height to accommodate wrapped text
            dl_ws.row_dimensions[header_row].height = 30

            # Add instruction text
            dl_ws[f'B{current_row}'] = "End of Table"
            dl_ws[f'B{current_row}'].font = Font(italic=True, size=10, color="808080")

            current_row += 2  # Space after table
    
    else:
        # No tables found
        current_row += 1
    
    print(f"Created Dynamic Learning & Optimization sheet with {current_row} rows of content")
    print(f"Hidden columns preserved and properly exported to Excel")

def create_final_actions_sheet(wb, tables, dynamic_learning_data):
    """
    Create the "Final Actions" sheet combining data from EDA and Dynamic Learning
    """
    # Create the new sheet
    final_ws = wb.create_sheet(title="Final Actions")
    
    # Style definitions
    title_font = Font(bold=True, size=18, color="1F4E79")
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Add main title
    final_ws['A1'] = "Final Actions - Material Requirements Summary"
    final_ws['A1'].font = title_font
    final_ws.merge_cells('A1:E1')
    final_ws['A1'].alignment = Alignment(horizontal='center')
    
    # Get EDA data (Material Code and Description)
    eda_materials = {}
    for table_name, df in tables.items():
        if df is not None and not df.empty:
            for _, row in df.iterrows():
                # Look for material code and description columns
                material_code = None
                material_desc = None
                
                for col in df.columns:
                    col_lower = str(col).lower()
                    if 'material' in col_lower and ('code' in col_lower or 'number' in col_lower):
                        material_code = row[col]
                    elif 'material' in col_lower and ('description' in col_lower or 'desc' in col_lower):
                        material_desc = row[col]
                
                if material_code and material_desc:
                    eda_materials[str(material_code)] = str(material_desc)
    
    # Get Dynamic Learning data
    dl_materials = {}
    if dynamic_learning_data and dynamic_learning_data.get('tables'):
        for table_name, df in dynamic_learning_data['tables'].items():
            if df is not None and not df.empty:
                for _, row in df.iterrows():
                    material_code = None
                    order_qty = None
                    order_deadline = None
                    confidence_score = None
                    
                    for col in df.columns:
                        col_lower = str(col).lower()
                        
                        # Material Code
                        if 'material' in col_lower and ('code' in col_lower or 'number' in col_lower):
                            material_code = row[col]
                        
                        # Order Qty & Deadline (combined column)
                        elif 'order qty' in col_lower and 'deadline' in col_lower:
                            combined_value = str(row[col])
                            
                            # Extract quantity (look for numbers)
                            import re
                            qty_match = re.search(r'(\d+(?:\.\d+)?)', combined_value)
                            if qty_match:
                                order_qty = float(qty_match.group(1))
                            
                            # Extract date (look for date patterns)
                            date_patterns = [
                                r'(\d{4}-\d{2}-\d{2})',  # YYYY-MM-DD
                                r'(\d{2}/\d{2}/\d{4})',  # MM/DD/YYYY
                                r'(\d{2}-\d{2}-\d{4})',  # MM-DD-YYYY
                                r'(\d{1,2}/\d{1,2}/\d{4})',  # M/D/YYYY
                            ]
                            
                            for pattern in date_patterns:
                                date_match = re.search(pattern, combined_value)
                                if date_match:
                                    order_deadline = date_match.group(1)
                                    break
                        
                        # Confidence Score
                        elif 'confidence' in col_lower and 'score' in col_lower:
                            confidence_score = row[col]
                    
                    if material_code:
                        dl_materials[str(material_code)] = {
                            'order_qty': order_qty,
                            'order_deadline': order_deadline,
                            'confidence_score': confidence_score
                        }
    
    # Create final combined data
    final_data = []
    
    # Combine data based on Material Code
    all_material_codes = set(eda_materials.keys()) | set(dl_materials.keys())
    
    for material_code in all_material_codes:
        material_desc = eda_materials.get(material_code, "N/A")
        dl_data = dl_materials.get(material_code, {})
        
        final_data.append({
            'Material Code': material_code,
            'Material Description': material_desc,
            'Order Qty': dl_data.get('order_qty', 'N/A'),
            'Order Deadline': dl_data.get('order_deadline', 'N/A'),
            'Confidence Score': dl_data.get('confidence_score', 'N/A')
        })
    
    # Add table starting from row 3
    current_row = 3
    
    # Add table info
    final_ws[f'A{current_row}'] = f"Combined Material Actions: {len(final_data)} materials"
    final_ws[f'A{current_row}'].font = Font(bold=True, size=12)
    current_row += 2
    
    # Add headers
    headers = ['Material Code', 'Material Description', 'Order Qty', 'Order Deadline', 'Confidence Score']
    for col_idx, header in enumerate(headers, 1):
        cell = final_ws.cell(row=current_row, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = border
    
    current_row += 1
    
    # Add data rows
    for data_row in final_data:
        for col_idx, header in enumerate(headers, 1):
            cell = final_ws.cell(row=current_row, column=col_idx)
            value = data_row[header]
            
            # Handle different data types
            if value == 'N/A' or pd.isna(value):
                cell.value = "N/A"
                cell.font = Font(italic=True, color="808080")
            elif header == 'Order Qty' and isinstance(value, (int, float)):
                cell.value = value
                cell.number_format = '#,##0'
            elif header == 'Confidence Score' and isinstance(value, (int, float)):
                cell.value = value
                if 0 <= value <= 1:
                    cell.number_format = '0.00%'
                else:
                    cell.number_format = '0.00'
            else:
                cell.value = str(value)
            
            cell.border = border
            
            # Alternate row coloring
            if current_row % 2 == 0:
                cell.fill = PatternFill(start_color="F8F8F8", end_color="F8F8F8", fill_type="solid")
        
        current_row += 1
    
    # Auto-fit columns
    auto_fit_columns(final_ws)
    
    print(f"Created Final Actions sheet with {len(final_data)} materials")

def extract_forecast_data(forecast_tab_widget):
    """
    Extract data from the ForecastCostSavingsTab widget
    """
    forecast_data = {
        'tables': {},
        'charts': {},
        'text_content': {}
    }
    
    try:
        # Find the main QTabWidget that contains the three sub-tabs
        from PyQt5.QtWidgets import QTabWidget, QTableWidget
        from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
        
        tab_widgets = forecast_tab_widget.findChildren(QTabWidget)
        main_tab_widget = None
        
        # Find the main tab widget with 3 tabs
        for tab_widget in tab_widgets:
            if tab_widget.count() == 3:  # Should have exactly 3 sub-tabs
                main_tab_widget = tab_widget
                break
        
        if not main_tab_widget:
            print("Warning: Could not find main forecast tab widget")
            return forecast_data
        
        # Extract data from each sub-tab
        for i in range(main_tab_widget.count()):
            tab_name = main_tab_widget.tabText(i)
            tab_widget = main_tab_widget.widget(i)
            
            print(f"Processing forecast tab: {tab_name}")
            
            # Extract tables from this tab
            tables = tab_widget.findChildren(QTableWidget)
            for j, table in enumerate(tables):
                if table and table.rowCount() > 0:
                    df = extract_table_data_from_widget(table)
                    if df is not None and not df.empty:
                        table_key = f"{clean_name(tab_name)}_Table_{j+1}"
                        forecast_data['tables'][table_key] = df
                        print(f"Extracted forecast table: {table_key} ({len(df)} rows)")
            
            # Extract charts from this tab
            canvases = tab_widget.findChildren(FigureCanvas)
            for j, canvas in enumerate(canvases):
                if hasattr(canvas, 'figure') and canvas.figure:
                    chart_key = f"{clean_name(tab_name)}_Chart_{j+1}"
                    forecast_data['charts'][chart_key] = canvas.figure
                    print(f"Extracted forecast chart: {chart_key}")
            
            # Extract text content (labels, info, etc.)
            from PyQt5.QtWidgets import QLabel
            labels = tab_widget.findChildren(QLabel)
            text_content = []
            for label in labels:
                if label.text() and len(label.text().strip()) > 20:  # Only meaningful text
                    text_content.append(label.text())
            
            if text_content:
                forecast_data['text_content'][clean_name(tab_name)] = text_content
    
    except Exception as e:
        print(f"Error extracting forecast data: {e}")
    
    return forecast_data

# NEW FUNCTION - ADD TO export_results.py
def create_forecast_cost_savings_sheet(wb, forecast_data, chart_buffers):
    """
    Create the "Forecasts and Cost Savings" sheet with all forecast data
    """
    # Create the new sheet
    forecast_ws = wb.create_sheet(title="Forecasts and Cost Savings")
    
    # Style definitions
    title_font = Font(bold=True, size=18, color="1F4E79")
    subtitle_font = Font(bold=True, size=14, color="2F4F4F")
    section_font = Font(bold=True, size=12, color="4A4A4A")
    normal_font = Font(size=11)
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
    highlight_fill = PatternFill(start_color="E6F3FF", end_color="E6F3FF", fill_type="solid")
    border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    # Add main title
    forecast_ws['A1'] = "Forecasts and Cost Savings Analysis"
    forecast_ws['A1'].font = title_font
    forecast_ws.merge_cells('A1:H1')
    forecast_ws['A1'].alignment = Alignment(horizontal='center')
    
    current_row = 3
    
    # Process each sub-tab in order: AI Forecast, Accuracy Comparison, Cost Savings
    tab_order = [
        ("TabPFN AI Forecast Predictions", "1. AI Forecast Predictions"),
        ("Accuracy Comparison", "2. Forecast Accuracy Comparison"), 
        ("Cost Variance Analysis", "3. Cost Savings Analysis")
    ]
    
    for tab_key_pattern, section_title in tab_order:
        # Add section header
        forecast_ws[f'A{current_row}'] = section_title
        forecast_ws[f'A{current_row}'].font = subtitle_font
        forecast_ws[f'A{current_row}'].fill = highlight_fill
        forecast_ws.merge_cells(f'A{current_row}:H{current_row}')
        current_row += 2
        
        # Find matching text content
        matching_text_keys = [k for k in forecast_data['text_content'].keys() 
                             if any(pattern in k.lower() for pattern in tab_key_pattern.lower().split())]
        
        for text_key in matching_text_keys:
            text_content = forecast_data['text_content'][text_key]
            for text in text_content:
                # Split long text into multiple lines if needed
                lines = text.split('\n')
                for line in lines:
                    if line.strip():
                        # Skip a row before "Performance Comparison:"
                        if line.strip() == "Performance Comparison:":
                            current_row += 1
                        forecast_ws[f'A{current_row}'] = line.strip()
                        forecast_ws[f'A{current_row}'].font = normal_font
                        current_row += 1
                current_row += 1  # Space after text content
        
        # Find matching tables
        matching_table_keys = [k for k in forecast_data['tables'].keys() 
                              if any(pattern in k.lower() for pattern in tab_key_pattern.lower().split())]
        
        for table_key in matching_table_keys:
            df = forecast_data['tables'][table_key]
            
            # Add table title
            table_title = table_key.replace('_', ' ').replace(' Table 1', '').replace(' Table 2', '').replace(' Table 3', '')
            forecast_ws[f'A{current_row}'] = f"{table_title}"
            forecast_ws[f'A{current_row}'].font = section_font
            current_row += 1
            
            # Add table info
            forecast_ws[f'A{current_row}'] = f"Records: {len(df)} rows × {len(df.columns)} columns"
            forecast_ws[f'A{current_row}'].font = Font(italic=True, size=10)
            current_row += 1
            
            # Add table headers
            for col_idx, column in enumerate(df.columns, 1):
                cell = forecast_ws.cell(row=current_row, column=col_idx, value=str(column))
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center')
                cell.border = border
            
            current_row += 1
            
            # Add table data
            max_rows = len(df)
            for i, (_, row_data) in enumerate(df.head(max_rows).iterrows()):
                for col_idx, value in enumerate(row_data, 1):
                    cell = forecast_ws.cell(row=current_row, column=col_idx)
                    
                    # Handle different data types
                    if pd.isna(value):
                        cell.value = "N/A"
                        cell.font = Font(italic=True, color="808080")
                    elif isinstance(value, str) and value.startswith('$'):
                        # Handle currency
                        try:
                            numeric_value = float(value.replace('$', '').replace(',', ''))
                            cell.value = numeric_value
                            cell.number_format = '"$"#,##0.00'
                        except:
                            cell.value = value
                    elif isinstance(value, (int, float)):
                        cell.value = value
                        if isinstance(value, float):
                            cell.number_format = '#,##0.00'
                    else:
                        cell.value = str(value)
                    
                    cell.border = border
                    
                    # Alternate row coloring
                    if current_row % 2 == 0:
                        cell.fill = PatternFill(start_color="F8F8F8", end_color="F8F8F8", fill_type="solid")
                
                current_row += 1
            
            if len(df) > max_rows:
                forecast_ws[f'A{current_row}'] = f"... and {len(df) - max_rows} more rows"
                forecast_ws[f'A{current_row}'].font = Font(italic=True, size=9)
                current_row += 1
            
            # Add this after the table data processing loop (around line 520)
            if "accuracy" in table_key.lower() and "comparison" in table_key.lower():
                # Find the columns we need
                hist_mape_col = None
                tabpfn_mape_col = None
                improvement_col = None
                
                for col_idx, column in enumerate(df.columns, 1):
                    col_name = str(column).lower()
                    if "historical" in col_name and "mape" in col_name:
                        hist_mape_col = col_idx
                    elif "tabpfn" in col_name and "mape" in col_name:
                        tabpfn_mape_col = col_idx
                    elif "improvement" in col_name:
                        improvement_col = col_idx
                
                # Apply conditional formatting if all columns found
                if hist_mape_col and tabpfn_mape_col and improvement_col:
                    data_start_row = current_row - len(df.head(max_rows))
                    for row_idx in range(data_start_row, current_row):
                        hist_cell = forecast_ws.cell(row=row_idx, column=hist_mape_col)
                        tabpfn_cell = forecast_ws.cell(row=row_idx, column=tabpfn_mape_col)
                        improvement_cell = forecast_ws.cell(row=row_idx, column=improvement_col)
                        
                        try:
                            hist_val = float(str(hist_cell.value).replace('%', ''))
                            tabpfn_val = float(str(tabpfn_cell.value).replace('%', ''))
                            
                            if tabpfn_val < hist_val:  # TabPFN is better (lower MAPE)
                                improvement_cell.fill = PatternFill(start_color="90EE90", end_color="90EE90", fill_type="solid")
                            elif tabpfn_val > hist_val:  # TabPFN is worse (higher MAPE)
                                improvement_cell.fill = PatternFill(start_color="FFB6C1", end_color="FFB6C1", fill_type="solid")
                            # Same values = no color change
                        except (ValueError, TypeError):
                            pass  # Skip if values can't be converted to float


            current_row += 2  # Space between tables
        
        # Find matching charts
        matching_chart_keys = [k for k in forecast_data['charts'].keys() 
                              if any(pattern in k.lower() for pattern in tab_key_pattern.lower().split())]
        
        for chart_key in matching_chart_keys:
            fig = forecast_data['charts'][chart_key]
            
            # Add chart title
            chart_title = chart_key.replace('_', ' ').title()
            forecast_ws[f'A{current_row}'] = f"{chart_title}"
            forecast_ws[f'A{current_row}'].font = section_font
            current_row += 1
            
            # Add chart
            try:
                img_buffer = BytesIO()
                fig.savefig(img_buffer, format='png', dpi=150, bbox_inches='tight', 
                           facecolor='white', edgecolor='none', pad_inches=0.1)
                img_buffer.seek(0)
                
                img = XLImage(img_buffer)
                
                # Resize chart to fit well
                max_width = 1200
                max_height = 1000
                if img.width > max_width or img.height > max_height:
                    width_ratio = max_width / img.width if img.width > max_width else 1
                    height_ratio = max_height / img.height if img.height > max_height else 1
                    ratio = min(width_ratio, height_ratio)
                    img.width = int(img.width * ratio)
                    img.height = int(img.height * ratio)
                
                # Add image to worksheet
                forecast_ws.add_image(img, f'A{current_row}')
                chart_buffers.append(img_buffer)
                
                # Calculate rows to skip based on image height
                rows_to_skip = int(img.height / 18) + 2
                current_row += rows_to_skip
                
            except Exception as e:
                print(f"Error adding chart {chart_key}: {e}")
                forecast_ws[f'A{current_row}'] = f"Error loading chart: {chart_title}"
                current_row += 2
        
        current_row += 3  # Space between sections
    
    # Auto-fit columns
    auto_fit_columns(forecast_ws)
    
    print(f"Created Forecasts and Cost Savings sheet with {current_row} rows of content")

def generate_dynamic_summary_lines(analysis_metadata):
    """
    UPDATED: Generate summary lines for all charts analysis
    """
    summary_lines = []
    
    try:
        # Basic metrics - always include with fallbacks
        total_materials = analysis_metadata.get('total_materials', 'N/A')
        materials_no_usage = analysis_metadata.get('materials_no_usage', 'N/A')
        materials_with_usage = analysis_metadata.get('materials_with_usage', 'N/A')
        
        summary_lines.extend([
  
            f"Total Materials Analyzed: {total_materials}",
           
            f"Materials With No Usage (Last 12 Periods): {materials_no_usage}",
           
            f"Materials With Usage (Last 12 Periods): {materials_with_usage}",
            ""
        ])
        
        # Insights section - only if available and not empty
        insights = analysis_metadata.get('insights', {})
        if insights and isinstance(insights, dict) and len(insights) > 0:
            summary_lines.append("Detailed Analysis Results:")
            
            # Define expected insight keys with fallback names
            insight_mappings = [
                ("Materials With Usage AND No Supplier Records", "Usage + No Supplier Records"),
                ("Materials With Usage AND No Current Stock", "Usage + No Current Stock"),
                ("Materials With Usage AND Have Extra Costs", "Usage + Have Extra Costs"),
                ("materials_with_usage_no_supplier", "Usage + No Supplier Records"),
                ("materials_with_usage_no_stock", "Usage + No Current Stock"),  
                ("materials_with_usage_extra_costs", "Usage + Have Extra Costs")
            ]
            
            insights_found = False
            for key, display_name in insight_mappings:
                if key in insights:
                    insight_data = insights[key]
                    if isinstance(insight_data, list):
                        count = len(insight_data)
                    elif isinstance(insight_data, (int, float)):
                        count = insight_data
                    else:
                        count = "N/A"
                    
                    summary_lines.append(f"• {display_name}: {count}")
                    insights_found = True
            
            if not insights_found:
                # Fallback: list all available insights
                for key, value in insights.items():
                    if isinstance(value, list):
                        count = len(value)
                    elif isinstance(value, (int, float)):
                        count = value
                    else:
                        count = "N/A"
                    
                    # Clean up key name for display
                    display_key = key.replace('_', ' ').title()
                    summary_lines.append(f"• {display_key}: {count}")
        else:
            summary_lines.append("Detailed Analysis Results: No additional insights available")
        
        # Add note about comprehensive analysis
        summary_lines.extend([
            "",
            "This analysis includes 7 comprehensive charts covering:",
            "• Overall material distribution and usage patterns",
            "• Supplier record completeness analysis", 
            "• Financial impact assessment with extra costs",
            "• Top materials identification by cost impact",
            "• Statistical summaries and key performance indicators"
        ])
    
    except Exception as e:
        print(f"Warning: Error generating summary lines: {e}")
        summary_lines = [
            "Analysis Summary: Error generating detailed summary",
            f"Error details: {str(e)}"
        ]
    
    return summary_lines

def add_charts_dynamically(summary_ws, charts, start_row, chart_buffers):
    """
    CORRECTED: Layout for all 10 charts with Charts 7 & 8 on separate rows:
    Row 1: Chart 01 (full width)
    Row 2: Chart 02 + Chart 03 (side by side)
    Row 3: Chart 04 + Chart 05 (side by side) 
    Row 4: Chart 06 (full width)
    Row 5: Chart 07 (full width)
    Row 6: Chart 08 (full width)
    Row 7: Chart 09 (full width)
    Row 8: Chart 10 (full width)
    """
    if not charts:
        return start_row
    
    current_row = start_row
    chart_list = list(charts.items())
    
    # Define the layout pattern for all 10 charts - Charts 7 & 8 get their own rows
    layout_pattern = [
        {"charts": [0], "layout": "single"},           # Chart 01: Complete Material Analysis Overview
        {"charts": [1, 2], "layout": "double"},        # Charts 02 + 03: Usage Distribution + Supplier Records
        {"charts": [3, 4], "layout": "double"},        # Charts 04 + 05: Stock Status + Extra Costs  
        {"charts": [5], "layout": "single"},           # Chart 06: Material Analysis Summary
        {"charts": [6], "layout": "single"},           # Chart 07: Material Categories Detailed View (own row)
        {"charts": [7], "layout": "single"},           # Chart 08: Extra Costs By Classification (own row)
        {"charts": [8], "layout": "single"},           # Chart 09: Top Materials By Extra Cost
        {"charts": [9], "layout": "single"},           # Chart 10: Final Summary Statistics
    ]
    
    for pattern in layout_pattern:
        # Check if we have charts for this pattern
        available_charts = []
        for chart_idx in pattern["charts"]:
            if chart_idx < len(chart_list):
                available_charts.append(chart_list[chart_idx])
        
        if not available_charts:
            break  # No more charts available
        
        if pattern["layout"] == "single":
            # Single chart - full width (columns A-H)
            chart_name, fig = available_charts[0]
            current_row = add_single_chart_to_summary(
                summary_ws, fig, chart_name, current_row, chart_buffers,
                width_cols=8, start_col='A'
            )
            
        elif pattern["layout"] == "double":
            # Two charts side by side
            temp_row = current_row
            max_row = current_row
            
            # First chart (columns A-E) 
            if len(available_charts) >= 1:
                chart_name1, fig1 = available_charts[0]
                row1 = add_single_chart_to_summary(
                    summary_ws, fig1, chart_name1, current_row, chart_buffers,
                    width_cols=5, start_col='A'
                )
                max_row = max(max_row, row1)
            
            # Second chart with 1 column gap
            if len(available_charts) >= 2:
                chart_name2, fig2 = available_charts[1]
                row2 = add_single_chart_to_summary(
                    summary_ws, fig2, chart_name2, current_row, chart_buffers,
                    width_cols=5, start_col='I'
                )
                max_row = max(max_row, row2)
            
            current_row = max_row
        
        # Add spacing between chart rows (1 empty row)
        current_row += 1
    
    return current_row

def add_single_chart_to_summary(summary_ws, fig, chart_name, start_row, chart_buffers, width_cols=7, start_col='A'):
    """
    IMPROVED: Add a single chart to the summary sheet with better sizing and positioning
    """
    try:
        # Add chart title
        title_cell = f'{start_col}{start_row}'
        clean_title = clean_chart_title(chart_name)
        summary_ws[title_cell] = clean_title
        summary_ws[title_cell].font = Font(bold=True, size=11)
        
        # Manual chart dimensions based on chart name
        chart_dimensions = {
            'Chart_01_': {'width': 798, 'height': 397},   
            'Chart_02_': {'width': 645, 'height': 346},   
            'Chart_03_': {'width': 1019, 'height': 298},    
            'Chart_04_': {'width': 945, 'height': 376},    
            'Chart_05_': {'width': 945, 'height': 367},    
            'Chart_06_': {'width': 1145, 'height': 431},  
            'Chart_07_': {'width': 1145, 'height': 431},  
            'Chart_08_': {'width': 788, 'height': 605},   
            'Chart_09_': {'width': 1060, 'height': 417},   
            'Chart_10_': {'width': 1247, 'height': 439}    
        }

        # Find matching dimensions
        chart_width = 800  # default
        chart_height = 400  # default

        for key, dims in chart_dimensions.items():
            if chart_name.startswith(key):
                chart_width = dims['width']
                chart_height = dims['height']
                break

        # Add chart image
        img_buffer = BytesIO()
        fig.savefig(img_buffer, format='png', dpi=150, bbox_inches='tight', 
                   facecolor='white', edgecolor='none', pad_inches=0.1)
        img_buffer.seek(0)
        
        img = XLImage(img_buffer)
        img.width = chart_width
        img.height = chart_height
        
        # Position chart one row below title
        chart_cell = f'{start_col}{start_row + 1}'
        summary_ws.add_image(img, chart_cell)
        
        # Keep buffer alive
        chart_buffers.append(img_buffer)
        
        # Calculate rows occupied (approximate)
        rows_occupied = int(chart_height / 18) + 2  # Title + image height
        
        return start_row + rows_occupied
        
    except Exception as e:
        print(f"Warning: Could not add chart {chart_name} to summary: {e}")
        return start_row + 15  # Return reasonable fallback

def clean_chart_title(chart_name):
    """
    Clean up chart names to match your desired format
    """
    # Remove chart number prefix and clean up
    clean_name = chart_name
    
    # Remove "Chart_XX_" prefix
    if chart_name.startswith('Chart_'):
        parts = chart_name.split('_', 2)
        if len(parts) >= 3:
            clean_name = parts[2]
    
    # Replace underscores with spaces and title case
    clean_name = clean_name.replace('_', ' ').title()
    
    # Fix common abbreviations and terms
    replacements = {
        'Eda': 'EDA',
        'And': 'and',
        'With': 'with',
        'The': 'the',
        'Of': 'of',
        'By': 'by',
        'In': 'in',
        'On': 'on',
        'For': 'for'
    }
    
    words = clean_name.split()
    for i, word in enumerate(words):
        if word in replacements and i > 0:  # Don't replace first word
            words[i] = replacements[word]
        elif word in replacements and i == 0:
            # Special case for first word
            if word == 'Eda':
                words[i] = 'EDA'
    
    return ' '.join(words)

def clean_sheet_name(name):
    """Clean sheet name for Excel compatibility"""
    # Remove invalid characters and limit length
    invalid_chars = ['\\', '/', '*', '[', ']', ':', '?']
    clean_name = str(name)
    for char in invalid_chars:
        clean_name = clean_name.replace(char, '_')
    
    # Remove extra spaces and replace with underscores
    clean_name = '_'.join(clean_name.split())
    
    # Limit length and ensure it's not empty
    clean_name = clean_name[:31] if clean_name else "Sheet1"
    return clean_name

def add_dataframe_to_sheet(ws, df, header_font, header_fill, title_font, border, original_name):
    """Add a pandas DataFrame to a worksheet with enhanced formatting and Excel sanitization"""
    # Add title with better formatting
    ws['A1'] = f"EDA Data: {original_name}"
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='center')
    
    # Add summary row
    ws['A2'] = f"Records: {len(df)} materials × {len(df.columns)} columns"
    ws['A2'].font = Font(italic=True, size=12)
    
    # Add DataFrame starting from row 4
    start_row = 4
    
    # Add headers with styling and sanitization
    for col_idx, column in enumerate(df.columns, 1):
        cell = ws.cell(row=start_row, column=col_idx, value=sanitize_excel_value(column))
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = border
    
    # Add data with formatting and sanitization
    for row_idx, row_data in enumerate(df.values, start_row + 1):
        for col_idx, value in enumerate(row_data, 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            
            # Sanitize the value first
            sanitized_value = sanitize_excel_value(value)
            
            # Handle different data types
            if pd.isna(value):
                cell.value = "N/A"
                cell.font = Font(italic=True, color="808080")
            elif isinstance(sanitized_value, str) and sanitized_value.startswith("'$"):
                # Sanitized currency - keep as text
                cell.value = sanitized_value
            elif isinstance(sanitized_value, str) and sanitized_value.startswith('$'):
                # Handle currency strings
                try:
                    numeric_value = float(sanitized_value.replace('$', '').replace(',', ''))
                    cell.value = numeric_value
                    cell.number_format = '"$"#,##0.00'
                except:
                    cell.value = sanitized_value
            elif isinstance(value, (int, float)) and not pd.isna(value):
                cell.value = value
                if isinstance(value, float):
                    cell.number_format = '#,##0.00'
                else:
                    cell.number_format = '#,##0'
            else:
                cell.value = sanitized_value
            
            cell.border = border
            
            # Alternate row coloring
            if row_idx % 2 == 0:
                cell.fill = PatternFill(start_color="F8F8F8", end_color="F8F8F8", fill_type="solid")
    
    # Auto-adjust column widths with limits
    for column_cells in ws.columns:
        max_length = 0
        column_letter = get_column_letter(column_cells[0].column)
        
        for cell in column_cells:
            try:
                cell_length = len(str(cell.value))
                if cell_length > max_length:
                    max_length = cell_length
            except:
                pass
        
        # Set width with reasonable limits
        adjusted_width = min(max(max_length + 2, 10), 50)
        ws.column_dimensions[column_letter].width = adjusted_width
    
    # Freeze the header row
    ws.freeze_panes = f"A{start_row + 1}"

def add_chart_to_sheet(ws, fig, chart_name, title_font):
    """Add a matplotlib figure to a worksheet as an image - FIXED: Return buffer to keep alive"""
    # Add title
    ws['A1'] = f"EDA Chart: {chart_name}"
    ws['A1'].font = title_font
    ws['A1'].alignment = Alignment(horizontal='center')
    
    # Add chart info
    ws['A2'] = "Generated from EDA analysis data"
    ws['A2'].font = Font(italic=True, size=10, color="666666")
    
    # Save figure to BytesIO with high quality
    img_buffer = BytesIO()
    fig.savefig(img_buffer, format='png', dpi=300, bbox_inches='tight', 
                facecolor='white', edgecolor='none', pad_inches=0.2)
    img_buffer.seek(0)
    
    # Create Excel image and add to worksheet
    img = XLImage(img_buffer)
    
    # Resize image to fit well in Excel while maintaining aspect ratio
    max_width = 1000
    max_height = 600
    
    if img.width > max_width or img.height > max_height:
        width_ratio = max_width / img.width if img.width > max_width else 1
        height_ratio = max_height / img.height if img.height > max_height else 1
        ratio = min(width_ratio, height_ratio)
        
        img.width = int(img.width * ratio)
        img.height = int(img.height * ratio)
    
    # Position image starting from row 4
    ws.add_image(img, 'A4')
    
    # Set minimum row height to accommodate the image
    ws.row_dimensions[4].height = max(img.height * 0.75, 300)
    
    # FIXED: Return the buffer instead of closing it immediately
    # The caller will close it after the workbook is saved
    return img_buffer