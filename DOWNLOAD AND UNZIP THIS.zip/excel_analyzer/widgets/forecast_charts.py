from PyQt5.QtWidgets import QWidget, QVBoxLayout
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import numpy as np

class ForecastCharts:
    def __init__(self):
        pass

    def _get_dynamic_y_limit(self, max_value):
        """Calculate dynamic y-axis limit based on the maximum value"""
        if max_value == 0:
            return 1
        
        # Handle negative values
        if max_value < 0:
            return 0
        
        # Determine the scale based on the magnitude
        if max_value < 1:
            # For decimal values, round up to next 0.1
            return round(max_value + 0.1, 1)
        elif max_value < 10:
            # For single digits, add 2
            return int(max_value) + 1
        elif max_value < 100:
            # For tens, round up to next 15
            return ((int(max_value) // 10) + 1) * 15
        elif max_value < 1000:
            # For hundreds, round up to next 150
            return ((int(max_value) // 100) + 1) * 150
        elif max_value < 10000:
            # For thousands, round up to next 1500
            return ((int(max_value) // 1000) + 1) * 1500
        else:
            # For larger values, round up to next 15000
            return ((int(max_value) // 10000) + 1) * 15000

    def create_summary_charts(self, results, model_type):
        """Create summary charts for accuracy comparison"""
        if not results:
            return None
            
        # Prepare data
        hist_mape = [r['Historical Forecast MAPE'] for r in results]
        ai_mape = [r['AI Forecast MAPE'] for r in results]
        improvements = [r['Improvement'] for r in results]
        
        # Create figure (reduced to 2 subplots now)
        fig = Figure(figsize=(14, 14))  # Adjusted size
        plt.rcParams.update({
            'font.size': 18,            # Default font size
            'axes.titlesize': 20,       # Title font size
            'axes.labelsize': 18,       # Axis label font size
            'xtick.labelsize': 16,      # X-axis tick label size
            'ytick.labelsize': 16,      # Y-axis tick label size
            'legend.fontsize': 16,      # Legend font size
        })
    
        # Chart 1 (now becomes the improvement bar chart)
        ax1 = fig.add_subplot(211)
        
        # Count improvements vs deteriorations
        positive_improvements = [imp for imp in improvements if imp > 0]
        negative_improvements = [imp for imp in improvements if imp < 0]
        no_change = [imp for imp in improvements if imp == 0]
        
        categories = ['Better\n(Lower MAPE)', 'Worse\n(Higher MAPE)', 'No Change']
        counts = [len(positive_improvements), len(negative_improvements), len(no_change)]
        colors = ['green', 'red', 'gray']
        
        bars = ax1.bar(categories, counts, color=colors, alpha=0.7, edgecolor='black')
        ax1.set_title(f'{model_type} Forecast Performance vs Historical Forecast')
        ax1.set_ylabel('Number of Materials')
        
        # Set dynamic y-axis for Chart 1
        max_count = max(counts) if counts else 0
        ax1.set_ylim(0, self._get_dynamic_y_limit(max_count))
        
        # Add value labels on bars
        for bar, count in zip(bars, counts):
            if count > 0:
                ax1.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.1,
                        f'{count}', ha='center', va='bottom', fontweight='bold')
        
        # Chart 2: Side-by-side comparison bar chart
        ax2 = fig.add_subplot(212)
        
        # Calculate average MAPE for each method
        avg_hist_mape = np.mean(hist_mape)
        avg_ai_mape = np.mean(ai_mape)
        
        methods = ['Historical\nForecast', f'{model_type}\nForecast']
        avg_mapes = [avg_hist_mape, avg_ai_mape]
        colors = ['lightblue', 'lightgreen']
        
        bars = ax2.bar(methods, avg_mapes, color=colors, alpha=0.7, edgecolor='black')
        ax2.set_title('Average MAPE Comparison')
        ax2.set_ylabel('Average MAPE (%)')
        
        # Set dynamic y-axis for Chart 2
        max_avg_mape = max(avg_mapes)
        ax2.set_ylim(0, self._get_dynamic_y_limit(max_avg_mape))
        
        # Add value labels on bars
        for bar, mape in zip(bars, avg_mapes):
            ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.1,
                    f'{mape:.1f}%', ha='center', va='bottom', fontweight='bold')
        
        # Add improvement annotation
        improvement_pct = avg_hist_mape - avg_ai_mape 
        if improvement_pct > 0:
            ax2.text(0.5, max(avg_mapes) * 0.8, f'{improvement_pct:.1f}% Improvement', 
                    ha='center', va='center', fontsize=12, fontweight='bold', 
                    bbox=dict(boxstyle="round,pad=0.3", facecolor="yellow", alpha=0.7))
        elif improvement_pct < 0:
            ax2.text(0.5, max(avg_mapes) * 0.8, f'{abs(improvement_pct):.1f}% Worse', 
                    ha='center', va='center', fontsize=12, fontweight='bold', 
                    bbox=dict(boxstyle="round,pad=0.3", facecolor="orange", alpha=0.7))
        
        # Add grid for better readability
        for ax in [ax1, ax2]:
            ax.grid(True, alpha=0.3)
        
        fig.tight_layout()
        return fig