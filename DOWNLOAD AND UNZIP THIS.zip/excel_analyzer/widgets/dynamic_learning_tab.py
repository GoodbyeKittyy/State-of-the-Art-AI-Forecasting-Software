import time
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QScrollArea, QSizePolicy)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QFontMetrics

# Import the new worker and tables modules
from excel_analyzer.dynamic_learning_worker import DynamicLearningWorker
from excel_analyzer.widgets.dynamic_learning_tables import DynamicLearningTables

class DynamicLearningTab(QWidget):
    def __init__(self, analysis_results):
        super().__init__()
        self._start_time = time.time()
        self.analysis_results = analysis_results
        
        # Initialize the worker
        self.worker = DynamicLearningWorker()
        self.tabpfn_forecasts = None # Will be populated by worker
        self.accuracy_results = None # Will be populated by worker
        self.cost_savings_results = None # Will be populated by worker

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        
        # Create scroll area for the single table
        scroll = QScrollArea()
        widget = QWidget()
        table_layout = QVBoxLayout()
        
        # Run all analysis in the background first
        self._run_background_analysis()
        
        # Create the optimized forecast table using the new class
        self.dynamic_learning_tables = DynamicLearningTables(
            self.analysis_results,
            self.tabpfn_forecasts,
            self.accuracy_results,
            self.cost_savings_results,
            self.worker # Pass the worker instance
        )
        self.dynamic_learning_tables.create_optimized_forecast_table(table_layout)
        
        widget.setLayout(table_layout)
        scroll.setWidget(widget)
        scroll.setWidgetResizable(True)
        layout.addWidget(scroll)
        self.setLayout(layout)

    def _run_background_analysis(self):
        """Run all analysis in the background but don't display the tabs"""
        historical_usage = self.analysis_results['sheets']['Historical Usage']
        historical_forecast = self.analysis_results['sheets']['Historical Forecast']
        financial_data = self.analysis_results['sheets']['Financial Standard Price']
        
        # Get period columns using worker's method
        usage_periods = self.worker._get_period_columns(historical_usage)
        forecast_periods = self.worker._get_period_columns(historical_forecast)
        
        # ADD PROGRESS TRACKING HERE
        total_materials = len(historical_usage['Material Code'].unique())
        print(f"Starting analysis for {total_materials} material codes...")
        
        # Generate TabPFN forecasts using worker's method
        self.tabpfn_forecasts = self.worker._generate_tabpfn_forecasts(historical_usage, usage_periods)
        print(f"Completed TabPFN forecasts for {len(self.tabpfn_forecasts)} materials")
        
        # Calculate accuracy metrics using worker's method
        if len(usage_periods) > 0 and len(forecast_periods) > 0:
            common_periods = sorted(list(set(usage_periods).intersection(set(forecast_periods))))
            material_codes = list(set(historical_usage['Material Code']).intersection(
                set(historical_forecast['Material Code'])))
            
            if len(common_periods) >= 2:
                self.accuracy_results = self.worker._calculate_existing_period_accuracy(
                    historical_usage, historical_forecast, material_codes, common_periods)
                print(f"Completed accuracy analysis for {len(self.accuracy_results)} materials")
        
        # Calculate cost savings using worker's method
        if 'Financial Standard Price' in self.analysis_results['sheets']:
            self.cost_savings_results = self.worker._calculate_cost_savings(
                historical_usage, historical_forecast, financial_data, common_periods)
            print(f"Completed cost savings analysis for {len(self.cost_savings_results)} materials")
        
        print("Background analysis completed!")
