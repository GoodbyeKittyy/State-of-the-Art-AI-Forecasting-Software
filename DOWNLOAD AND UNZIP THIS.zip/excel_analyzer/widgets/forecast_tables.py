from PyQt5.QtWidgets import (QTableWidget, QTableWidgetItem, QHeaderView)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

class ForecastTables:
    def __init__(self):
        pass

    def _configure_table_size(self, table):
        """Configure table to be larger"""
        table.setMinimumHeight(600)  # Increased from default
        table.setMinimumWidth(800)   # Increased from default
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        table.verticalHeader().setDefaultSectionSize(30)  # Taller rows

    def _configure_dynamic_table_size(self, table):
        """Configure table with dynamic sizing for cost variance analysis"""
        # Remove minimum size constraints to allow full dynamic resizing
        table.setMinimumHeight(0)
        table.setMinimumWidth(0)
        
        # Set horizontal header to resize based on content, then stretch to fill
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        table.horizontalHeader().setStretchLastSection(True)
        
        # Set vertical header to resize based on content and available space
        table.verticalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)
        
        # Enable word wrap for better text fitting
        table.setWordWrap(True)
        
        # Set size policy to expand and contract with parent widget
        from PyQt5.QtWidgets import QSizePolicy
        table.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # Auto-adjust row height based on content
        table.resizeRowsToContents()

    def create_ai_forecast_table(self, forecasts, next_period):
        """Create table for AI forecast predictions"""
        table = QTableWidget()
        table.setRowCount(len(forecasts))
        table.setColumnCount(3)
        table.setHorizontalHeaderLabels([
            'Material Code', 
            f'Forecasted Usage for Next Period  ({next_period})',
            'Forecast Method'
        ])
        
        for i, (material_code, forecast_data) in enumerate(forecasts.items()):
            table.setItem(i, 0, QTableWidgetItem(str(material_code)))
            table.setItem(i, 1, QTableWidgetItem(f"{forecast_data['forecast']:.0f}"))
            table.setItem(i, 2, QTableWidgetItem(forecast_data['method']))
        
        self._configure_table_size(table)
        table.sortItems(0, Qt.AscendingOrder)  # Added this line
        return table

    def create_accuracy_comparison_table(self, results, has_tabpfn):
        """Create table for accuracy comparison"""
        table = QTableWidget()
        table.setRowCount(len(results))
        table.setColumnCount(4)
        
        # Dynamic header based on model availability
        ai_method = "TabPFN AI Forecast MAPE" if has_tabpfn else "Statistical Fallback Forecast MAPE"
        table.setHorizontalHeaderLabels([
            'Material Code', 
            'Historical Forecasted Usage MAPE',
            'TabPFN AI Forecasted Usage MAPE',
            'Improvement'
        ])
        
        for i, result in enumerate(results):
            table.setItem(i, 0, QTableWidgetItem(str(result['Material Code'])))
            table.setItem(i, 1, QTableWidgetItem(f"{result['Historical Forecast MAPE']:.2f}%"))
            table.setItem(i, 2, QTableWidgetItem(f"{result['AI Forecast MAPE']:.2f}%"))
            
            improvement = result['Improvement']
            improvement_item = QTableWidgetItem(f"{improvement:.2f}%")
            
            if improvement > 0:
                improvement_item.setForeground(Qt.darkGreen)
            elif improvement < 0:
                improvement_item.setForeground(Qt.red)
            # if it's exactly 0, we do nothing (default color)
            
            table.setItem(i, 3, improvement_item)
        
        self._configure_table_size(table)
        table.sortItems(0, Qt.AscendingOrder)  # Added this line
        return table

    def create_cost_variance_table(self, variance_data, has_tabpfn):
        """Create table for cost variance analysis with dynamic sizing"""
        table = QTableWidget()
        table.setRowCount(len(variance_data))
        table.setColumnCount(8)
        
        # Dynamic header based on model availability
        ai_method = "TabPFN AI Forecast" if has_tabpfn else "Statistical Fallback Forecast"
        ai_variance_header = f"{ai_method} Cost Variance"
        
        table.setHorizontalHeaderLabels([
            'Material Code',
            'Historical Forecasted Usage',
            'TabPFN AI Forecasted Usage',
            'Actual Usage',
            'Standard Price',
            'Historical Forecast Cost Variance',
            ai_variance_header,
            'Better Forecasting Method'
        ])
        
        for i, data in enumerate(variance_data):
            table.setItem(i, 0, QTableWidgetItem(str(data['Material Code'])))
            table.setItem(i, 1, QTableWidgetItem(f"{data['Historical Forecast']:.2f}"))
            table.setItem(i, 2, QTableWidgetItem(f"{data['AI Forecast']:.2f}"))
            table.setItem(i, 3, QTableWidgetItem(f"{data['Actual Usage']:.2f}"))
            table.setItem(i, 4, QTableWidgetItem(f"${data['Standard Price']:.2f}"))
            table.setItem(i, 5, QTableWidgetItem(f"${data['Historical Forecast Cost Variance']:.2f}"))
            table.setItem(i, 6, QTableWidgetItem(f"${data['AI Forecast Cost Variance']:.2f}"))
            
            better_method_item = QTableWidgetItem(data['Better Forecasting Method'])
            if "Historical" in data['Better Forecasting Method']:
                better_method_item.setForeground(Qt.blue)
            elif "TabPFN" in data['Better Forecasting Method'] or "Statistical" in data['Better Forecasting Method']:
                better_method_item.setForeground(Qt.darkGreen)
            table.setItem(i, 7, better_method_item)
        
        # Use dynamic sizing instead of fixed sizing for cost variance table
        self._configure_dynamic_table_size(table)
        table.sortItems(0, Qt.AscendingOrder)  # Added this line
        return table