import os
import pandas as pd
import numpy as np
import warnings
import subprocess
import sys
import time
import torch
import skfuzzy as fuzz
from skfuzzy import control as ctrl
from deap import base, creator, tools, algorithms
import multiprocessing
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed

warnings.filterwarnings('ignore')

class DynamicLearningWorker:
    def __init__(self):
        self.tabpfn_models = {}
        self.model_performances = {}
        self.tabpfn_model = None
        self._forecast_cache = None
        self._setup_fuzzy_system()
        self._setup_evolutionary_algorithm()
        self._load_tabpfn_model()

    def _load_tabpfn_model(self):
        """Load TabPFN time series model with correct parameters"""
        try:
            print("Loading TabPFN time series model...")
            
            try:
                import tabpfn
            except ImportError:
                print("Installing tabpfn...")
                subprocess.run([sys.executable, "-m", "pip", "install", "tabpfn"], check=True)
            
            from tabpfn import TabPFNRegressor
            
            self.tabpfn_models = {}
            self.model_performances = {}
            
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            configs = [
                {'device': 'cpu', 'random_state': 42},
                {'device': 'cpu', 'random_state': 123},
                {'device': 'cpu', 'random_state': 456},
            ]
            
            for i, config in enumerate(configs):
                self.tabpfn_models[f'model_{i}'] = TabPFNRegressor(**config)
                self.model_performances[f'model_{i}'] = []
            
            self.tabpfn_model = self.tabpfn_models['model_0']
            
            print("✓ TabPFN ensemble loaded successfully!")
            return True
            
        except Exception as e:
            print(f"Error loading TabPFN model: {e}")
            print("Falling back to statistical forecasting methods...")
            self.tabpfn_model = None
            self.tabpfn_models = {}
            return False

    def _setup_fuzzy_system(self):
        """Initialize the fuzzy logic system with robust defaults"""
        # Input variables
        self.accuracy = ctrl.Antecedent(np.arange(0, 101, 1), 'accuracy')
        self.cost_savings = ctrl.Antecedent(np.arange(0, 101, 1), 'cost_savings')
        self.supplier_reliability = ctrl.Antecedent(np.arange(0, 101, 1), 'supplier_reliability')
        self.inventory_risk = ctrl.Antecedent(np.arange(0, 101, 1), 'inventory_risk')
        
        # Output variable
        self.forecast_adjustment = ctrl.Consequent(np.arange(-50, 51, 1), 'forecast_adjustment')
        
        # Automatic membership functions with good overlap
        names = ['low', 'medium', 'high']
        self.accuracy.automf(names=names)
        self.cost_savings.automf(names=names)
        self.supplier_reliability.automf(names=names)
        self.inventory_risk.automf(names=names)
        
        # Output membership
        self.forecast_adjustment['decrease'] = fuzz.trimf(self.forecast_adjustment.universe, [-50, -50, 0])
        self.forecast_adjustment['maintain'] = fuzz.trimf(self.forecast_adjustment.universe, [-25, 0, 25])
        self.forecast_adjustment['increase'] = fuzz.trimf(self.forecast_adjustment.universe, [0, 50, 50])
        
        # Robust rules that always fire
        rules = [
            # Accuracy dominates
            ctrl.Rule(self.accuracy['low'], self.forecast_adjustment['decrease']),
            ctrl.Rule(self.accuracy['high'], self.forecast_adjustment['increase']),
            
            # Cost savings secondary
            ctrl.Rule(self.cost_savings['low'], self.forecast_adjustment['decrease']),
            ctrl.Rule(self.cost_savings['high'], self.forecast_adjustment['increase']),
            
            # Supplier reliability
            ctrl.Rule(self.supplier_reliability['low'], self.forecast_adjustment['decrease']),
            
            # Inventory risk
            ctrl.Rule(self.inventory_risk['high'], self.forecast_adjustment['increase']),
            
            # Default rule (always fires)
            ctrl.Rule(
                self.accuracy['medium'] | 
                self.cost_savings['medium'] | 
                self.supplier_reliability['medium'] | 
                self.inventory_risk['medium'],
                self.forecast_adjustment['maintain']
            )
        ]
        
        self.forecast_ctrl = ctrl.ControlSystem(rules)
        self.forecast_sim = ctrl.ControlSystemSimulation(self.forecast_ctrl)

    def _setup_evolutionary_algorithm(self):
        """Initialize the evolutionary computation parameters"""
        # Create the fitness and individual types if they don't exist
        if not hasattr(creator, "FitnessMin"):
            creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
        if not hasattr(creator, "Individual"):
            creator.create("Individual", list, fitness=creator.FitnessMin)
        
        self.toolbox = base.Toolbox()
        self.toolbox.register("attr_float", np.random.uniform, -1, 1)
        self.toolbox.register("individual", tools.initRepeat, creator.Individual, 
                            self.toolbox.attr_float, n=4)
        self.toolbox.register("population", tools.initRepeat, list, self.toolbox.individual)
        
        # Placeholder evaluate function - will be updated when actually used
        def evaluate(individual):
            return (0,)
            
        self.toolbox.register("mate", tools.cxBlend, alpha=0.5)
        self.toolbox.register("mutate", tools.mutGaussian, mu=0, sigma=1, indpb=0.2)
        self.toolbox.register("select", tools.selTournament, tournsize=3)
        self.toolbox.register("evaluate", evaluate)

    def _get_period_columns(self, df):
        """Get period columns (YYYYMXX format) from dataframe"""
        periods = []
        for col in df.columns:
            if isinstance(col, str) and len(col) == 7 and col[4] == 'M':
                try:
                    year = int(col[:4])
                    month = int(col[5:])
                    if 2000 <= year <= 2100 and 1 <= month <= 12:
                        periods.append(col)
                except:
                    continue
        return sorted(periods)

    def _generate_tabpfn_forecasts(self, historical_usage, usage_periods):
        """Generate forecasts using TabPFN model with parallel processing - FORWARD LOOKING"""
        
        if self._forecast_cache is not None:
            return self._forecast_cache
        
        forecasts = {}
        
        # Load TabPFN model if not already loaded
        if self.tabpfn_model is None:
            self._load_tabpfn_model()
        
        if self.tabpfn_model is None or len(usage_periods) < 3:
            # Use fallback method with parallel processing
            def process_material_fallback(row_data):
                material_code, row_values = row_data
                usage_data = [row_values[period] for period in usage_periods if not pd.isna(row_values[period])]
                forecast = self._fallback_forecast(usage_data, periods=1)
                return material_code, {
                    'forecast': forecast[0] if forecast is not None else 0.0,
                    'method': 'Statistical Fallback'
                }
            
            material_data = [(row['Material Code'], row) for _, row in historical_usage.iterrows()]
            
            max_workers = min(multiprocessing.cpu_count(), len(material_data))
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_material_fallback, data): data[0] for data in material_data}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, result = future.result()
                        forecasts[material_code] = result
                    except Exception as e:
                        material_code = future_to_material[future]
                        print(f"Error processing material {material_code}: {e}")
                        forecasts[material_code] = {'forecast': 0.0, 'method': 'Error Fallback'}
            
            self._forecast_cache = forecasts
            return forecasts
        
        try:
            print(f"Generating forward-looking TabPFN forecasts for {len(historical_usage)} materials...")
            
            def process_single_material(row_data):
                material_code, row_values = row_data
                usage_values = [row_values[period] for period in usage_periods if not pd.isna(row_values[period])]
                
                if len(usage_values) >= 3:
                    try:
                        # Generate FORWARD forecast (next period after all known data)
                        forecast = self._generate_single_ai_forecast(usage_values)
                        return material_code, {
                            'forecast': max(0, forecast),
                            'method': 'TabPFN Regressor'
                        }
                    except Exception as e:
                        print(f"TabPFN failed for material {material_code}: {e}")
                        forecast = self._fallback_forecast(usage_values, periods=1)
                        return material_code, {
                            'forecast': forecast[0] if forecast is not None else 0.0,
                            'method': 'Statistical Fallback (TabPFN Error)'
                        }
                else:
                    forecast = self._fallback_forecast(usage_values, periods=1)
                    return material_code, {
                        'forecast': forecast[0] if forecast is not None else 0.0,
                        'method': 'Statistical Fallback (Short Series)'
                    }
            
            material_data = [(row['Material Code'], row) for _, row in historical_usage.iterrows()]
            
            max_workers = min(8, len(material_data))
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_single_material, data): data[0] for data in material_data}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, result = future.result()
                        forecasts[material_code] = result
                        if len(forecasts) % 50 == 0:
                            print(f"Processed {len(forecasts)}/{len(material_data)} materials")
                    except Exception as e:
                        material_code = future_to_material[future]
                        print(f"Error processing material {material_code}: {e}")
                        forecasts[material_code] = {'forecast': 0.0, 'method': 'Error Fallback'}
            
            print(f"Generated {len(forecasts)} evolutionary computation forward-looking forecasts")
            self._forecast_cache = forecasts
            return forecasts
            
        except Exception as e:
            print(f"TabPFN forecasting failed: {e}")
            # Fallback with parallel processing
            def process_fallback_material(row_data):
                material_code, row_values = row_data
                usage_values = [row_values[period] for period in usage_periods if not pd.isna(row_values[period])]
                forecast = self._fallback_forecast(usage_values, periods=1)
                return material_code, {
                    'forecast': forecast[0] if forecast is not None else 0.0,
                    'method': 'Statistical Fallback (Global Error)'
                }
            
            material_data = [(row['Material Code'], row) for _, row in historical_usage.iterrows()]
            
            max_workers = min(multiprocessing.cpu_count(), len(material_data))
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_fallback_material, data): data[0] for data in material_data}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, result = future.result()
                        forecasts[material_code] = result
                    except Exception as e:
                        material_code = future_to_material[future]
                        forecasts[material_code] = {'forecast': 0.0, 'method': 'Error Fallback'}
            
            self._forecast_cache = forecasts
            return forecasts

    def _create_advanced_time_series_features(self, values):
        """Create advanced time series features optimized for TabPFN"""
        try:
            values = np.array(values)
            if len(values) < 3:
                return None
            
            features = []
            
            # Create features for each time step (starting from index 2 to have enough history)
            for i in range(2, len(values)):
                feature_row = []
                
                # 1. Time-based features
                feature_row.append(i / len(values))  # Normalized time index
                feature_row.append(np.sin(2 * np.pi * i / 12))  # Seasonal component (monthly)
                feature_row.append(np.cos(2 * np.pi * i / 12))  # Seasonal component (monthly)
                
                # 2. Lag features (multiple lags)
                feature_row.append(values[i-1])  # Lag 1
                feature_row.append(values[i-2])  # Lag 2
                
                # 3. Moving averages (different windows)
                ma_2 = np.mean(values[max(0, i-2):i])
                ma_3 = np.mean(values[max(0, i-3):i]) if i >= 3 else ma_2
                feature_row.append(ma_2)
                feature_row.append(ma_3)
                
                # 4. Trend features
                if i >= 3:
                    # Short-term trend
                    short_trend = (values[i-1] - values[i-2])
                    # Medium-term trend
                    medium_trend = (values[i-1] - values[i-3]) / 2
                    feature_row.append(short_trend)
                    feature_row.append(medium_trend)
                else:
                    feature_row.extend([0, 0])
                
                # 5. Volatility features
                if i >= 3:
                    volatility = np.std(values[max(0, i-3):i])
                    feature_row.append(volatility)
                else:
                    feature_row.append(0)
                
                # 6. Momentum features
                if i >= 4:
                    momentum = values[i-1] - values[i-4]
                    feature_row.append(momentum)
                else:
                    feature_row.append(0)
                
                # 7. Relative position features
                if i >= 3:
                    recent_max = np.max(values[max(0, i-3):i])
                    recent_min = np.min(values[max(0, i-3):i])
                    if recent_max != recent_min:
                        relative_pos = (values[i-1] - recent_min) / (recent_max - recent_min)
                    else:
                        relative_pos = 0.5
                    feature_row.append(relative_pos)
                else:
                    feature_row.append(0.5)
                
                # 8. Change rate features
                if i >= 2:
                    change_rate = (values[i-1] - values[i-2]) / (values[i-2] + 1e-8)
                    feature_row.append(change_rate)
                else:
                    feature_row.append(0)
                
                features.append(feature_row)
            
            return np.array(features)
            
        except Exception as e:
            print(f"Advanced feature creation failed: {e}")
            return None

    def _auto_optimize_tabpfn_for_material(self, material_code, values):
        """Auto-optimize TabPFN model selection for specific material"""
        try:
            if len(values) < 5:  # Need minimum data for cross-validation
                return self._generate_single_ai_forecast_fallback(values)
            
            # Create advanced features
            features = self._create_advanced_time_series_features(values)
            if features is None or len(features) < 3:
                return self._generate_single_ai_forecast_fallback(values)
            
            # Prepare training data
            X_train = features[:-1]
            y_train = np.array(values[3:len(features)+2])  # Align with features
            
            if len(X_train) != len(y_train) or len(X_train) < 2:
                return self._generate_single_ai_forecast_fallback(values)
            
            best_model = None
            best_score = float('inf')
            best_forecast = None
            
            # Try different models and find the best one
            for model_name, model in self.tabpfn_models.items():
                try:
                    if len(X_train) >= 2:
                        # Use time series cross-validation for model selection
                        scores = []
                        
                        # Walk-forward validation
                        for split_idx in range(max(2, len(X_train) - 2), len(X_train)):
                            X_train_split = X_train[:split_idx]
                            y_train_split = y_train[:split_idx]
                            X_test_split = X_train[split_idx:split_idx+1]
                            y_test_split = y_train[split_idx:split_idx+1]
                            
                            if len(X_train_split) >= 2:
                                model.fit(X_train_split, y_train_split)
                                pred = model.predict(X_test_split)[0]
                                actual = y_test_split[0]
                                
                                # Calculate MAPE
                                if actual != 0:
                                    mape = abs((actual - pred) / actual) * 100
                                    scores.append(mape)
                        
                        if scores:
                            avg_score = np.mean(scores)
                            
                            # Update model performance tracking
                            if model_name not in self.model_performances:
                                self.model_performances[model_name] = []
                            self.model_performances[model_name].append(avg_score)
                            
                            if avg_score < best_score:
                                best_score = avg_score
                                best_model = model
                                
                                # Generate forecast with best model
                                model.fit(X_train, y_train)
                                X_pred = features[-1:]
                                best_forecast = model.predict(X_pred)[0]
                        
                except Exception as e:
                    print(f"Model {model_name} failed for material {material_code}: {e}")
                    continue
            
            if best_forecast is not None:
                return max(0, round(best_forecast))
            else:
                return self._generate_single_ai_forecast_fallback(values)
                
        except Exception as e:
            print(f"Auto-optimization failed for material {material_code}: {e}")
            return self._generate_single_ai_forecast_fallback(values)
    
    def _generate_single_ai_forecast_fallback(self, prior_values):
        """Enhanced fallback forecast method"""
        try:
            if len(prior_values) == 0:
                return 0.0
            
            # Enhanced statistical forecasting
            values = np.array(prior_values)
            
            if len(values) >= 6:
                # Triple exponential smoothing (Holt-Winters)
                alpha, beta, gamma = 0.3, 0.1, 0.1
                season_length = min(4, len(values) // 2)
                
                # Initialize components
                level = np.mean(values[:season_length])
                trend = (np.mean(values[season_length:2*season_length]) - level) / season_length
                seasonal = values[:season_length] - level
                
                # Apply smoothing
                for i in range(season_length, len(values)):
                    old_level = level
                    level = alpha * (values[i] - seasonal[i % season_length]) + (1 - alpha) * (level + trend)
                    trend = beta * (level - old_level) + (1 - beta) * trend
                    seasonal[i % season_length] = gamma * (values[i] - level) + (1 - gamma) * seasonal[i % season_length]
                
                # Forecast
                forecast = level + trend + seasonal[len(values) % season_length]
                
            elif len(values) >= 3:
                # Enhanced trend analysis with dampening
                x = np.arange(len(values))
                
                # Fit polynomial trend
                if len(values) >= 4:
                    coeffs = np.polyfit(x, values, 2)  # Quadratic
                    trend = 2 * coeffs[0] * len(values) + coeffs[1]  # Derivative at last point
                else:
                    coeffs = np.polyfit(x, values, 1)  # Linear
                    trend = coeffs[0]
                
                # Dampen trend for stability
                dampening_factor = 0.7
                trend *= dampening_factor
                
                # Add seasonal adjustment
                if len(values) >= 4:
                    seasonal_factor = np.mean(values[-2:]) / np.mean(values[:-2]) if np.mean(values[:-2]) != 0 else 1
                    seasonal_factor = min(max(seasonal_factor, 0.5), 2.0)  # Bound the factor
                else:
                    seasonal_factor = 1.0
                
                forecast = (values[-1] + trend) * seasonal_factor
            else:
                # Simple average with trend
                if len(values) >= 2:
                    trend = values[-1] - values[-2]
                    forecast = values[-1] + 0.5 * trend  # Dampened trend
                else:
                    forecast = values[-1]
            
            return max(0, round(forecast))
            
        except Exception as e:
            print(f"Enhanced fallback forecast failed: {e}")
            return max(0, prior_values[-1]) if len(prior_values) > 0 else 0.0

    def _preprocess_features(self, features):
        """Preprocess features for better TabPFN performance"""
        try:
            # Robust scaling
            features_scaled = np.copy(features)
            
            for i in range(features.shape[1]):
                col = features[:, i]
                if np.std(col) > 0:
                    # Use robust scaling (median and IQR)
                    median = np.median(col)
                    q75, q25 = np.percentile(col, [75, 25])
                    iqr = q75 - q25
                    if iqr > 0:
                        features_scaled[:, i] = (col - median) / iqr
                    else:
                        features_scaled[:, i] = col - median
            
            return features_scaled
            
        except Exception as e:
            print(f"Feature preprocessing failed: {e}")
            return features

    def _preprocess_targets(self, targets):
        """Preprocess targets for better TabPFN performance"""
        try:
            # Log transformation for positive values with large variance
            targets_processed = np.copy(targets)
            
            if np.all(targets > 0) and np.std(targets) > np.mean(targets):
                # Apply log transformation to reduce variance
                targets_processed = np.log1p(targets)
            
            return targets_processed
            
        except Exception as e:
            print(f"Target preprocessing failed: {e}")
            return targets

    def _postprocess_target(self, forecast_scaled, original_values):
        """Postprocess forecast to original scale"""
        try:
            # Reverse log transformation if it was applied
            if np.all(np.array(original_values) > 0) and np.std(original_values) > np.mean(original_values):
                forecast = np.expm1(forecast_scaled)
            else:
                forecast = forecast_scaled
            
            # Apply bounds based on historical data
            if len(original_values) > 0:
                historical_max = np.max(original_values)
                historical_mean = np.mean(original_values)
                
                # Bound forecast to reasonable range
                forecast = min(forecast, historical_max * 2.0)  # Max 2x historical max
                forecast = max(forecast, historical_mean * 0.1)  # Min 10% of historical mean
            
            return forecast
            
        except Exception as e:
            print(f"Target postprocessing failed: {e}")
            return forecast_scaled

    def _adaptive_learning_update(self, material_code, actual_value, forecast_value):
        """Update model performance and adapt learning"""
        try:
            if not hasattr(self, 'material_performance'):
                self.material_performance = {}
            
            if material_code not in self.material_performance:
                self.material_performance[material_code] = {
                    'errors': [],
                    'forecasts': [],
                    'actuals': [],
                    'best_model': None
                }
            
            # Calculate error
            if actual_value != 0:
                error = abs((actual_value - forecast_value) / actual_value) * 100
            else:
                error = abs(forecast_value)
            
            # Update performance tracking
            self.material_performance[material_code]['errors'].append(error)
            self.material_performance[material_code]['forecasts'].append(forecast_value)
            self.material_performance[material_code]['actuals'].append(actual_value)
            
            # Keep only recent performance (last 10 periods)
            for key in ['errors', 'forecasts', 'actuals']:
                if len(self.material_performance[material_code][key]) > 10:
                    self.material_performance[material_code][key] = \
                        self.material_performance[material_code][key][-10:]
            
            # Adapt model selection based on performance
            if len(self.material_performance[material_code]['errors']) >= 3:
                avg_error = np.mean(self.material_performance[material_code]['errors'][-3:])
                
                # If performance is poor, try different model configuration
                if avg_error > 20:  # MAPE > 20%
                    print(f"Adapting model for material {material_code} due to poor performance")
                    # This would trigger model reselection in next forecast
                    self.material_performance[material_code]['needs_optimization'] = True
            
        except Exception as e:
            print(f"Adaptive learning update failed: {e}")

    def _calculate_existing_period_accuracy(self, historical_usage, historical_forecast, 
                            material_codes, common_periods):
        """Calculate accuracy by comparing historical forecasts vs AI forecasts for latest period"""
        results = []
        
        if len(common_periods) < 2:
            print("Need at least 2 periods for accuracy calculation")
            return results
        
        # Use only the LATEST period for comparison
        latest_period = common_periods[-1]
        print(f"Calculating accuracy for latest period only: {latest_period}")
        print(f"Analyzing {len(material_codes)} materials...")
        
        # For accuracy calculation, we need to predict the latest period using prior periods
        latest_period_forecasts = self._generate_latest_period_forecasts(
            historical_usage, material_codes, common_periods, latest_period
        )
        
        print("Calculating MAPE for each material...")
        
        def process_material_accuracy(material_code):
            try:
                # Get actual usage for latest period
                usage_row = historical_usage[historical_usage['Material Code'] == material_code]
                if len(usage_row) == 0:
                    return None
                
                actual_val = usage_row[latest_period].values[0]
                if pd.isna(actual_val):  # Only filter out NaN, not zero
                    return None
                
                # Get historical forecast for latest period
                forecast_row = historical_forecast[historical_forecast['Material Code'] == material_code]
                if len(forecast_row) == 0:
                    return None
                
                hist_forecast_val = forecast_row[latest_period].values[0]
                if pd.isna(hist_forecast_val):
                    return None
                
                # Get AI forecast for latest period (predicted from prior periods)
                ai_forecast = latest_period_forecasts.get(material_code, None)
                if ai_forecast is None:
                    return None
                
                # Calculate MAPE for both forecast methods - handle zero actual values
                hist_mape = abs((actual_val - hist_forecast_val) / actual_val) * 100 if actual_val != 0 else 0
                ai_mape = abs((actual_val - ai_forecast) / actual_val) * 100 if actual_val != 0 else 0
                
                # Calculate improvement percentage
                improvement = hist_mape - ai_mape  # Positive means AI is better
                
                return {
                    'Material Code': material_code,
                    'Historical Forecast MAPE': hist_mape,
                    'AI Forecast MAPE': ai_mape,
                    'Improvement': improvement
                }
            except Exception as e:
                print(f"Error processing material {material_code}: {e}")
                return None
        
        # Process materials in parallel
        max_workers = multiprocessing.cpu_count()

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_material = {executor.submit(process_material_accuracy, material_code): material_code 
                                for material_code in material_codes}
            
            for future in as_completed(future_to_material):
                try:
                    result = future.result()
                    if result is not None:
                        results.append(result)
                        if len(results) % 50 == 0:
                            print(f"Processed {len(results)} materials")
                except Exception as e:
                    material_code = future_to_material[future]
                    print(f"Error getting result for material {material_code}: {e}")
        
        print(f"Accuracy analysis complete for {len(results)} materials")
        return results

    def _generate_latest_period_forecasts(self, historical_usage, material_codes, common_periods, latest_period):
        """Generate AI forecasts for the latest period using prior data - FOR ACCURACY CALCULATION ONLY"""
        latest_forecasts = {}
        
        print(f"Generating backward-looking forecasts for accuracy calculation: {latest_period}")
        
        try:
            # Find the index of the latest period
            latest_index = common_periods.index(latest_period)
            if latest_index == 0:
                print("Latest period is the first period - cannot generate forecast")
                return latest_forecasts
            
            # Get all periods before the latest period
            prior_periods = common_periods[:latest_index]
            
            if len(prior_periods) < 2:
                print("Insufficient prior periods for forecasting")
                return latest_forecasts
            
            print(f"Using {len(prior_periods)} prior periods for backward forecasting")
            
            def process_material_forecast(material_code):
                try:
                    usage_row = historical_usage[historical_usage['Material Code'] == material_code]
                    if len(usage_row) == 0:
                        return material_code, None
                    
                    # Get usage values for all prior periods
                    prior_values = []
                    for period in prior_periods:
                        val = usage_row[period].values[0]
                        if not pd.isna(val):
                            prior_values.append(val)
                    
                    if len(prior_values) >= 2:
                        # Generate forecast for latest period using prior data
                        forecast = self._generate_single_ai_forecast(prior_values)
                        return material_code, forecast
                    else:
                        return material_code, None
                except Exception as e:
                    print(f"Error processing material {material_code}: {e}")
                    return material_code, None
            
            # Process materials in parallel
            max_workers = multiprocessing.cpu_count()

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_material_forecast, material_code): material_code for material_code in material_codes}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, forecast = future.result()
                        if forecast is not None:
                            latest_forecasts[material_code] = forecast
                            if len(latest_forecasts) % 50 == 0:
                                print(f"Processed {len(latest_forecasts)} forecasts")
                    except Exception as e:
                        material_code = future_to_material[future]
                        print(f"Error getting result for material {material_code}: {e}")
            
            print(f"Generated {len(latest_forecasts)} evolutionary computation backward-looking forecasts for accuracy calculation")
            return latest_forecasts
            
        except Exception as e:
            print(f"Error generating latest period forecasts: {e}")
            return latest_forecasts

    def _generate_single_ai_forecast(self, prior_values):
            """Generate single AI forecast with proper error handling"""
            try:
                if len(prior_values) < 3:
                    return self._generate_single_ai_forecast_fallback(prior_values)
                
                # Use auto-optimization for better performance
                if hasattr(self, 'tabpfn_models') and self.tabpfn_models:
                    return self._auto_optimize_tabpfn_for_material("temp_material", prior_values)
                
                # Fallback to single model approach
                if self.tabpfn_model is not None:
                    features = self._create_advanced_time_series_features(prior_values)
                    
                    if features is not None and len(features) >= 2:
                        X_train = features[:-1]
                        y_train = np.array(prior_values[3:len(features)+2])
                        
                        if len(X_train) >= 2 and len(y_train) >= 2 and len(X_train) == len(y_train):
                            # Fit and predict
                            self.tabpfn_model.fit(X_train, y_train)
                            
                            X_pred = features[-1:]
                            forecast = self.tabpfn_model.predict(X_pred)[0]
                            
                            return max(0, round(forecast))
                
                return self._generate_single_ai_forecast_fallback(prior_values)
                
            except Exception as e:
                print(f"Error in _generate_single_ai_forecast: {e}")
                return self._generate_single_ai_forecast_fallback(prior_values)

    def _calculate_cost_savings(self, historical_usage, historical_forecast, financial_data, common_periods):
        """Calculate cost savings for each material (simplified version)"""
        if len(common_periods) == 0:
            return []
        
        latest_period = common_periods[-1]
        material_prices = dict(zip(financial_data['Material Code'], financial_data['Standard Price']))
        
        # Generate AI forecasts for latest period
        ai_forecasts = self._generate_latest_period_forecasts(
            historical_usage, 
            list(material_prices.keys()), 
            common_periods, 
            latest_period
        )
        
        results = []
        for material_code in material_prices.keys():
            # Get actual usage
            usage_row = historical_usage[historical_usage['Material Code'] == material_code]
            if usage_row.empty:
                continue
            actual = usage_row[latest_period].values[0]
            if pd.isna(actual):
                continue
            
            # Get historical forecast
            forecast_row = historical_forecast[historical_forecast['Material Code'] == material_code]
            if forecast_row.empty:
                continue
            hist_forecast = forecast_row[latest_period].values[0]
            if pd.isna(hist_forecast):
                continue
            
            # Get AI forecast
            ai_forecast = ai_forecasts.get(material_code, hist_forecast)
            
            # Calculate cost variances
            price = material_prices[material_code]
            hist_variance = abs(hist_forecast - actual) * price
            ai_variance = abs(ai_forecast - actual) * price
            
            # Determine better method
            if hist_variance < ai_variance:
                better_method = "Historical Forecast"
            elif ai_variance < hist_variance:
                better_method = "TabPFN AI Forecast" if self.tabpfn_model else "Statistical Fallback Forecast"
            else:
                better_method = "Equal Performance"
            
            results.append({
                'Material Code': material_code,
                'Historical Forecast Cost Variance': hist_variance,
                'AI Forecast Cost Variance': ai_variance,
                'Better Forecasting Method': better_method
            })
        
        return results

    def _calculate_supplier_reliability(self, po_lead_times, quote_lead_times):
        """Calculate supplier reliability score (0-100)"""
        if len(po_lead_times) == 0 or len(quote_lead_times) == 0:
            return 50
        
        # Calculate percentage of times actual lead time was within 20% of quoted time
        reliability = []
        for po, quote in zip(po_lead_times, quote_lead_times):
            if quote > 0:
                deviation = abs(po - quote) / quote
                reliability.append(1 if deviation <= 0.2 else 0)
        
        if len(reliability) == 0:
            return 50
            
        score = np.mean(reliability) * 100
        return min(100, max(0, score))

    def _calculate_inventory_risk(self, current_stock, shelf_life, moq, reorder_point, min_safety, max_stock, forecast):
        """Calculate inventory risk score (0-100)"""
        try:
            # Handle 'NIL' or None values by converting them to 0
            def safe_float(value):
                if value is None or str(value).upper() == 'NIL':
                    return 0.0
                try:
                    return float(value)
                except:
                    return 0.0

            current_stock = safe_float(current_stock)
            shelf_life = safe_float(shelf_life)
            moq = safe_float(moq)
            reorder_point = safe_float(reorder_point)
            min_safety = safe_float(min_safety)
            max_stock = safe_float(max_stock)
            forecast = safe_float(forecast)

            # Calculate days of supply - handle zero forecast
            if forecast > 0:
                days_of_supply = (current_stock / forecast * 30)
            else:
                days_of_supply = 0  # If no forecast, assume zero days of supply
                
            # Shelf life risk
            shelf_life_risk = 0
            if shelf_life > 0 and days_of_supply > shelf_life * 0.8:
                shelf_life_risk = min(100, (days_of_supply / shelf_life) * 100)
            
            # Stockout risk - handle zero reorder point
            stockout_risk = 0
            if reorder_point > 0 and current_stock < reorder_point:
                stockout_risk = min(100, (1 - (current_stock / reorder_point)) * 100)
            elif reorder_point == 0 and current_stock == 0:
                stockout_risk = 100  # Maximum risk if no stock and no reorder point
            
            # Overstock risk - handle zero max_stock
            overstock_risk = 0
            if max_stock > 0 and current_stock > max_stock * 0.8:
                overstock_risk = min(100, (current_stock / max_stock) * 100)
            elif max_stock == 0 and current_stock > 0:
                overstock_risk = 50  # Medium risk if we have stock but no max defined
                
            # MOQ risk - handle zero MOQ
            moq_risk = 0
            if moq > 0 and forecast < moq * 1.2:
                moq_risk = min(100, (1 - (forecast / moq)) * 50)
            elif moq == 0:
                moq_risk = 0  # No risk if no MOQ
                
            # Combine risks with weights
            total_risk = (
                0.3 * shelf_life_risk +
                0.3 * stockout_risk +
                0.2 * overstock_risk +
                0.2 * moq_risk
            )
            
            return min(100, max(0, total_risk))
            
        except Exception as e:
            print(f"Error calculating inventory risk: {e}")
            return 50  # Return medium risk if calculation fails
        
    def _apply_fuzzy_logic(self, accuracy, cost_savings, supplier_reliability, inventory_risk):
        try:
            # Validate and clamp inputs
            accuracy = max(0, min(100, float(accuracy)))
            cost_savings = max(0, min(100, float(cost_savings)))
            supplier_reliability = max(0, min(100, float(supplier_reliability)))
            inventory_risk = max(0, min(100, float(inventory_risk)))

            # Set inputs
            self.forecast_sim.input['accuracy'] = accuracy
            self.forecast_sim.input['cost_savings'] = cost_savings
            self.forecast_sim.input['supplier_reliability'] = supplier_reliability
            self.forecast_sim.input['inventory_risk'] = inventory_risk
            
            # Compute the system
            self.forecast_sim.compute()
            
            # Return neutral adjustment if no rules fired
            if 'forecast_adjustment' not in self.forecast_sim.output:
                return 0
                
            # Limit adjustment to ±50% to prevent extreme swings
            return max(-50, min(50, self.forecast_sim.output['forecast_adjustment']))
        
        except Exception as e:
            print(f"Fuzzy logic error: {e}")
            return 0

    def _apply_evolutionary_optimization(self, initial_forecast, fuzzy_adjustment, accuracy, inventory_risk, reliability):
        """Apply evolutionary computation to optimize the forecast with realistic constraints"""
        # First, calculate reasonable bounds based on historical data
        min_bound = max(0, initial_forecast * 0.1)  # Never less than 10% of initial
        max_bound = initial_forecast * 3.0  # Never more than 3x initial
        
        def evaluate(individual):
            # Extract weights from individual
            w1, w2, w3, w4 = individual
            
            # Normalize weights
            total = abs(w1) + abs(w2) + abs(w3) + abs(w4)
            if total == 0:
                return (float('inf'),)
            
            w1, w2, w3, w4 = abs(w1)/total, abs(w2)/total, abs(w3)/total, abs(w4)/total
            
            # Calculate components with bounded adjustments
            fuzzy_factor = 1 + (max(-0.5, min(0.5, fuzzy_adjustment/100)))  # Limit fuzzy adjustment to ±50%
            accuracy_component = (100 - min(100, max(0, accuracy))) / 100
            inventory_component = (100 - min(100, max(0, inventory_risk))) / 100
            reliability_component = min(100, max(0, reliability)) / 100
            
            # Calculate final forecast with weights and constraints
            final_forecast = (
                w1 * initial_forecast * fuzzy_factor + 
                w2 * initial_forecast * accuracy_component +
                w3 * initial_forecast * inventory_component +
                w4 * initial_forecast * reliability_component
            )
            
            # Apply hard bounds
            final_forecast = max(min_bound, min(max_bound, final_forecast))
            
            # Calculate confidence score
            confidence = (
                w1 * (100 - min(100, abs(fuzzy_adjustment))) +
                w2 * accuracy_component * 100 +
                w3 * inventory_component * 100 +
                w4 * reliability_component * 100
            ) / (w1 + w2 + w3 + w4)
            
            # Penalize extreme weights
            weight_variance = (
                abs(w1 - 0.25) + abs(w2 - 0.25) + 
                abs(w3 - 0.25) + abs(w4 - 0.25)
            )
            
            return (weight_variance,)
        
        self.toolbox.register("evaluate", evaluate)
        
        # Run evolutionary algorithm
        pop = self.toolbox.population(n=50)
        hof = tools.HallOfFame(1)
        stats = tools.Statistics(lambda ind: ind.fitness.values)
        stats.register("avg", np.mean)
        stats.register("min", np.min)
        stats.register("max", np.max)
        
        algorithms.eaSimple(pop, self.toolbox, cxpb=0.5, mutpb=0.2, 
                        ngen=20, stats=stats, halloffame=hof, verbose=False)
        
        # Get best individual
        best_weights = hof[0]
        
        # Normalize weights
        total = sum(abs(w) for w in best_weights)
        if total == 0:
            weights = [0.25, 0.25, 0.25, 0.25]
        else:
            weights = [abs(w)/total for w in best_weights]
        
        # Recalculate final forecast with same constraints
        fuzzy_factor = 1 + (max(-0.5, min(0.5, fuzzy_adjustment/100)))
        accuracy_component = (100 - min(100, max(0, accuracy))) / 100
        inventory_component = (100 - min(100, max(0, inventory_risk))) / 100
        reliability_component = min(100, max(0, reliability)) / 100
        
        final_forecast = (
            weights[0] * initial_forecast * fuzzy_factor +
            weights[1] * initial_forecast * accuracy_component +
            weights[2] * initial_forecast * inventory_component +
            weights[3] * initial_forecast * reliability_component
        )
        
        # Apply final bounds and rounding
        final_forecast = max(min_bound, min(max_bound, final_forecast))
        final_forecast = round(final_forecast)
        
        # Calculate confidence score
        confidence = (
            weights[0] * (100 - min(100, abs(fuzzy_adjustment))) +
            weights[1] * accuracy_component * 100 +
            weights[2] * inventory_component * 100 +
            weights[3] * reliability_component * 100
        )
        
        return final_forecast, confidence

    def _generate_explanation(self, material_code, initial_forecast, optimized_forecast, 
                                    accuracy_info, cost_info, supplier_data, inventory_data, financial_data):
            """Generate comprehensive, standardized explanation for forecast adjustment with two-column structure"""
            
            # Helper function to safely convert values
            def safe_float(value, default=0.0):
                if value is None or str(value).upper() in ['NIL', 'NULL', '']:
                    return default
                try:
                    return float(value)
                except (ValueError, TypeError):
                    return default
            
            # Helper function to format unavailable data consistently
            def format_unavailable(message="Data not available"):
                return f"   ℹ️  {message}"
            
            # Calculate key metrics upfront
            forecast_change = optimized_forecast - initial_forecast
            forecast_change_pct = (forecast_change / initial_forecast * 100) if initial_forecast > 0 else 0
            
            left_column = []
            right_column = []
            
            # === LEFT COLUMN: FORECAST ADJUSTMENT SUMMARY + CURRENT INVENTORY POSITION ===
            
            # SECTION 1: EXECUTIVE SUMMARY
            left_column.append("=== FORECAST ADJUSTMENT SUMMARY ===")
            if abs(forecast_change) < 0.01:
                left_column.append(f"✓ Forecasted usage maintained at {initial_forecast:,.0f} units - current strategy is optimal")
            else:
                direction = "increased" if forecast_change > 0 else "decreased"
                left_column.append(f"📈 Usage adjusted and {direction} from {initial_forecast:,.0f} to {optimized_forecast:,.0f} units after evolutionary optimization")
                left_column.append(f"   Change: {forecast_change:+,.0f} units ({forecast_change_pct:+.1f}%)")
            
            # SECTION 2: INVENTORY POSITION ANALYSIS
            left_column.append("\n=== CURRENT INVENTORY POSITION ===")
            
            if not inventory_data.empty:
                current_stock = safe_float(inventory_data['Current Stock'].values[0])
                reorder_point = safe_float(inventory_data['Reorder Point'].values[0])
                min_safety = safe_float(inventory_data['Minimum Safety Stock'].values[0])
                max_stock = safe_float(inventory_data['Max Stock'].values[0])
                moq = safe_float(inventory_data['MOQ'].values[0])
                shelf_life = safe_float(inventory_data['Shelf Life Days'].values[0])
                
                # Calculate advanced metrics
                days_of_supply = (current_stock / optimized_forecast * 30) if optimized_forecast > 0 else float('inf') if current_stock > 0 else 0
                
                utilization_rate = current_stock / max_stock if max_stock > 0 else (1.0 if current_stock > 0 else 0)
                
                left_column.append(f"📦 Current Stock: {current_stock:,.0f} units")
                left_column.append(f"📅 Days of Supply: {days_of_supply:.1f} days")
                left_column.append(f"📊 Stock Utilization: {utilization_rate*100:.1f}% of max capacity")
                
                # Stock position assessment with actionable insights
                if current_stock < min_safety:
                    left_column.append(f"🚨 CRITICAL: Below minimum safety stock by {min_safety - current_stock:,.0f} units")
                    left_column.append("   → Immediate action required: Emergency procurement or demand rationing")
                elif current_stock < reorder_point:
                    left_column.append(f"⚠️  Below reorder point by {reorder_point - current_stock:,.0f} units")
                    left_column.append("   → Trigger replenishment order within 24-48 hours")
                elif utilization_rate > 0.85:
                    left_column.append(f"📈 High inventory utilization ({utilization_rate*100:.1f}%)")
                    left_column.append("   → Consider increasing max stock or reducing order frequency")
                elif utilization_rate < 0.3:
                    left_column.append(f"📉 Low inventory utilization ({utilization_rate*100:.1f}%)")
                    left_column.append("   → Potential overstock situation - review demand patterns")
                else:
                    left_column.append("✅ Inventory position is within optimal range")
                
                # MOQ Analysis
                left_column.append(f"\n📋 MOQ Analysis:")
                if moq > 0:
                    moq_multiple = optimized_forecast / moq if moq > 0 else 0
                    left_column.append(f"   Minimum Order Quantity: {moq:,.0f} units")
                    left_column.append(f"   Forecast/MOQ Ratio: {moq_multiple:.2f}")
                    
                    if moq_multiple < 0.5:
                        left_column.append("   ⚠️  Forecast significantly below MOQ - consider:")
                        left_column.append("      • Batch ordering for multiple periods")
                        left_column.append("      • Supplier negotiation for lower MOQ")
                        left_column.append("      • Alternative suppliers")
                    elif moq_multiple > 3:
                        left_column.append("   ✅ Excellent MOQ efficiency - good order economics")
                    else:
                        left_column.append("   ✅ Acceptable MOQ efficiency")
                else:
                    left_column.append(format_unavailable("MOQ information not available"))
                
                # Shelf Life Analysis
                left_column.append(f"\n🕐 Shelf Life Analysis:")
                if shelf_life > 0:
                    shelf_life_risk = days_of_supply / shelf_life
                    left_column.append(f"   Product shelf life: {shelf_life:.0f} days")
                    left_column.append(f"   Shelf life utilization: {shelf_life_risk*100:.1f}%")
                    
                    if shelf_life_risk > 0.8:
                        left_column.append("   🚨 HIGH RISK: Inventory may expire before consumption")
                        left_column.append("      • Reduce order quantities immediately")
                        left_column.append("      • Implement FIFO rotation strictly")
                        left_column.append("      • Consider promotional activities")
                    elif shelf_life_risk > 0.5:
                        left_column.append("   ⚠️  MEDIUM RISK: Monitor expiration dates closely")
                    else:
                        left_column.append("   ✅ Low expiration risk")
                else:
                    left_column.append(format_unavailable("Shelf life has no expiry"))
            
            else:
                left_column.append(format_unavailable("Inventory data not available"))
                left_column.append("   → Unable to assess current stock position")
                left_column.append("   → Recommend immediate inventory audit")
                left_column.append("\n📋 MOQ Analysis:")
                left_column.append(format_unavailable("MOQ information not available"))
                left_column.append("\n🕐 Shelf Life Analysis:")
                left_column.append(format_unavailable("Shelf life has no expiry"))
            
            # === RIGHT COLUMN: SUPPLIER PERFORMANCE + FINANCIAL IMPACT ===
            
            # SECTION 3: SUPPLIER PERFORMANCE & LEAD TIME ANALYSIS
            right_column.append("=== SUPPLIER PERFORMANCE ANALYSIS ===")

            if not supplier_data.empty:
                try:
                    # Check if required columns exist
                    required_columns = [
                        'PO Lead Time Weeks (Delivery Date vs GRN Date)', 
                        'Quotation Lead Time Weeks'
                    ]
                    
                    missing_columns = [col for col in required_columns if col not in supplier_data.columns]
                    
                    if missing_columns:
                        right_column.append(f"🚛 Lead Time Performance:")
                        right_column.append(format_unavailable(f"Required columns missing: {missing_columns}"))
                        right_column.append("   → Check data source for proper column names\n")
                    else:
                        # Get rows where BOTH PO and Quote lead times exist (paired data)
                        complete_rows = supplier_data.dropna(subset=required_columns)
                        
                        if len(complete_rows) > 0:
                            # Extract paired data from complete rows only
                            po_lead_times = complete_rows['PO Lead Time Weeks (Delivery Date vs GRN Date)'].values
                            quote_lead_times = complete_rows['Quotation Lead Time Weeks'].values
                            
                            # Convert to numeric, handling any non-numeric values
                            try:
                                po_lead_times = pd.to_numeric(po_lead_times, errors='coerce')
                                quote_lead_times = pd.to_numeric(quote_lead_times, errors='coerce')
                                
                                # Remove any NaN values that resulted from conversion
                                valid_mask = ~(np.isnan(po_lead_times) | np.isnan(quote_lead_times))
                                po_lead_times = po_lead_times[valid_mask]
                                quote_lead_times = quote_lead_times[valid_mask]
                                
                                if len(po_lead_times) > 0:
                                    # Now we have properly paired arrays of the same length
                                    avg_po_lead = np.mean(po_lead_times)
                                    avg_quote_lead = np.mean(quote_lead_times)
                                    lead_time_std = np.std(po_lead_times)
                                    lead_time_cv = lead_time_std / avg_po_lead if avg_po_lead > 0 else 0
                                    
                                    # Calculate delivery performance metrics using paired data
                                    delivery_variance = np.mean(np.abs(po_lead_times - quote_lead_times))
                                    on_time_delivery = np.mean(po_lead_times <= quote_lead_times * 1.1) * 100
                                    
                                    # Additional metrics now that we have paired data
                                    early_delivery_rate = np.mean(po_lead_times < quote_lead_times) * 100
                                    late_delivery_rate = np.mean(po_lead_times > quote_lead_times * 1.1) * 100
                                    
                                    right_column.append(f"🚛 Lead Time Performance ({len(po_lead_times)} valid records):")
                                    right_column.append(f"   Average actual lead time: {avg_po_lead:.2f} weeks")
                                    right_column.append(f"   Average quoted lead time: {avg_quote_lead:.2f} weeks")
                                    right_column.append(f"   Average delivery variance: {delivery_variance:.2f} weeks")
                                    right_column.append(f"   On-time delivery rate: {on_time_delivery:.2f}%")
                                    right_column.append(f"   Early delivery rate: {early_delivery_rate:.2f}%")
                                    right_column.append(f"   Late delivery rate: {late_delivery_rate:.2f}%")
                                    
                                    # Enhanced supplier reliability assessment with more context
                                    if len(po_lead_times) < 3:
                                        right_column.append("   ⚠️  LIMITED DATA: Analysis based on few records")
                                    
                                    if on_time_delivery < 70:
                                        right_column.append("   🚨 POOR supplier reliability\n")
                                    elif on_time_delivery < 85:
                                        right_column.append("   ⚠️  MODERATE supplier reliability - monitor closely\n")
                                    else:
                                        right_column.append("   ✅ GOOD supplier reliability\n")
                                else:
                                    right_column.append(f"🚛 Lead Time Performance:")
                                    right_column.append(format_unavailable("No valid numeric lead time data found"))
                                    right_column.append("   → Check data for non-numeric values\n")
                                    
                            except Exception as numeric_error:
                                right_column.append(f"🚛 Lead Time Performance:")
                                right_column.append(format_unavailable(f"Data conversion error: {str(numeric_error)}"))
                                right_column.append("   → Check data format and types\n")
                        else:
                            right_column.append(f"🚛 Lead Time Performance:")
                            right_column.append(format_unavailable("No complete PO/Quote lead time pairs found"))
                            right_column.append("   → Need records with both actual and quoted lead times")
                            right_column.append("   → Recommend improving data collection processes\n")
                            
                except Exception as e:
                    right_column.append(f"🚛 Lead Time Performance:")
                    right_column.append(format_unavailable(f"Analysis error: {str(e)}"))
                    right_column.append("   → Contact system administrator\n")
                    
            else:
                right_column.append(f"🚛 Lead Time Performance:")
                right_column.append(format_unavailable("Supplier data not available"))
                right_column.append("   → Unable to assess supplier reliability")
                right_column.append("   → Recommend supplier performance tracking implementation\n")
                
            # SECTION 4: FINANCIAL IMPACT ANALYSIS
            right_column.append("=== FINANCIAL IMPACT ANALYSIS ===")
            
            # Cost Comparison Analysis
            right_column.append("💰 Forecast Method Cost Comparison:")

            if cost_info and cost_info['Better Forecasting Method'] == "TabPFN AI Forecast":
                savings = cost_info['AI Forecast Cost Variance']
                right_column.append(f"TabPFN AI Forecast is better")
                right_column.append(f"Potential savings if AI was used to forecast usage for last period: ${abs(savings):,.2f}")

            elif cost_info and cost_info['Better Forecasting Method'] == "Historical Forecast":
                savings = cost_info['Historical Forecast Cost Variance']
                right_column.append(f"Historical Forecast was better")
                right_column.append(f" Savings when Historical forecast was used to forecast usage for last period: ${abs(savings):,.2f}")
    
            else:
                right_column.append(format_unavailable("Historical and AI resulted in equal costs"))
            
            # Historical Cost Analysis
            right_column.append("\n📊 Historical Cost Pattern Analysis:")
            if not financial_data.empty:
                cost_column = 'Extra Cost (Expedited, Write-Off etc.)' if 'Extra Cost (Expedited, Write-Off etc.)' in financial_data.columns else None
                
                if cost_column:
                    understock_cost = financial_data[financial_data['Classification'] == 'Understock'][cost_column].sum()
                    overstock_cost = financial_data[financial_data['Classification'] == 'Overstock'][cost_column].sum()
                    obsolete_cost = financial_data[financial_data['Classification'] == 'Obsolete'][cost_column].sum()
                    damage_cost = financial_data[financial_data['Classification'] == 'Unexpected Damage'][cost_column].sum()
                    
                    total_cost = understock_cost + overstock_cost + obsolete_cost + damage_cost
                    
                    right_column.append(f"   Total inventory-related costs: ${total_cost:,.2f}")
                    
                    # Cost breakdown - only show when cost > 0
                    if understock_cost > 0:
                        right_column.append(f"   • Understock costs: ${understock_cost:,.2f} ({understock_cost/total_cost*100 if total_cost > 0 else 0:.1f}%)")
                    
                    if overstock_cost > 0:
                        right_column.append(f"   • Overstock costs: ${overstock_cost:,.2f} ({overstock_cost/total_cost*100 if total_cost > 0 else 0:.1f}%)")
                    
                    if obsolete_cost > 0:
                        right_column.append(f"   • Obsolete costs: ${obsolete_cost:,.2f} ({obsolete_cost/total_cost*100 if total_cost > 0 else 0:.1f}%)")
                    
                    if damage_cost > 0:
                        right_column.append(f"   • Damage costs: ${damage_cost:,.2f} ({damage_cost/total_cost*100 if total_cost > 0 else 0:.1f}%)")
                    
                    # Enhanced cost per unit analysis
                    cost_per_unit = total_cost / initial_forecast if initial_forecast > 0 else 0
                    right_column.append(f"   Historical cost per unit: ${cost_per_unit:.2f}")
                    
                    # Cost trend analysis
                    if total_cost > initial_forecast * 0.15:
                        right_column.append(f"   🚨 HIGH COST IMPACT: Inventory costs exceed 15% of forecast value")
                    elif total_cost > initial_forecast * 0.08:
                        right_column.append(f"   ⚠️  MODERATE COST IMPACT: Inventory costs are 8-15% of forecast value")
                    else:
                        right_column.append(f"   ✅ ACCEPTABLE COST LEVEL: Inventory costs under 8% of forecast value")
                else:
                    right_column.append(format_unavailable("Historical financial data not available"))
                    right_column.append("   → No Historical Records of Extra Costs")
            else:
                right_column.append(format_unavailable("Historical financial data not available"))
                right_column.append("   → No Historical Records of Extra Costs")
                        
            # Return both columns as a dictionary for flexible formatting
            return {
                'left_column': "\n".join(left_column),
                'right_column': "\n".join(right_column)
            }

    def _fallback_forecast(self, values, periods=1):
        """A robust fallback forecasting method."""
        if not values:
            return [0.0] * periods
        
        values = np.array(values)
        
        # Simple Moving Average
        if len(values) >= 3:
            forecast = np.mean(values[-3:])
        elif len(values) == 2:
            forecast = np.mean(values)
        else:
            forecast = values[-1]
            
        return [max(0, round(forecast))] * periods

