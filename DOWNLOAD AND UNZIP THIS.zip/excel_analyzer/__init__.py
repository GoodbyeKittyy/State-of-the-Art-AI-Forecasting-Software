"""
Excel Analyzer Package

This package provides tools for analyzing Excel data with PyQt5 interface.
"""

# Version of the package
__version__ = "1.0.0"

# Import key components to make them easily accessible
from .app import ExcelAnalyzerApp
from .data_analysis_worker import DataAnalysisWorker

# Define what gets imported with 'from excel_analyzer import *'
__all__ = ['ExcelAnalyzerApp', 'DataAnalysisWorker']