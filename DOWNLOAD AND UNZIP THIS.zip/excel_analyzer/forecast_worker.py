import os
import pandas as pd
import numpy as np
import warnings
import subprocess
import sys
import time
import torch
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
import multiprocessing

warnings.filterwarnings('ignore')

class ForecastWorker:
    def __init__(self):
        self._start_time = time.time()
        self.tabpfn_model = None
        self.tabpfn_models = {}
        self.model_performances = {}
        self._forecast_cache = None
        self._load_tabpfn_model()

    def _load_tabpfn_model(self):
        """Load TabPFN time series model with correct parameters"""
        try:
            print("Loading TabPFN time series model...")
            
            # Install tabpfn if not already installed
            try:
                import tabpfn
            except ImportError:
                print("Installing tabpfn...")
                subprocess.run([sys.executable, "-m", "pip", "install", "tabpfn"], check=True)
            
            # Import TabPFN with correct initialization
            from tabpfn import TabPFNRegressor
            
            # Initialize multiple models for ensemble - using correct parameters
            self.tabpfn_models = {}
            self.model_performances = {}
            
            # Create different model configurations with valid parameters
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
            configs = [
                {'device': 'cpu', 'random_state': 42},
                {'device': 'cpu', 'random_state': 123},
                {'device': 'cpu', 'random_state': 456},
            ]
            
            for i, config in enumerate(configs):
                self.tabpfn_models[f'model_{i}'] = TabPFNRegressor(**config)
                self.model_performances[f'model_{i}'] = []
            
            # Main model for backward compatibility
            self.tabpfn_model = self.tabpfn_models['model_0']
            
            print("✓ TabPFN ensemble loaded successfully!")
            return True
            
        except Exception as e:
            print(f"Error loading TabPFN model: {e}")
            print("Falling back to statistical forecasting methods...")
            self.tabpfn_model = None
            self.tabpfn_models = {}
            return False

    def _get_period_columns(self, df):
        """Get period columns (YYYYMXX format) from dataframe"""
        periods = []
        for col in df.columns:
            if isinstance(col, str) and len(col) == 7 and col[4] == 'M':
                try:
                    year = int(col[:4])
                    month = int(col[5:])
                    if 2000 <= year <= 2100 and 1 <= month <= 12:
                        periods.append(col)
                except:
                    continue
        return sorted(periods)

    def _get_next_period(self, last_period):
        """Get the next period string from the last period"""
        try:
            year = int(last_period[:4])
            month = int(last_period[5:])
            
            if month == 12:
                return f"{year+1}M01"
            else:
                return f"{year}M{month+1:02d}"
        except:
            return "Next Period"

    def _create_advanced_time_series_features(self, values):
        """Create advanced time series features optimized for TabPFN"""
        try:
            values = np.array(values)
            if len(values) < 3:
                return None
            
            features = []
            
            # Create features for each time step (starting from index 2 to have enough history)
            for i in range(2, len(values)):
                feature_row = []
                
                # 1. Time-based features
                feature_row.append(i / len(values))  # Normalized time index
                feature_row.append(np.sin(2 * np.pi * i / 12))  # Seasonal component (monthly)
                feature_row.append(np.cos(2 * np.pi * i / 12))  # Seasonal component (monthly)
                
                # 2. Lag features (multiple lags)
                feature_row.append(values[i-1])  # Lag 1
                feature_row.append(values[i-2])  # Lag 2
                
                # 3. Moving averages (different windows)
                ma_2 = np.mean(values[max(0, i-2):i])
                ma_3 = np.mean(values[max(0, i-3):i]) if i >= 3 else ma_2
                feature_row.append(ma_2)
                feature_row.append(ma_3)
                
                # 4. Trend features
                if i >= 3:
                    # Short-term trend
                    short_trend = (values[i-1] - values[i-2])
                    # Medium-term trend
                    medium_trend = (values[i-1] - values[i-3]) / 2
                    feature_row.append(short_trend)
                    feature_row.append(medium_trend)
                else:
                    feature_row.extend([0, 0])
                
                # 5. Volatility features
                if i >= 3:
                    volatility = np.std(values[max(0, i-3):i])
                    feature_row.append(volatility)
                else:
                    feature_row.append(0)
                
                # 6. Momentum features
                if i >= 4:
                    momentum = values[i-1] - values[i-4]
                    feature_row.append(momentum)
                else:
                    feature_row.append(0)
                
                # 7. Relative position features
                if i >= 3:
                    recent_max = np.max(values[max(0, i-3):i])
                    recent_min = np.min(values[max(0, i-3):i])
                    if recent_max != recent_min:
                        relative_pos = (values[i-1] - recent_min) / (recent_max - recent_min)
                    else:
                        relative_pos = 0.5
                    feature_row.append(relative_pos)
                else:
                    feature_row.append(0.5)
                
                # 8. Change rate features
                if i >= 2:
                    change_rate = (values[i-1] - values[i-2]) / (values[i-2] + 1e-8)
                    feature_row.append(change_rate)
                else:
                    feature_row.append(0)
                
                features.append(feature_row)
            
            return np.array(features)
            
        except Exception as e:
            print(f"Advanced feature creation failed: {e}")
            return None

    def _auto_optimize_tabpfn_for_material(self, material_code, values):
        """Auto-optimize TabPFN model selection for specific material"""
        try:
            if len(values) < 5:  # Need minimum data for cross-validation
                return self._generate_single_ai_forecast_fallback(values)
            
            # Create advanced features
            features = self._create_advanced_time_series_features(values)
            if features is None or len(features) < 3:
                return self._generate_single_ai_forecast_fallback(values)
            
            # Prepare training data
            X_train = features[:-1]
            y_train = np.array(values[3:len(features)+2])  # Align with features
            
            if len(X_train) != len(y_train) or len(X_train) < 2:
                return self._generate_single_ai_forecast_fallback(values)
            
            best_model = None
            best_score = float('inf')
            best_forecast = None
            
            # Try different models and find the best one
            for model_name, model in self.tabpfn_models.items():
                try:
                    if len(X_train) >= 2:
                        # Use time series cross-validation for model selection
                        scores = []
                        
                        # Walk-forward validation
                        for split_idx in range(max(2, len(X_train) - 2), len(X_train)):
                            X_train_split = X_train[:split_idx]
                            y_train_split = y_train[:split_idx]
                            X_test_split = X_train[split_idx:split_idx+1]
                            y_test_split = y_train[split_idx:split_idx+1]
                            
                            if len(X_train_split) >= 2:
                                model.fit(X_train_split, y_train_split)
                                pred = model.predict(X_test_split)[0]
                                actual = y_test_split[0]
                                
                                # Calculate MAPE
                                if actual != 0:
                                    mape = abs((actual - pred) / actual) * 100
                                    scores.append(mape)
                        
                        if scores:
                            avg_score = np.mean(scores)
                            
                            # Update model performance tracking
                            if model_name not in self.model_performances:
                                self.model_performances[model_name] = []
                            self.model_performances[model_name].append(avg_score)
                            
                            if avg_score < best_score:
                                best_score = avg_score
                                best_model = model
                                
                                # Generate forecast with best model
                                model.fit(X_train, y_train)
                                X_pred = features[-1:]
                                best_forecast = model.predict(X_pred)[0]
                        
                except Exception as e:
                    print(f"Model {model_name} failed for material {material_code}: {e}")
                    continue
            
            if best_forecast is not None:
                return max(0, round(best_forecast))
            else:
                return self._generate_single_ai_forecast_fallback(values)
                
        except Exception as e:
            print(f"Auto-optimization failed for material {material_code}: {e}")
            return self._generate_single_ai_forecast_fallback(values)

    def _generate_single_ai_forecast(self, prior_values):
        """Generate single AI forecast with proper error handling"""
        try:
            if len(prior_values) < 3:
                return self._generate_single_ai_forecast_fallback(prior_values)
            
            # Use auto-optimization for better performance
            if hasattr(self, 'tabpfn_models') and self.tabpfn_models:
                return self._auto_optimize_tabpfn_for_material("temp_material", prior_values)
            
            # Fallback to single model approach
            if self.tabpfn_model is not None:
                features = self._create_advanced_time_series_features(prior_values)
                
                if features is not None and len(features) >= 2:
                    X_train = features[:-1]
                    y_train = np.array(prior_values[3:len(features)+2])
                    
                    if len(X_train) >= 2 and len(y_train) >= 2 and len(X_train) == len(y_train):
                        # Fit and predict
                        self.tabpfn_model.fit(X_train, y_train)
                        
                        X_pred = features[-1:]
                        forecast = self.tabpfn_model.predict(X_pred)[0]
                        
                        return max(0, round(forecast))
            
            return self._generate_single_ai_forecast_fallback(prior_values)
            
        except Exception as e:
            print(f"Error in _generate_single_ai_forecast: {e}")
            return self._generate_single_ai_forecast_fallback(prior_values)

    def _generate_single_ai_forecast_fallback(self, prior_values):
        """Enhanced fallback forecast method"""
        try:
            if len(prior_values) == 0:
                return 0.0
            
            # Enhanced statistical forecasting
            values = np.array(prior_values)
            
            if len(values) >= 6:
                # Triple exponential smoothing (Holt-Winters)
                alpha, beta, gamma = 0.3, 0.1, 0.1
                season_length = min(4, len(values) // 2)
                
                # Initialize components
                level = np.mean(values[:season_length])
                trend = (np.mean(values[season_length:2*season_length]) - level) / season_length
                seasonal = values[:season_length] - level
                
                # Apply smoothing
                for i in range(season_length, len(values)):
                    old_level = level
                    level = alpha * (values[i] - seasonal[i % season_length]) + (1 - alpha) * (level + trend)
                    trend = beta * (level - old_level) + (1 - beta) * trend
                    seasonal[i % season_length] = gamma * (values[i] - level) + (1 - gamma) * seasonal[i % season_length]
                
                # Forecast
                forecast = level + trend + seasonal[len(values) % season_length]
                
            elif len(values) >= 3:
                # Enhanced trend analysis with dampening
                x = np.arange(len(values))
                
                # Fit polynomial trend
                if len(values) >= 4:
                    coeffs = np.polyfit(x, values, 2)  # Quadratic
                    trend = 2 * coeffs[0] * len(values) + coeffs[1]  # Derivative at last point
                else:
                    coeffs = np.polyfit(x, values, 1)  # Linear
                    trend = coeffs[0]
                
                # Dampen trend for stability
                dampening_factor = 0.7
                trend *= dampening_factor
                
                # Add seasonal adjustment
                if len(values) >= 4:
                    seasonal_factor = np.mean(values[-2:]) / np.mean(values[:-2]) if np.mean(values[:-2]) != 0 else 1
                    seasonal_factor = min(max(seasonal_factor, 0.5), 2.0)  # Bound the factor
                else:
                    seasonal_factor = 1.0
                
                forecast = (values[-1] + trend) * seasonal_factor
            else:
                # Simple average with trend
                if len(values) >= 2:
                    trend = values[-1] - values[-2]
                    forecast = values[-1] + 0.5 * trend  # Dampened trend
                else:
                    forecast = values[-1]
            
            return max(0, round(forecast))
            
        except Exception as e:
            print(f"Enhanced fallback forecast failed: {e}")
            return max(0, prior_values[-1]) if len(prior_values) > 0 else 0.0

    def _fallback_forecast(self, data, periods=1):
        """Fallback forecasting method using statistical approaches"""
        try:
            data = np.array([x for x in data if not pd.isna(x)])
            
            if len(data) == 0:
                return np.array([0.0] * periods)
            
            if len(data) >= 6:
                # Use exponential smoothing for longer series
                alpha = 0.3
                smoothed = [data[0]]
                for i in range(1, len(data)):
                    smoothed.append(alpha * data[i] + (1 - alpha) * smoothed[-1])
                
                # Simple trend from smoothed data
                trend = (smoothed[-1] - smoothed[-3]) / 2 if len(smoothed) >= 3 else 0
                
                forecast = []
                last_value = smoothed[-1]
                for i in range(periods):
                    next_value = last_value + trend * (i + 1)
                    forecast.append(max(0, next_value))
                
                return np.array(forecast)
                
            elif len(data) >= 3:
                # Use simple trend analysis
                x = np.arange(len(data))
                coeffs = np.polyfit(x, data, 1)
                trend = coeffs[0]
                
                # Generate forecast
                last_value = data[-1]
                forecast = []
                for i in range(periods):
                    next_value = last_value + trend * (i + 1)
                    forecast.append(max(0, next_value))
                
                return np.array(forecast)
            else:
                # Use simple average for very short series
                avg_value = np.mean(data)
                return np.array([max(0, avg_value)] * periods)
                
        except Exception as e:
            print(f"Fallback forecast failed: {e}")
            if len(data) > 0:
                return np.array([max(0, data[-1])] * periods)
            else:
                return np.array([0.0] * periods)

    def _generate_tabpfn_forecasts(self, historical_usage, usage_periods):
        """Generate forecasts using TabPFN model with parallel processing"""
        
        if self._forecast_cache is not None:
            return self._forecast_cache
        
        forecasts = {}
        
        # Load TabPFN model if not already loaded
        if self.tabpfn_model is None:
            self._load_tabpfn_model()
        
        if self.tabpfn_model is None or len(usage_periods) < 3:
            # Use fallback method with parallel processing
            from concurrent.futures import ProcessPoolExecutor, as_completed
            import multiprocessing
            
            def process_material_fallback(row_data):
                material_code, row_values = row_data
                usage_data = [row_values[period] for period in usage_periods if not pd.isna(row_values[period])]
                forecast = self._fallback_forecast(usage_data, periods=1)
                return material_code, {
                    'forecast': forecast[0] if forecast is not None else 0.0,
                    'method': 'Statistical Fallback'
                }
            
            # Prepare data for parallel processing
            material_data = [(row['Material Code'], row) for _, row in historical_usage.iterrows()]
            
            # Process in parallel
            max_workers = min(multiprocessing.cpu_count(), len(material_data))
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_material_fallback, data): data[0] for data in material_data}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, result = future.result()
                        forecasts[material_code] = result
                    except Exception as e:
                        material_code = future_to_material[future]
                        print(f"Error processing material {material_code}: {e}")
                        forecasts[material_code] = {'forecast': 0.0, 'method': 'Error Fallback'}
            
            self._forecast_cache = forecasts
            return forecasts
        
        try:
            print(f"Generating TabPFN forecasts for {len(historical_usage)} materials...")
            
            # Parallel processing for TabPFN forecasts
            from concurrent.futures import ThreadPoolExecutor, as_completed
            
            def process_single_material(row_data):
                material_code, row_values = row_data
                usage_values = [row_values[period] for period in usage_periods if not pd.isna(row_values[period])]
                
                if len(usage_values) >= 3:
                    try:
                        forecast = self._generate_single_ai_forecast(usage_values)
                        return material_code, {
                            'forecast': max(0, forecast),
                            'method': 'TabPFN Regressor'
                        }
                    except Exception as e:
                        print(f"TabPFN failed for material {material_code}: {e}")
                        forecast = self._fallback_forecast(usage_values, periods=1)
                        return material_code, {
                            'forecast': forecast[0] if forecast is not None else 0.0,
                            'method': 'Statistical Fallback (TabPFN Error)'
                        }
                else:
                    forecast = self._fallback_forecast(usage_values, periods=1)
                    return material_code, {
                        'forecast': forecast[0] if forecast is not None else 0.0,
                        'method': 'Statistical Fallback (Short Series)'
                    }
            
            # Prepare data for parallel processing
            material_data = [(row['Material Code'], row) for _, row in historical_usage.iterrows()]
            
            # Process in parallel with threads (better for I/O and model inference)
            max_workers = min(8, len(material_data))  # Limit to 8 threads for stability
            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_single_material, data): data[0] for data in material_data}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, result = future.result()
                        forecasts[material_code] = result
                        if len(forecasts) % 50 == 0:
                            print(f"Processed {len(forecasts)}/{len(material_data)} materials")
                    except Exception as e:
                        material_code = future_to_material[future]
                        print(f"Error processing material {material_code}: {e}")
                        forecasts[material_code] = {'forecast': 0.0, 'method': 'Error Fallback'}
            
            print(f"Generated {len(forecasts)} forecasts using TabPFN")
            self._forecast_cache = forecasts
            return forecasts
            
        except Exception as e:
            print(f"TabPFN forecasting failed: {e}")
            # Fallback with parallel processing
            from concurrent.futures import ProcessPoolExecutor, as_completed
            
            def process_fallback_material(row_data):
                material_code, row_values = row_data
                usage_values = [row_values[period] for period in usage_periods if not pd.isna(row_values[period])]
                forecast = self._fallback_forecast(usage_values, periods=1)
                return material_code, {
                    'forecast': forecast[0] if forecast is not None else 0.0,
                    'method': 'Statistical Fallback (Global Error)'
                }
            
            material_data = [(row['Material Code'], row) for _, row in historical_usage.iterrows()]
            
            max_workers = min(multiprocessing.cpu_count(), len(material_data))
            with ProcessPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_fallback_material, data): data[0] for data in material_data}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, result = future.result()
                        forecasts[material_code] = result
                    except Exception as e:
                        material_code = future_to_material[future]
                        forecasts[material_code] = {'forecast': 0.0, 'method': 'Error Fallback'}
            
            self._forecast_cache = forecasts
            return forecasts

    def _calculate_existing_period_accuracy(self, historical_usage, historical_forecast, 
                    material_codes, common_periods):
        """Calculate accuracy using ONLY the latest period - PARALLEL OPTIMIZED"""
        results = []
        
        if len(common_periods) < 2:
            print("Need at least 2 periods for accuracy calculation")
            return results
        
        # Use only the LATEST period for comparison
        latest_period = common_periods[-1]
        print(f"Calculating accuracy for latest period only: {latest_period}")
        print(f"Analyzing {len(material_codes)} materials...")
        
        # Generate AI forecasts for the latest period only
        latest_period_forecasts = self._generate_latest_period_forecasts(
            historical_usage, material_codes, common_periods, latest_period
        )
        
        print("Calculating MAPE for each material...")
        
        # Parallel processing function
        def process_material_accuracy(material_code):
            try:
                # Get usage data for latest period
                usage_row = historical_usage[historical_usage['Material Code'] == material_code]
                if len(usage_row) == 0:
                    return None
                
                actual_val = usage_row[latest_period].values[0]
                if pd.isna(actual_val):
                    return None
                
                # Get historical forecast for latest period
                forecast_row = historical_forecast[historical_forecast['Material Code'] == material_code]
                if len(forecast_row) == 0:
                    return None
                
                hist_forecast_val = forecast_row[latest_period].values[0]
                if pd.isna(hist_forecast_val):
                    return None
                
                # Get AI forecast for latest period
                ai_forecast = latest_period_forecasts.get(material_code, None)
                if ai_forecast is None:
                    return None
                
                # Calculate MAPE (using single period - convert to percentage)
                hist_mape = abs((actual_val - hist_forecast_val) / actual_val) * 100 if actual_val != 0 else 0
                ai_mape = abs((actual_val - ai_forecast) / actual_val) * 100 if actual_val != 0 else 0
                
                return {
                    'Material Code': material_code,
                    'Historical Forecast MAPE': hist_mape,
                    'AI Forecast MAPE': ai_mape,
                    'Improvement': hist_mape - ai_mape
                }
            except Exception as e:
                print(f"Error processing material {material_code}: {e}")
                return None
        
        # Process materials in parallel
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        import multiprocessing
        max_workers = multiprocessing.cpu_count()

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_material = {executor.submit(process_material_accuracy, material_code): material_code for material_code in material_codes}
            
            for future in as_completed(future_to_material):
                try:
                    result = future.result()
                    if result is not None:
                        results.append(result)
                        if len(results) % 50 == 0:
                            print(f"Processed {len(results)} materials")
                except Exception as e:
                    material_code = future_to_material[future]
                    print(f"Error getting result for material {material_code}: {e}")
        
        print(f"Accuracy analysis complete for {len(results)} materials")
        return results

    def _generate_latest_period_forecasts(self, historical_usage, material_codes, common_periods, latest_period):
        """Generate AI forecasts for the latest period only - PARALLEL OPTIMIZED"""
        latest_forecasts = {}
        
        print(f"Generating forecasts for latest period only: {latest_period}")
        
        try:
            # Find the index of the latest period
            latest_index = common_periods.index(latest_period)
            if latest_index == 0:
                print("Latest period is the first period - cannot generate forecast")
                return latest_forecasts
            
            # Get all periods before the latest period
            prior_periods = common_periods[:latest_index]
            
            if len(prior_periods) < 2:
                print("Insufficient prior periods for forecasting")
                return latest_forecasts
            
            print(f"Using {len(prior_periods)} prior periods for forecasting")
            
            # Parallel processing function
            def process_material_forecast(material_code):
                try:
                    usage_row = historical_usage[historical_usage['Material Code'] == material_code]
                    if len(usage_row) == 0:
                        return material_code, None
                    
                    # Get usage values for all prior periods
                    prior_values = []
                    for period in prior_periods:
                        val = usage_row[period].values[0]
                        if not pd.isna(val):
                            prior_values.append(val)
                    
                    if len(prior_values) >= 2:
                        # Generate forecast for latest period using prior data
                        forecast = self._generate_single_ai_forecast(prior_values)
                        return material_code, forecast
                    else:
                        return material_code, None
                except Exception as e:
                    print(f"Error processing material {material_code}: {e}")
                    return material_code, None
            
            # Process materials in parallel
            from concurrent.futures import ThreadPoolExecutor, as_completed
            
            import multiprocessing
            max_workers = multiprocessing.cpu_count()

            with ThreadPoolExecutor(max_workers=max_workers) as executor:
                future_to_material = {executor.submit(process_material_forecast, material_code): material_code for material_code in material_codes}
                
                for future in as_completed(future_to_material):
                    try:
                        material_code, forecast = future.result()
                        if forecast is not None:
                            latest_forecasts[material_code] = forecast
                            if len(latest_forecasts) % 50 == 0:
                                print(f"Processed {len(latest_forecasts)} forecasts")
                    except Exception as e:
                        material_code = future_to_material[future]
                        print(f"Error getting result for material {material_code}: {e}")
            
            print(f"Generated {len(latest_forecasts)} forecasts for latest period")
            return latest_forecasts
            
        except Exception as e:
            print(f"Error generating latest period forecasts: {e}")
            return latest_forecasts