import sys
import os
import socket
import io
from datetime import datetime
from PyQt5.QtWidgets import QApplication
from PyQt5.QtNetwork import QNetworkAccessManager
from excel_analyzer.app import ExcelAnalyzerApp

# Global set to track processed tables
_processed_tables = set()
# Global log file handle
_log_file = None

def setup_logging():
    """Set up logging to capture all console output to a timestamped file"""
    global _log_file
    
    # Get the directory where main.py is located1
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create usage_logs directory in the same folder as main.py
    log_dir = os.path.join(script_dir, "usage_logs")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # Generate timestamp for filename
    timestamp = datetime.now()
    date_str = timestamp.strftime("%d%b%Y")  # 14Aug2025
    time_str = timestamp.strftime("%I.%M%p").lower()  # 5.17pm
    
    log_filename = f"USERLOG_{date_str}_{time_str}.txt"
    log_path = os.path.join(log_dir, log_filename)
    
    # Open log file for writing
    _log_file = open(log_path, 'w', encoding='utf-8')
    
    # Write initial log header
    header = f"=== Excel Analyzer Application Log ===\n"
    header += f"Started: {timestamp.strftime('%Y-%m-%d %H:%M:%S')}\n"
    header += f"Log file: {log_filename}\n"
    header += "=" * 50 + "\n\n"
    _log_file.write(header)
    _log_file.flush()
    
    return log_path

def close_logging():
    """Close the log file properly"""
    global _log_file
    if _log_file:
        footer = f"\n\n=== Log ended: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ===\n"
        _log_file.write(footer)
        _log_file.flush()
        _log_file.close()
        _log_file = None

def log_message(message, source="CONSOLE"):
    """Write message to log file with timestamp"""
    global _log_file
    if _log_file and message.strip():
        # Don't log certain security messages that clutter the log
        security_messages_to_skip = [
            "DNS resolution blocked",
            "Network socket creation blocked",
            "Qt network request blocked"
        ]
        
        if any(skip_msg.lower() in message.lower() for skip_msg in security_messages_to_skip):
            return  # Skip logging this message
            
        timestamp = datetime.now().strftime('%H:%M:%S')
        log_entry = f"[{timestamp}] {source}: {message}"
        if not log_entry.endswith('\n'):
            log_entry += '\n'
        _log_file.write(log_entry)
        _log_file.flush()

#For Cybersecurity purposes, forcing it to run locally is much faster too
def block_network_messages():
    """Block network-related error messages AND empty lines from appearing in console"""
    
    class FilteredStderr(io.StringIO):
        def __init__(self, original_stderr):
            super().__init__()
            self.original_stderr = original_stderr
            # Theses are Word combinations that are very specific to download/model errors
            self.blocked_combinations = [
                # Multiple words that must all be present (case-insensitive)
                ["huggingface", "download", "failed"],
                ["direct", "url", "download", "failed"],
                ["model", "failed", "material"],
                ["download", "model", "manually"],
                ["offline", "usage", "download"],
                ["regressor", "ckpt"],
                ["prior-labs"],
                ["resolve", "main", "huggingface"],
                ["appdata", "roaming"],
                ["failed", "download", "ckpt"],
                ["huggingface.co", "resolve"],
                ["temp_material"]
            ]
            
            # Single keywords that are very specific and unlikely in normal prints
            self.blocked_single_keywords = [
                "huggingface.co",
                ".ckpt",
                "Prior-Labs/TabPFN",
                "tabpfn-v2-regressor"
            ]
        
        #Block any network related messages as we dont need to see those
        def _should_block_message(self, text):
            # Block empty lines and whitespace-only lines
            if text.strip() == "":
                return True
                
            text_lower = text.lower()
            
            # Check single specific keywords
            for keyword in self.blocked_single_keywords:
                if keyword.lower() in text_lower:
                    return True
            
            # Check word combinations
            for combination in self.blocked_combinations:
                if all(word.lower() in text_lower for word in combination):
                    return True
            
            return False
        
        def write(self, text):
            if self._should_block_message(text):
                # Completely ignore the message - don't log or write anything
                return len(text)  # Return length to simulate successful write
            
            # Log to file before writing to console
            log_message(text.strip(), "STDERR")
            
            # Otherwise, write to original stderr with newline if not present
            if text and not text.endswith('\n'):
                text += '\n'
            self.original_stderr.write(text)
            self.original_stderr.flush()
            return len(text)
        
        def flush(self):
            self.original_stderr.flush()
    
    class FilteredStdout(io.StringIO):
        def __init__(self, original_stdout):
            super().__init__()
            self.original_stdout = original_stdout
            self.blocked_keywords = [
                "failed to download",
                "Failed to download", 
                "download model manually",
                "huggingface.co",
                "resolve/main",
                "offline usage",
                "model failed",
                "Model model_",
                "tabpfn",
                "TabPFN",
                ".ckpt",
                "connection error",
                "Connection error",
                "network error", 
                "Network error",
                "download error",
                "Download error",
                "unable to download",
                "Unable to download",
                "HuggingFace downloads failed",
                "HuggingFace download failed",
                "Direct URL downloads failed",
                "Direct download failed",
                "For offline usage, please download the model manually from:",
                "Prior-Labs/TabPFN"
            ]
        
        def write(self, text):
            # Block empty lines and whitespace-only lines
            if text.strip() == "":
                return len(text)
                
            # Check if the message contains any blocked keywords
            if any(keyword.lower() in text.lower() for keyword in self.blocked_keywords):
                # Completely ignore the message - don't log or write anything
                return len(text)  # Return length to simulate successful write
            
            # Log to file before writing to console
            log_message(text.strip(), "STDOUT")
            
            # Otherwise, write to original stdout with newline if not present
            if text and not text.endswith('\n'):
                text += '\n'
            self.original_stdout.write(text)
            self.original_stdout.flush()
            return len(text)
        
        def flush(self):
            self.original_stdout.flush()
    
    # Replace stderr and stdout with filtered versions
    sys.stderr = FilteredStderr(sys.stderr)
    sys.stdout = FilteredStdout(sys.stdout)

#These are the important network reroute settings 
def block_network_access():
    """Block network access using multiple methods"""
    
    log_message("Blocking network access for security", "NETWORK")
    
    # Method 1: Override socket creation to prevent network connections
    original_socket = socket.socket
    def blocked_socket(*args, **kwargs):
        log_message("Network socket creation blocked", "SECURITY")
        raise OSError("Network access blocked by application")
    socket.socket = blocked_socket
    
    # Method 2: Set environment variables to disable network
    os.environ['HTTP_PROXY'] = 'http://127.0.0.1:1'
    os.environ['HTTPS_PROXY'] = 'http://127.0.0.1:1'
    os.environ['http_proxy'] = 'http://127.0.0.1:1'
    os.environ['https_proxy'] = 'http://127.0.0.1:1'
    os.environ['NO_PROXY'] = ''
    
    log_message("Environment proxy settings configured", "NETWORK")
    
    # Method 3: Disable common network libraries
    try:
        import urllib3
        urllib3.disable_warnings()
        log_message("urllib3 warnings disabled", "NETWORK")
    except ImportError:
        log_message("urllib3 not available", "NETWORK")
        pass
    
    # Method 4: Block DNS resolution
    original_getaddrinfo = socket.getaddrinfo
    def blocked_getaddrinfo(*args, **kwargs):
        log_message("DNS resolution blocked", "SECURITY")
        raise OSError("DNS resolution blocked")
    socket.getaddrinfo = blocked_getaddrinfo

def setup_qt_network_blocking(app):
    """Block Qt network access"""
    log_message("Setting up Qt network blocking", "QT")
    
    # Create a custom network access manager that denies all requests
    class BlockedNetworkAccessManager(QNetworkAccessManager):
        def createRequest(self, operation, request, outgoingData=None):
            # Block all network requests
            log_message("Qt network request blocked", "QT_SECURITY")
            raise RuntimeError("Network access blocked")
    
    # You can apply this to your main window if it uses network features
    # This would need to be implemented in your ExcelAnalyzerApp class

def limit_all_tables_in_app(app_window):
    """Apply 100-row display limit to all table widgets in the application while preserving full data"""
    try:
        if not hasattr(app_window, 'tab_widget') or not app_window.tab_widget.isVisible():
            return
        
        # Process all main tabs
        for tab_index in range(app_window.tab_widget.count()):
            main_tab = app_window.tab_widget.widget(tab_index)
            limit_all_tables_in_widget(main_tab)
    except Exception as e:
        log_message(f"Error in limit_all_tables_in_app: {e}", "ERROR")
        pass

def limit_all_tables_in_widget(widget, max_display_rows=100):
    """FIXED: Hide rows beyond limit instead of deleting data, with duplicate prevention"""
    from PyQt5.QtWidgets import QTableWidget, QTabWidget
    
    if widget is None:
        return
    
    try:
        # If this widget is a QTableWidget, limit display only
        if isinstance(widget, QTableWidget):
            # Create unique identifier for this table
            table_id = id(widget)
            
            # Skip if already processed
            if table_id in _processed_tables:
                return
                
            total_rows = widget.rowCount()
            if total_rows > max_display_rows:
                # Hide rows instead of deleting them - this preserves the data
                for row in range(max_display_rows, total_rows):
                    widget.setRowHidden(row, True)
                
                # Mark as processed
                _processed_tables.add(table_id)
                message = f"Table display limited: showing {max_display_rows} of {total_rows} rows (data preserved for export)"
                log_message(message, "TABLE")
                print(message)
        
        # Check for sub-tab widgets RECURSIVELY
        if isinstance(widget, QTabWidget):
            for i in range(widget.count()):
                sub_widget = widget.widget(i)
                limit_all_tables_in_widget(sub_widget, max_display_rows)
        
        # Check all child widgets INCLUDING nested QTabWidgets
        for child in widget.findChildren(QTableWidget):
            # Create unique identifier for this table
            table_id = id(child)
            
            # Skip if already processed
            if table_id in _processed_tables:
                continue
                
            total_rows = child.rowCount()
            if total_rows > max_display_rows:
                # FIXED: Only hide rows, don't delete data
                for row in range(max_display_rows, total_rows):
                    child.setRowHidden(row, True)
                
                # Mark as processed
                _processed_tables.add(table_id)
                message = f"Child table display limited: showing {max_display_rows} of {total_rows} rows (data preserved)"
                log_message(message, "TABLE")
                print(message)
        
        # ADDITIONAL: Check for nested QTabWidgets that might contain tables
        for child_tab in widget.findChildren(QTabWidget):
            if child_tab != widget:  # Avoid infinite recursion
                limit_all_tables_in_widget(child_tab, max_display_rows)
                
    except Exception as e:
        error_msg = f"Error in limit_all_tables_in_widget: {e}"
        log_message(error_msg, "ERROR")
        print(error_msg)
        pass

def main():
    log_path = None
    try:
        # Set up logging first - this must be done before any other operations
        log_path = setup_logging()
        log_message("Application starting up", "SYSTEM")
        log_message(f"Log file created: {log_path}", "SYSTEM")
        
        # Block network-related messages first
        log_message("Setting up network message filtering", "SYSTEM")
        block_network_messages()
        
        # Block network access before doing anything else
        log_message("Blocking network access", "SYSTEM")
        block_network_access()
        
        log_message("Creating QApplication", "QT")
        app = QApplication(sys.argv)
        
        # Set application properties
        app.setApplicationName("Material Planning Forecasting Tool")
        app.setApplicationVersion("1.0")
        log_message("Application properties set", "QT")
        
        # Optional: Set up Qt-specific network blocking
        setup_qt_network_blocking(app)
        
        log_message("Creating main window", "APP")
        # Create and show main window
        window = ExcelAnalyzerApp()
        
        # Apply table display limits periodically (preserving full data)
        log_message("Setting up table display limiter", "TABLE")
        from PyQt5.QtCore import QTimer
        timer = QTimer()
        timer.timeout.connect(lambda: limit_all_tables_in_app(window))
        timer.start(2000)  # Check every 2 seconds
        
        log_message("Showing main window", "APP")
        window.show()
        
        log_message("Starting application event loop", "QT")
        exit_code = app.exec_()
        log_message(f"Application exited with code: {exit_code}", "SYSTEM")
        
        sys.exit(exit_code)
        
    except Exception as e:
        error_msg = f"Fatal error in main(): {e}"
        log_message(error_msg, "FATAL")
        print(f"FATAL ERROR: {error_msg}")
        if log_path:
            print(f"Check log file for details: {log_path}")
        sys.exit(1)
    finally:
        # Ensure log file is properly closed
        close_logging()

if __name__ == "__main__":
    main()